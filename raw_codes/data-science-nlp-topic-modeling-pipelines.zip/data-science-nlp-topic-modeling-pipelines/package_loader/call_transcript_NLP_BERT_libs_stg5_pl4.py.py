# Databricks notebook source
pip install typing-extensions==4.5.0

# COMMAND ----------

pip install pydantic==2.2.1

# COMMAND ----------

pip install "snowflake-connector-python[secure-local-storage,pandas]"

# COMMAND ----------

pip install spacy

# COMMAND ----------

pip install tokenizers

# COMMAND ----------

pip install torch

# COMMAND ----------

pip install numpy==1.20.3

# COMMAND ----------

pip install tqdm --upgrade

# COMMAND ----------

pip install transformers

# COMMAND ----------

#pip install -U spacy[transformers] 


# COMMAND ----------

pip install pandas==1.4.3

# COMMAND ----------

pip install https://github.com/explosion/spacy-models/releases/download/en_core_web_sm-3.4.0/en_core_web_sm-3.4.0.tar.gz

# COMMAND ----------

sfUtils = sc._jvm.net.snowflake.spark.snowflake.Utils
sc = spark.sparkContext
sc._jvm.net.snowflake.spark.snowflake.SnowflakeConnectorUtils.enablePushdownSession(sc._jvm.org.apache.spark.sql.SparkSession.builder().getOrCreate())
zone = sc._jvm.java.util.TimeZone
zone.setDefault(sc._jvm.java.util.TimeZone.getTimeZone("UTC"))

# COMMAND ----------

# MAGIC %sql
# MAGIC SET TIME ZONE 'UTC';

# COMMAND ----------

import pandas as pd
import snowflake.connector
from snowflake.connector.converter_null import SnowflakeNoConverterToPython
import base64
import configparser
import logging
from cryptography.fernet import Fernet
from pyspark.sql import functions as F
from pyspark.sql.functions import lit
from pyspark.sql.types import *
import configparser
from cryptography.fernet import Fernet



# COMMAND ----------

from dateutil import tz
import pytz
from datetime import date
from datetime import datetime
import pprint
import datetime
import os,sys,csv,urllib,time
from datetime import datetime, date , timedelta , datetime, timezone
from pyspark.sql.functions import col
from pyspark.sql.types import IntegerType
def utc_to_local(utc_dt,tz_var):
    return utc_dt.replace(tzinfo=timezone.utc).astimezone(tz=tz_var)

# COMMAND ----------

import xml.etree.ElementTree as ET
from ast import literal_eval
import pickle
import requests
from pyspark.sql.functions import max, min
from datetime import datetime
from pyspark.sql.functions import to_date


# COMMAND ----------

import os
import numpy as np
import re
import ast
import unicodedata
from tokenizers import normalizers
from tokenizers.normalizers import NFD, StripAccents 
import spacy
#import spacy_transformers
from spacy.lang.en import English
from tqdm import tqdm
tqdm.pandas()
from pathlib import Path

# COMMAND ----------

import timeit
time_now = timeit.default_timer()

# COMMAND ----------

import sys
sys.setrecursionlimit(10000)
import multiprocessing

# COMMAND ----------

import torch
import torch.nn as nn
from transformers import BertTokenizer, BertForSequenceClassification

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC # DBFS Class

# COMMAND ----------

class color:
  """Class to color and modifiy font (colors don't work on databricks but bold and underline do)"""
  PURPLE = '\033[95m'
  CYAN = '\033[96m'
  DARKCYAN = '\033[36m'
  BLUE = '\033[94m'
  GREEN = '\033[92m'
  YELLOW = '\033[93m'
  RED = '\033[91m'
  BOLD = '\033[1m'
  UNDERLINE = '\033[4m'
  END = '\033[0m'   


"""DATABRICKS FILE SYSTEM HELPER CLASS"""


class DBFShelper(color):
  def __init__(self):
    """Functions to interact with Files in Databricks File System (DBFS)."""
    self.myName = self.get_Name()
    self.iniPath = '/FileStore/' + self.myName + '/resources/'
    
  def get_DBFSdir_content(self, folderPath):
    print(folderPath)
    dir_paths = dbutils.fs.ls(folderPath)
    subdir_paths = [self.get_dir_content(p.path) for p in dir_paths if p.isDir() and p.path != folderPath]
    flat_subdir_paths = [p for subdir in subdir_paths for p in subdir]
    
    return list(map(lambda p: p.path, dir_paths)) + flat_subdir_paths

  def add_DBFSdirectory(self, filePath, newDir):
    """Creates directory in DBFS."""
    dbutils.fs.mkdirs(filePath + newDir)

  def remove_DBFSfile(self, filePath, fileName):
    """Removes file on DBFS."""
    dbutils.fs.rm(filePath + fileName, True)
        
  def read_DBFSfile(self, filePath, fileName):
    """Reads file on DBFS."""
    file_str = ''
    with open('/dbfs' + filePath + fileName, "r") as f_read:
      for line in f_read:
        if line != '\n':
          file_str = file_str + line + '\n'
      print('Current file contents are as follows : ')
      print(file_str)
        
    return file_str
    
  def write_DBFSfile(self, filePath, fileName, contents):
    """Writes file on DBFS."""
    with open('/dbfs' + filePath + fileName, "w") as f_write:
      f_write.write(contents)
      f_write.close()
      
  def get_Name(self):
    dbutils.widgets.text('Name', "")
    y = dbutils.widgets.get('Name')
    
    return y
                      
  def __str__(self):
    """Returns a string with class description"""
    
    return 'This is a class including funtions to interact with Databricks file system.'

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC #Snowflake Database Helper Class

# COMMAND ----------

"""SNOWFLAKE HELPER CLASS"""


class SnoflkDBhelper(DBFShelper):
  def __init__(self, environmentStr):
    """Initialize the attributes of the db object"""
    DBFShelper.__init__(self)
    if environmentStr == 'nonprod':
      url = "voyatest.east-us-2.privatelink.snowflakecomputing.com"
    else:
      url = "voya.east-us-2.privatelink.snowflakecomputing.com"
    dbutils.widgets.remove("Name")
    self.env = environmentStr
    self.url = url  
    self.db = "EDS_PROD"
    self.schema = "QUANT"
    self.role = "ROLE_EDS_PROD_DDLADMIN_QUANT"
    self.myName = self.get_Name()
    self.iniPath = '/FileStore/' + self.myName + '/resources/'
    self.proc_encryption()
    
  def utc_to_local(self, utc_dt, tz_var):
    
    return utc_dt.replace(tzinfo=timezone.utc).astimezone(tz=tz_var)
  
  def generate_key(self):
    """generate cred key"""
    self.credKey = Fernet.generate_key()
      
  def encrypt_message(self, message):
    """encrypt message"""
    encoded_message = message.encode()
    f= Fernet(self.credKey)
    encrypted_message = f.encrypt(encoded_message)
    
    return encrypted_message

  def decrypt_message(self, encrypted_message):
    """decrypt message to use in host system"""
    #key = self.load_key()
    f= Fernet(self.credKey)    
    decrypted_message = f.decrypt(encrypted_message)
    
    return decrypted_message
  
  def proc_encryption(self):
    """execute entire encryption process involving cred and parameter files"""
    self.generate_key()

    cred_write_config = configparser.RawConfigParser()
    cred_write_config.read("/dbfs/" + self.iniPath + "cred.ini")
    
    db_name_str=str(self.db)
    username=cred_write_config.get(db_name_str,"username")
    password=cred_write_config.get(db_name_str,"password")
    encrypt_username= self.encrypt_message(username)
    encrypt_password= self.encrypt_message(password)
    encrypt_username_string=encrypt_username.decode('utf-8')
    encrypt_password_string=encrypt_password.decode('utf-8')

    
    self.paramsIni = {"db" : self.db, "username" : self.encrypt_message(username).decode('utf-8'), "password" : self.encrypt_message(password).decode('utf-8')}
    
    myDBFS.remove_DBFSfile(myDBFS.iniPath, 'cred.ini')
  
  def write_to_snowflake_table(self, df, tablename):
    """write to snowflake using encrypted credentials"""
    password_encoded = self.paramsIni["password"].encode('utf-8')
    username_encoded = self.paramsIni["username"].encode('utf-8')
    username_decrypt=self.decrypt_message(username_encoded)
    password_decrypt=self.decrypt_message(password_encoded)
    username=username_decrypt.decode('utf-8')
    password=password_decrypt.decode('utf-8')
    
    options = {
    "sfUrl": self.url,
    "sfUser": username,
    "sfPassword": password,
    "sfDatabase": self.db,
    "sfSchema": self.schema,
    "sfRole": self.role,
    "sfTimezone": "spark"
    }
    df\
    .write.format("snowflake")\
    .options(**options)\
    .option("dbtable",tablename)\
    .mode("append")\
    .save()
    result = "Load Complete"
    
    return result
  
  def read_from_snowflake(self,  query):
    """read data from snowflake using encrypted credentials"""
    password_encoded = self.paramsIni["password"].encode('utf-8')
    username_encoded = self.paramsIni["username"].encode('utf-8')
    username_decrypt=self.decrypt_message(username_encoded)
    password_decrypt=self.decrypt_message(password_encoded)
    username=username_decrypt.decode('utf-8')
    password=password_decrypt.decode('utf-8')
      
    options = {
    "sfUrl": self.url,
    "sfUser": username,
    "sfPassword": password,
    "sfDatabase": self.db,
    "sfSchema": self.schema,
    "sfRole": self.role,
    "sfTimezone": "spark"
    }
    
    df = spark.read \
              .format("snowflake") \
              .options(**options) \
              .option("query",  query) \
              .load()

    return df
          
  def truncate_or_merge_table(self, query):
    """truncate or merge data from snowflake using encrypted credentials"""
    password_encoded = self.paramsIni["password"].encode('utf-8')
    username_encoded = self.paramsIni["username"].encode('utf-8')
    username_decrypt=self.decrypt_message(username_encoded)
    password_decrypt=self.decrypt_message(password_encoded)
    username=username_decrypt.decode('utf-8')
    password=password_decrypt.decode('utf-8')
    
    options = {
    "sfUrl": self.url,
    "sfUser": username,
    "sfPassword": password,
    "sfDatabase": self.db,
    "sfSchema": self.schema,
    "sfRole": self.role,
    "sfTimezone": "spark"
    }
    df=sfUtils.runQuery(options, query)
    result="Truncate or Merge Complete"
    
    return result                            
                      
  def __str__(self):
    """Returns a string with class description"""
    print("")
    print("This is object is a Snowflake connection with the following attributes: \n")
    print('Environment : ' + self.env)
    print('url : ' + self.url)
    print('cred file path : ' + self.iniPath)
    print("")
    print('encrypted SF credentials : ')
    pprint.pprint(self.paramsIni)
    print("")
    print('It includes methods to establish, maintain, encrypt and update Snowflake database credentials.')
    print("")
    print('Also incuded are methods to query Snowflake tables in the environment for which you have set-up encrypted credentails.')
    
    return ''

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC # General NLP Class

# COMMAND ----------

"""GENERAL NLP CLASS"""  

  
class nlpGen():
  def __init__(self):
    """Initialize the attributes of the nlp object"""
    self.spacyTokenizer = spacy.load('en_core_web_sm')
    self.path = Path(os.getcwd())
    self.w_dir = str(self.path.parent.parent.parent.absolute())
    
    self.dict_file_location = "/dbfs/mnt" +self.w_dir + "bea/Libraries/LM_Dictionary/"
    self.model_addr = "/dbfs/mnt/bea/Libraries/Machine Learning/finBERTImplementation/classifier_model/finbert-sentiment"
    
    
    file = open(self.dict_file_location + "contraction_words.txt", "r")
    contents = file.read()
    self.contractions = ast.literal_eval(contents)
    file.close()

    #===============================================================================
    # load generic stop words list from L&M dictionary
    #===============================================================================
    file_address = self.dict_file_location + 'StopWords_Full_list.txt'
    with open(file_address ,'r') as stop_words:
        stopWords = stop_words.read().lower()
    stopWordList = stopWords.split('\n')
    self.stopWordList = set(stopWordList)

    #===============================================================================
    # Loading litigious words from L&M dictionary
    #===============================================================================
    file_address = self.dict_file_location + 'litigious_words.txt'
    with open(file_address ,'r') as pos_words:
        posWords = pos_words.read().lower()
    litigiousWordList = posWords.split('\n')
    self.litigiousWordList = set(litigiousWordList)

    #===============================================================================
    # Loading complex words from L&M dictionary
    #===============================================================================
    file_address = self.dict_file_location + 'complexity_words.txt'
    with open(file_address ,'r') as neg_words:
        negWords = neg_words.read().lower()
    complexWordList = negWords.split('\n')
    self.complexWordList = set(complexWordList)

    #===============================================================================
    # Loading uncertainty words from L&M dictionary
    #===============================================================================
    file_address = self.dict_file_location + 'uncertainty_words.txt'
    with open(file_address,'r') as neg_words:
        negWords = neg_words.read().lower()
    uncertainWordList = negWords.split('\n')
    self.uncertainWordList = set(uncertainWordList)

    #===============================================================================
    # Loading litigious words from L&M dictionary
    #===============================================================================
    file_address = self.dict_file_location + 'syllable_count.txt'
    syllables = {}
    with open(file_address ,'r') as pos_words:
        for line in pos_words:
            word, count = line.split() 
            syllables[word.lower()] = int(count)
    self.syllables = syllables
    #===============================================================================
    #will use this list to id negated words
    #===============================================================================
    self.negate = ["cannot","neither","never", "none", "nope", "nor", "not", "nothing", "nowhere","without", "rarely", "seldom", "despite", "no", "nobody"]
    #negate = set(negate)
    #===============================================================================
    # Loading positive words from L&M dictionary
    #===============================================================================
    file_address = self.dict_file_location + 'vocab_pos.txt'
    with open(file_address ,'r') as pos_words:
        posWords = pos_words.read().lower()
    positiveWordList = posWords.split('\n')
    self.positiveWordList = set(positiveWordList)

    #===============================================================================
    # Loading negative words from L&M dictionary
    #===============================================================================
    file_address = self.dict_file_location + 'vocab_neg.txt'
    with open(file_address ,'r') as neg_words:
        negWords = neg_words.read().lower()
    negativeWordList = negWords.split('\n')
    self.negativeWordList = set(negativeWordList)
  
      #===============================================================================
  #function for imputing contraction's:
  #===============================================================================
  def expand_contractions(self, text):
    for word in text.split():
      if word.lower() in self.contractions:
        text = text.replace(word, self.contractions[word.lower()])
              
    return text
  
  #===============================================================================
  #function to check if string exists in stopWords
  #===============================================================================
  def checkStopWord(self, text):
    if text in self.stopWordList:
      
      return 0

    return 1
  
  #function for removing unicode data :
  #===============================================================================
  def remove_accented_chars(self, text):
    normalizer = normalizers.Sequence([NFD(), StripAccents()])
    
    return normalizer.normalize_str(text)
  
  #===============================================================================
  ## defining tokenizer - Spacy
  # Tokenizer + Lemmatization using spacy  
  #===============================================================================
  def tokenizer_spacy(self, text):
    text = text.lower()
    doc = self.spacyTokenizer(text)
    token_lemmatized = []
    for token in doc:
      token_lemmatized.append(token.text)

    filtered_words = list(filter(lambda x: x not in self.stopWordList, token_lemmatized))
    
    return filtered_words
  
  # Identifies 
  def acq(self, text): 
    if ('acquisition' in ' '.join(text).lower()) or ('merger' in ' '.join(text).lower()):
      
      return 1
    
    else:
      
      return 0
    
   #===============================================================================  
  #function to id negations
  #===============================================================================
  def negated(self, word):
    """
    Determine if preceding word is a negation word
    """
    return word in self.negate

  def correctID(x):
    if (len(set(x))==1) & (type(x)==list):
      
      return [x[0]]  
    else:
      
      return x
    
  def checkDataType(self, textList):
    #IF THE TEXT LIST HAS TEXT, PROCESS IT, OTHERWISE OUTPUT NAN
    if (not isinstance(textList,str) and textList and ' '.join(textList).strip(' ')) or (isinstance(textList,str) and textList.strip(' ')):
      #Text input is not and empty string or list
      if not isinstance(textList,str):
        #Text input is a list
        text = ' '.join(textList)
      else:
        #Text input is a string
        text = textList
    else:
      text = False
        
    return text
        
  def pre_proc_text(self, textList):
    text = self.checkDataType(textList)
    
    if text:
      ###Functions to clean the text ###
      #using contractions dictionary to make corrections 
      text = self.expand_contractions(re.sub('’', "'", text))
      #stripping the words using space 
      text = text.strip().lower() 
      #replacing " " " with space 
      text = text.replace('"', '')
      #remove single words - 'a','A','i','I'
      text = re.sub(r"\b[a-zA-Z]\b", "", text)  
      #replace anything that is not an english letter - ',','.','123','$' with space
      text = re.sub("[^a-zA-Z]", " ", text) 
      #replace spaces more than one with single space 
      text = re.sub("\s+", ' ', text)
      
      input_words = self.tokenizer_spacy(text)
      word_count = len(input_words)
      
      return text, input_words, word_count
    
    else:
      
      return text, [], 0
        
  def lm_analysis(self, textList):
    text, input_words, word_count = self.pre_proc_text(textList)
    if (text) and (word_count > 1):
      lit_count = 0
      com_count = 0
      unc_count = 0
      for input_word in input_words:
        if input_word in self.litigiousWordList:
            lit_count +=1
            
        if input_word in self.complexWordList:
            com_count +=1
            
        if input_word in self.uncertainWordList:
            unc_count +=1
        lit_score = lit_count / (word_count)
        com_score = com_count / (word_count)
        unc_score = unc_count / (word_count)

      return (lit_score, com_score, unc_score, word_count, lit_count, com_count, unc_count)
    
    else:

      return (np.nan , np.nan , np.nan , np.nan,  np.nan,  np.nan,  np.nan)
          
#===============================================================================
#Clean text and calculate polarity score for each document including negation of
#positive term
#===============================================================================

  def fog_analysis(self, textList):
    if isinstance(textList, list):
      raw_text = ' '.join(textList)
    else:
      raw_text = textList
      
    total_word_count = len(raw_text.split(' '))
    avg_word_per_sent = np.mean([len(sent.split(" ")) for sent in raw_text.split('. ')])
    text, input_words, word_count = self.pre_proc_text(textList)

    if (text) and (word_count > 1):
      com_count = 0
      for input_word in input_words:
        # check if word exists in our dictionary
        if(input_word in self.syllables.keys()):
          
          if (input_word.endswith('es')):
            
            # Check if root word is a many-syllable word - in this case excluding just 's' may yield root
            if (input_word[:-1] in self.syllables.keys()):
              
              if(self.syllables[input_word[:-1]] > 2):
                com_count +=1
                continue
              else:
                continue
                
            # Check if root word is a many-syllable word - in this case excluding 'es' may yield root       
            elif (input_word[:-2] in self.syllables.keys()):
              
              if(self.syllables[input_word[:-2]] > 2):
                com_count +=1
                continue
              else:
                continue  
                
          if(input_word.endswith('ing')):
            
            # Excluding 'ing' may yield root 
            if (input_word[:-3] in self.syllables.keys()):
              
              if(self.syllables[input_word[:-3]] > 2):
                com_count +=1
                continue
              else:
                continue
                
          if(input_word.endswith('ed')):
            
            if (input_word[:-1] in self.syllables.keys()):
              
              if(self.syllables[input_word[:-1]] > 2):
                com_count +=1
                continue
              else:
                continue
                
            elif (input_word[:-2] in self.syllables.keys()):
              
              if(self.syllables[input_word[:-2]] > 2):
                com_count +=1
                continue
              else:
                continue
                
          # In case no recognized suffix is added            
          if(self.syllables[input_word] > 2):
            com_count +=1
     
      fog_index = 0.4 * (avg_word_per_sent + 100 * (com_count/total_word_count))
        
      return (fog_index, com_count, avg_word_per_sent, total_word_count)
          
    else:
      
      return (np.nan, np.nan, np.nan, np.nan)
    
  #===============================================================================
  #Clean text and calculate polarity score for each document including negation of
  #positive term
  #==============================================================================
  
  # Function to extract no. of dollar amounts from the given string
  def getDollarAmounts(self, textList):
    text = self.checkDataType(textList)
    text_tokenized, input_words, word_count = self.pre_proc_text(textList)
    if (text) and (word_count > 0):
      array = re.findall(r'\$[0-9]+', text)
      
      return (len(array), word_count)
    
    else:
      
      return (np.nan, np.nan)

  # Function to extract no. of numerical values from the given string (including dollar amounts!)
  def getNumbers(self, textList):
    text = self.checkDataType(textList)
    text_tokenized, input_words, word_count = self.pre_proc_text(textList)
    if (text) and (word_count > 0):
      array = re.findall(r'[\$]*[0-9]+[.]*[0-9]*', text)

      return (len(array), word_count)
    
    else:
      
      return (np.nan, np.nan)
  
  def polarity_score(self, textList):
    text, input_words, word_count = self.pre_proc_text(textList)
    
    if (text) and (word_count > 1):
      pos_count = 0
      neg_count = 0 
      pos_words = []
      neg_words = []
      for i in range(0, word_count):
        if input_words[i] in self.negativeWordList:
          neg_count -=1
          neg_words.append(input_words[i])
          
        if input_words[i] in self.positiveWordList:
          
          if i >= 3:
            
            if self.negated(input_words[i - 1]) or self.negated(input_words[i - 2]) or self.negated(input_words[i - 3]):
              neg_count -=1
              neg_words.append(input_words[i] + ' (with negation)')
            else:
              pos_count += 1
              pos_words.append(input_words[i])
              
          elif i == 2:
            
            if self.negated(input_words[i - 1]) or self.negated(input_words[i - 2]):
              neg_count -=1
              neg_words.append(input_words[i] + ' (with negation)')
            else:
              pos_count += 1
              pos_words.append(input_words[i])
              
          elif i == 1:
            
            if self.negated(input_words[i - 1]):
              neg_count -=1
              neg_words.append(input_words[i] + ' (with negation)')
            else:
              pos_count += 1
              pos_words.append(input_words[i])
              
          elif i == 0:
            pos_count += 1
            pos_words.append(input_words[i])

      sumNeg = neg_count 
      sumNeg = sumNeg * -1

      pol_score = (pos_count - sumNeg) / (word_count)
      legacy_score = self.combine_sent(pos_count, sumNeg)
      
      return (pol_score, word_count, sumNeg, pos_count, legacy_score)
    
    else:
      
      return (np.nan, np.nan, np.nan , np.nan, np.nan)  
        
  def tone_count_with_negation_check(self, textList):
    """
    Count positive and negative words with negation check. Account for simple negation only for positive words.
    Simple negation is taken to be observations of one of negate words occurring within three words
    preceding a positive words.
    """ 

    scores = []
    legacy_scores = []
    lengths = []
    neg_count_list = []
    pos_count_list = []
    #print('Negative words: ', neg_words,'\nPositive words: ', pos_words, '\n')
    sent_metrics = self.polarity_score(textList)

    scores.append(sent_metrics[0])
    lengths.append(sent_metrics[1])
    neg_count_list.append(sent_metrics[2])
    pos_count_list.append(sent_metrics[3])
    legacy_scores.append(sent_metrics[4])

    return (scores, lengths, neg_count_list, pos_count_list, legacy_scores)

  def combine_sent(self, x, y):
    if x + y == 0:

      return 0
      
    else:

      return ((x-y)/(x+y))

  def get_gpu(self):
    dbutils.widgets.text('gpuNo', "")
    y = dbutils.widgets.get('gpuNo')
    
    return y
        
  def predict(self, text):
    # This block feeds inputs to model and returns the predicted label
       # GPU no. 0 - MAKE SURE THAT GPU NUMBER YOU ASSIGN IS AVAILABLE IN !nvidia-smi
    self.model.to('cuda:' + self.get_gpu())
    # Each input has to be tokenized using the BERT tokenizer, truncated to 512 tokens
    inputs = self.tokenizer(text , return_tensors="pt", max_length = 512, truncation = True)
    # Load the input vector into the correct GPU
    inputs = inputs.to('cuda:' + self.get_gpu())
    # This block feeds inputs to model and returns the predicted label

    with torch.no_grad():
      logits = self.model(**inputs).logits
      d_logits = logits.detach().cpu().numpy()
      pred = np.argmax(d_logits)

      return pred

  def check_sentence(self, sent):
    sent = sent.lower().split(" ")
    if len(sent) < 3:
      
        return 0
      
    if "operator" in sent or "operator," in sent:
      
        return 0
      
    return 1

  def filter_sentence(self, sent):
    sent = sent.replace("Thank you", "")
    sent = sent.replace("thank you", "")
    sent = sent.replace("thanks", "")
    sent = sent.replace("Thanks", "")
    sent = sent.replace("Sorry", "")
    sent = sent.replace("sorry", "")

    return sent
    
  def bert_sentiment_score(self, textList):
    text = self.checkDataType(textList)

    if text:
        
      score = np.nan
      pos_sent = 0
      neg_sent = 0
      neutral_sent = 0
      num_sentences = 0

      #replace spaces more than one with single space 
      text = re.sub("\s+", ' ', text)
      sentences = text.split('.')
      sentences = list(filter(self.check_sentence, sentences))
      num_sentences = len(sentences)
      
      if num_sentences > 0:
        for sentence in sentences:
          sentence = sentence.strip()
          sentence += '.'
          sentence = self.filter_sentence(sentence)
          sent_score = self.predict(sentence)

          if sent_score==0:
            pos_sent+=1

          if sent_score==1:
            neg_sent+=1

        if num_sentences!=0:  
          score = (pos_sent - neg_sent)/num_sentences

        return (score, neg_sent, pos_sent, num_sentences)
      
      else: 
        
        return(np.nan, np.nan, np.nan, 0)
    
    else:
      
      return(np.nan, np.nan, np.nan, np.nan)

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC # Call Transcript NLP Class

# COMMAND ----------

"""CALL TRANSCRIPT NLP CLASS"""

   
class nlpCT(nlpGen, SnoflkDBhelper):
  def __init__(self, min_date_new, max_date_new, new_data_dims, currdf, histdf):
    """Initialize the attributes of the transcirpt nlp object"""
    #RUN INITIALIZATION OF NLPGEN CLASS TO INHERIT ATTRIBUTES
    nlpGen.__init__(self)
    #DEFINE PATH TO FACTSET XML LAYOUT FILE
    self.xlmns = "{http://www.factset.com/callstreet/xmllayout/v0.1}"
    #GET THE CURRENT DATE TO USE AS METADATA
    eastern_tzinfo = pytz.timezone("America/New_York")
    load_date_time = self.utc_to_local(datetime.now(),eastern_tzinfo)
    load_date_prep = datetime.strptime(load_date_time.strftime("%Y-%m-%d %H:%M:%S"), "%Y-%m-%d %H:%M:%S") 
    self.last_parsed_datetime = load_date_prep
    #SAVE ATTRIBUTES OF THE CALL TRANSCRIPTS BEING PROCESSED
    self.parsed_df = pd.DataFrame()
    self.min_last_ts_date = min_date_new
    self.max_last_ts_date = max_date_new
    self.last_data_dims = new_data_dims
    self.texts = ['EXEC_ANS',
                 'EXEC_DISCUSSION',
                 'CEO_ANS',
                 'CEO_DISCUSSION',
                 'ANALYST_QS',
                 'MGNT_DISCUSSION',
                 'QA_SECTION']
    self.textFunctionTupleList = [('EXEC_ANS', 'lm'), ('EXEC_ANS', 'dsa'), ('EXEC_ANS', 'num'), ('EXEC_ANS', 'fog'),
                                 ('EXEC_DISCUSSION', 'lm'), ('EXEC_DISCUSSION', 'dsa'), ('EXEC_DISCUSSION', 'num'), ('EXEC_DISCUSSION', 'fog'),
                                 ('CEO_ANS', 'lm'), ('CEO_ANS', 'dsa'), ('CEO_ANS', 'num'), ('CEO_ANS', 'fog'),
                                 ('CEO_DISCUSSION', 'lm'), ('CEO_DISCUSSION', 'dsa'), ('CEO_DISCUSSION', 'num'), ('CEO_DISCUSSION', 'fog'),
                                 ('ANALYST_QS', 'lm'), ('ANALYST_QS', 'dsa'), ('ANALYST_QS', 'num'), ('ANALYST_QS', 'fog'),
                                 ('MGNT_DISCUSSION', 'lm'), ('MGNT_DISCUSSION', 'dsa'), ('MGNT_DISCUSSION', 'num'), ('MGNT_DISCUSSION', 'fog'),
                                 ('QA_SECTION', 'lm'), ('QA_SECTION', 'dsa'), ('QA_SECTION', 'num'), ('QA_SECTION', 'fog')]
    self.aggTexts = ['MGNT_DISCUSSION', 'QA_SECTION']
    self.transientFileLoc = "/dbfs/mnt/bea/callTranscriptTransientData/pickleFilesStaging/"
    
    #PARSE TRASCRIPTS
    if not currdf.empty:
      self.histdf = currdf
      curr_list = currdf.to_numpy().tolist()
      for row in curr_list:
        self.parsed_df = self.parseXMLfromStr(row)
    else:
      self.histdf = histdf
      
    self.outputCols = ['ENTITY_ID',
                       'CALL_ID',
                       'CALL_NAME',
                       'COMPANY_NAME',
                       'EARNINGS_CALL',
                       'DATE',
                       'EXEC_ANS_POLARITY',
                       'EXEC_ANS_POS_WORD_PER_LEN',
                       'EXEC_DISCUSSION_POLARITY',
                       'EXEC_DISCUSSION_POS_WORD_PER_LEN',
                       'CEO_ANS_POLARITY',
                       'CEO_ANS_POS_WORD_PER_LEN',
                       'CEO_DISCUSSION_POLARITY',
                       'CEO_DISCUSSION_POS_WORD_PER_LEN',
                       'ANALYST_QS_POLARITY',
                       'ANALYST_QS_POS_WORD_PER_LEN',
                       'EXEC_ANS_COMBINED_LEN',
                       'EXEC_DISCUSSION_COMBINED_LEN',
                       'ANALYST_QS_COMBINED_LEN',
                       'CEO_ANS_COMBINED_LEN',
                       'CEO_DISCUSSION_COMBINED_LEN',
                       'ANALYST_QS_COMBINED_POS_WORD_COUNT',
                       'ANALYST_QS_COMBINED_NEG_WORD_COUNT',
                       'CEO_DISCUSSION_COMBINED_POS_WORD_COUNT',
                       'CEO_DISCUSSION_COMBINED_NEG_WORD_COUNT',
                       'EXEC_ANS_COMBINED_POS_WORD_COUNT',
                       'EXEC_ANS_COMBINED_NEG_WORD_COUNT',
                       'EXEC_DISCUSSION_COMBINED_POS_WORD_COUNT',
                       'EXEC_DISCUSSION_COMBINED_NEG_WORD_COUNT',
                       'CEO_ANS_COMBINED_POS_WORD_COUNT',
                       'CEO_ANS_COMBINED_NEG_WORD_COUNT',
                       'EXEC_ANS_SENT_BERT',
                       'EXEC_DISCUSSION_SENT_BERT',
                       'CEO_ANS_SENT_BERT',
                       'CEO_DISCUSSION_SENT_BERT',
                       'ANALYST_QS_SENT_BERT',
                       'EXEC_ANS_NUM_SENTENCES',
                       'EXEC_DISCUSSION_NUM_SENTENCES',
                       'CEO_ANS_NUM_SENTENCES',
                       'CEO_DISCUSSION_NUM_SENTENCES',
                       'ANALYST_QS_NUM_SENTENCES',
                       'EXEC_ANS_POS_SENT_COUNT_BERT',
                       'EXEC_DISCUSSION_POS_SENT_COUNT_BERT',
                       'CEO_ANS_POS_SENT_COUNT_BERT',
                       'CEO_DISCUSSION_POS_SENT_COUNT_BERT',
                       'ANALYST_QS_POS_SENT_COUNT_BERT',
                       'EXEC_ANS_NEG_SENT_COUNT_BERT',
                       'EXEC_DISCUSSION_NEG_SENT_COUNT_BERT',
                       'CEO_ANS_NEG_SENT_COUNT_BERT',
                       'CEO_DISCUSSION_NEG_SENT_COUNT_BERT',
                       'ANALYST_QS_NEG_SENT_COUNT_BERT',
                       'MGNT_DISCUSSION_FOG_INDEX',
                       'EXEC_DISCUSSION_NUMBERS_PER_LEN',
                       'CEO_DISCUSSION_NUMBERS_PER_LEN',
                       'CEO_ANS_NUMBERS_PER_LEN',
                       'EXEC_ANS_NUMBERS_PER_LEN',
                       'ANALYST_QS_NUMBERS_PER_LEN',
                       'EXEC_DISCUSSION_NUMBERS_COUNT',
                       'CEO_DISCUSSION_NUMBERS_COUNT',
                       'CEO_ANS_NUMBERS_COUNT',
                       'EXEC_ANS_NUMBERS_COUNT',
                       'ANALYST_QS_NUMBERS_COUNT',
                       'EXEC_DISCUSSION_LIT_COUNT',
                       'CEO_DISCUSSION_LIT_COUNT',
                       'CEO_ANS_LIT_COUNT',
                       'EXEC_ANS_LIT_COUNT',
                       'ANALYST_QS_LIT_COUNT',
                       'EXEC_DISCUSSION_COM_COUNT',
                       'CEO_DISCUSSION_COM_COUNT',
                       'CEO_ANS_COM_COUNT',
                       'EXEC_ANS_COM_COUNT',
                       'ANALYST_QS_COM_COUNT',
                       'EXEC_DISCUSSION_UNC_COUNT',
                       'CEO_DISCUSSION_UNC_COUNT',
                       'CEO_ANS_UNC_COUNT',
                       'EXEC_ANS_UNC_COUNT',
                       'MGNT_DISCUSSION_POS_WORD_PER_LEN',
                       'MGNT_DISCUSSION_POLARITY',
                       'MGNT_DISCUSSION_COMBINED_POS_WORD_COUNT',
                       'MGNT_DISCUSSION_COMBINED_NEG_WORD_COUNT',
                       'MGNT_DISCUSSION_COMBINED_LEN',
                       'QA_SECTION_POS_WORD_PER_LEN',
                       'QA_SECTION_POLARITY',
                       'QA_SECTION_COMBINED_POS_WORD_COUNT',
                       'QA_SECTION_COMBINED_NEG_WORD_COUNT',
                       'QA_SECTION_COMBINED_LEN',
                       'MGNT_DISCUSSION_SENT_BERT',
                       'MGNT_DISCUSSION_NUM_SENTENCES',
                       'MGNT_DISCUSSION_POS_SENT_COUNT_BERT',
                       'MGNT_DISCUSSION_NEG_SENT_COUNT_BERT',
                       'QA_SECTION_SENT_BERT',
                       'QA_SECTION_NUM_SENTENCES',
                       'QA_SECTION_POS_SENT_COUNT_BERT',
                       'QA_SECTION_NEG_SENT_COUNT_BERT',
                       'MGNT_DISCUSSION_NUMBERS_PER_LEN',
                       'MGNT_DISCUSSION_NUMBERS_COUNT',
                       'QA_SECTION_NUMBERS_PER_LEN',
                       'QA_SECTION_NUMBERS_COUNT',
                       'MGNT_DISCUSSION_LIT_COUNT',
                       'MGNT_DISCUSSION_UNC_COUNT',
                       'MGNT_DISCUSSION_COM_COUNT',
                       'QA_SECTION_LIT_COUNT',
                       'QA_SECTION_UNC_COUNT',
                       'QA_SECTION_COM_COUNT']
  
  #PARSING METHOD
  
  def parseXMLfromStr(self, xmlListRow):
    """Parse XML strings stored in Snowflake"""
    SF_Date = []
    SF_ID = []
    entity_ID = []
    error = []
    SF_Date.append(xmlListRow[0])
    SF_ID.append(xmlListRow[1])
    entity_ID.append(xmlListRow[2])
    xmlStr = xmlListRow[3]
    eventDatetime = xmlListRow[6]
    # get root element
    try:
      root = ET.fromstring(xmlStr)
      error.append('no')
    except Exception as e:
      print("Oops!", e.__class__, "occurred for trasnscript with ID = " + str(xmlListRow[1]) + ".")
      print("Next entry.")
      print
      error.append('yes')
      call_dict = {"ENTITY_ID": entity_ID[0], "SF_DATE": SF_Date[0], "SF_ID": SF_ID[0], "ERROR" : error[0], "TRANSCRIPT_STATUS": '', "COMPANY_NAME": '', 
                   "COMPANY_ID": '', "CALL_NAME": '', "CALL_ID": '', "DATE": '', 
                   "CEO_ID": '', "CEO_DISCUSSION": '', "EXEC_DISCUSSION": '', "ANALYST_QS": '', "CEO_ANS": '', 
                   "EXEC_ANS": '', "MGNT_DISCUSSION": '', "QA_SECTION": '', "EARNINGS_CALL": '', 'EVENT_DATETIME_UTC': ''}

      self.parsed_df = self.parsed_df.append(call_dict, ignore_index = True)
      return self.parsed_df.copy()

    # We maintain lists of participant IDs to track whether someone speaking is an analyst or corporate representative
    corprep_ids = []
    analyst_ids = []

    # Basic metadata 
    company_name = []
    company_id = []
    transcript_id = root.get('id')
    status = root.get('product')

    call_title = root.find('./' + self.xlmns + 'meta/' + self.xlmns + 'title').text

    #CHECK TO SEE IF CALL ID IN XML IS MISSING AND, IF IT IS, REPLACE WITH SNOWFLAKE ID IF AVAILABLE OR EMPTY STRING IF NOT
    if root.get('id'):
      call_id = ''.join(root.get('id'))
    else:
      print('No ID in xml for snowflake ID: ' + str(xmlListRow[1]) + '.  Using ID from Snowflake table')
      call_id = ''.join(xmlListRow[1])

    # Only parse corrected earnings calls for current pipeline
    if 'correct' not in status.lower():
      return self.parsed_df

    # Call date
    date = root.find('./' + self.xlmns + 'meta/' + self.xlmns + 'date').text
    year = int(date[:4])
    month = int(date[5:7])
    day = int(date[8:10])

    # These lists will be populated with paragraphs of speech corresponding to our sections
    ceo_speech = []
    exec_speech = []
    ceo_ans = []
    exec_ans = []
    an_q = []

    # To track CEO speech
    ceo_id = []
    ceo_unique_id = []
    ceo_matches = 0

    # Additional metadata
    num_of_analysts = 0
    merger = 0
    earnings_call = 1

    # This loop collects participant IDs and other metadata
    for child in root.findall('./' + self.xlmns + 'meta/' + self.xlmns + 'participants/'):
      if child.get('type') == 'corprep':
        corprep_ids.append(child.get('id'))

        if self.checkCEO(child.get('title'))==1:
          ceo_matches += 1
          company_name.append(child.get('affiliation'))
          company_id.append(child.get('affiliation_entity'))
          ceo_id.append(child.get('id'))
          ceo_unique_id.append(child.get('entity'))

      if child.get('type') == 'analyst':
        analyst_ids.append(child.get('id'))

    num_of_analysts = len(analyst_ids)

    if company_id==[]:
      company_id = root.find('./' + self.xlmns + 'meta/' + self.xlmns + 'companies/' + self.xlmns + 'company').text

    # This loop goes through two bodies of text - Management discussion and Q&A. It collects text paragraph-wise 
    # and stores them in the relevant variable. 
    for child in root.findall('./' + self.xlmns + 'body/' + self.xlmns + 'section'):
      if child.get('name') == 'MANAGEMENT DISCUSSION SECTION':
        for participant in child.findall('./'):
          p_id = participant.get('id')
          if p_id in corprep_ids:

            if p_id in ceo_id:
              for para in participant.findall('./' + self.xlmns + 'plist/'):
                if(para.text!= None):
                  para.text = " ".join(para.text.split())
                  ceo_speech.append(para.text)
            else:
              for para in participant.findall('./' + self.xlmns + 'plist/'):
                if(para.text!= None):
                  para.text = " ".join(para.text.split())
                  exec_speech.append(para.text)

      if child.get('name') == 'Q&A':
        for participant in child.findall('./'):
          p_id = participant.get('id')
          if p_id in analyst_ids:
            for para in participant.findall('./' + self.xlmns + 'plist/'):
              if(para.text!= None):
                para.text = " ".join(para.text.split())
                an_q.append(para.text)

          if p_id in corprep_ids:

            if p_id in ceo_id: 
              for para in participant.findall('./' + self.xlmns + 'plist/'):
                if(para.text!= None):
                  para.text = " ".join(para.text.split())
                  ceo_ans.append(para.text)   
            else:
              for para in participant.findall('./' + self.xlmns + 'plist/'):
                if(para.text!= None):
                  para.text = " ".join(para.text.split())
                  exec_ans.append(para.text)

    merger = 1 if len(set(company_name))>1 else 0 
    earnings_call_title = self.checkEarnings(call_title)
    earninsg_call = 1
    management_disc = ' '.join(ceo_speech) + ' '.join(exec_speech)
    management_ans = ' '.join(ceo_ans) + ' '.join(exec_ans)
    QandA_total = [' '.join(an_q) + management_ans]
    management_ans = [management_ans]
    management_disc = [management_disc]
    company_name = ' '.join(company_name)

    call_dict = {"ENTITY_ID" : entity_ID[0], "SF_DATE": SF_Date[0], "SF_ID": SF_ID[0], "ERROR" : error[0], "TRANSCRIPT_STATUS": status, 
                 "COMPANY_NAME": company_name, "COMPANY_ID": company_id[0], "CALL_NAME": call_title, "CALL_ID": call_id, "DATE": date, 
                 "CEO_DISCUSSION": ceo_speech, "EXEC_DISCUSSION": exec_speech, 
                 "ANALYST_QS": an_q, "CEO_ANS": ceo_ans, "EXEC_ANS": exec_ans, "MGNT_DISCUSSION" : management_disc,
                 "QA_SECTION": QandA_total, "EARNINGS_CALL": earnings_call, 'EVENT_DATETIME_UTC': eventDatetime}

    self.parsed_df = self.parsed_df.append(call_dict, ignore_index = True)

    return self.parsed_df.copy()


  def checkCEO(self, string):
    """Check if some version of 'CEO' is in a string"""
    try:
      if ('ceo' in string.lower()) or ('chief executive officer' in string.lower()) or ('c.e.o' in string.lower()):
        
        return 1
      
      else:
        
        return 0
      
    except:
      
      return 0

  def checkEarnings(self, string):
    """Check if some version of 'Earnings' is in a string"""
    try:
      if ('earnings' in string.lower()) or ('earning' in string.lower()):
        
        return 1
      
      else:
        
        return 0
      
    except:
      
      return 0
      
  #PROCESSING METHODS
  
  def proc_NLP(self, text):
    """Process parsed data with dictionary and numerical methods"""
    df = self.parsed_df
    
    #LM additional metrics 
    df[text + "_UNC_COUNT"] = df[text].progress_apply(lambda x: self.lm_analysis(x))
    
    df[text + "_LIT_COUNT"] = df[text + "_UNC_COUNT"].apply(lambda x: x[4])
    df[text + "_COM_COUNT"] = df[text + "_UNC_COUNT"].apply(lambda x: x[5])
    df[text + "_UNC_COUNT"] = df[text + "_UNC_COUNT"].apply(lambda x: x[6])

    #Fog Index
    df[text + "_FOG_INDEX"] = df[text].progress_apply(lambda x: self.fog_analysis(x)[0])

    print(text + " fog metrics calculated. Aggregating...")
    
    #Dictionary sentiment
    df[text + "_POLARITY"] = df[text].progress_apply(lambda x: self.tone_count_with_negation_check(x))

    print(text + " dict SA metrics calculated. Aggregating...")

    df[text + "_COMBINED_LEN"] = df[text + "_POLARITY"].apply(lambda x: x[1][0])
    df[text + "_COMBINED_NEG_WORD_COUNT"] = df[text + "_POLARITY"].apply(lambda x: x[2][0])
    df[text + "_COMBINED_POS_WORD_COUNT"] = df[text + "_POLARITY"].apply(lambda x: x[3][0])
    df[text + "_POLARITY"] = df[text + "_POLARITY"].apply(lambda x: x[4][0])

    df[text + "_POS_WORD_PER_LEN"] = df[[text + "_COMBINED_POS_WORD_COUNT", text + "_COMBINED_LEN"]].apply(lambda x: x[0]/x[1], axis =1)

    #Numerical features
    df[text + '_NUMBERS_COUNT'] = df[text].progress_apply(lambda x: self.getNumbers(x))
    df[text + '_NUMBERS_PER_LEN'] = df[text + '_NUMBERS_COUNT'].apply(lambda x: x[0]/x[1])
    df[text + '_NUMBERS_COUNT'] = df[text + '_NUMBERS_COUNT'].progress_apply(lambda x: x[0])

    return df
      
  def proc_NLP_large(self, textFunctionTuple):
    """Process large sets of parsed data with dictionary and numerical methods"""
    print(textFunctionTuple)
    #fList = textFunctionTuple[0]

    df = self.parsed_df
    text = textFunctionTuple[0]
    function = textFunctionTuple[1]
    
    if function == 'lm':
      #LM additional metrics 
      df[text + "_UNC_COUNT"] = df[text].progress_apply(lambda x: self.lm_analysis(x))
      
      print(text + " lm metrics calculated. Aggregating...")
      df[text + "_LIT_COUNT"] = df[text + "_UNC_COUNT"].apply(lambda x: x[4])
      df[text + "_COM_COUNT"] = df[text + "_UNC_COUNT"].apply(lambda x: x[5])
      df[text + "_UNC_COUNT"] = df[text + "_UNC_COUNT"].apply(lambda x: x[6])
    elif function == 'fog':
      #Fog Index
      df[text + "_FOG_INDEX"] = df[text].progress_apply(lambda x: self.fog_analysis(x)[0])
      
      print(text + " fog metrics calculated. Aggregating...")
    elif function =='dsa':
      #Dictionary sentiment
      df[text + "_POLARITY"] = df[text].progress_apply(lambda x: self.tone_count_with_negation_check(x))

      print(text + " dict SA metrics calculated. Aggregating...")
      df[text + "_COMBINED_LEN"] = df[text + "_POLARITY"].apply(lambda x: x[1][0])
      df[text + "_COMBINED_NEG_WORD_COUNT"] = df[text + "_POLARITY"].apply(lambda x: x[2][0])
      df[text + "_COMBINED_POS_WORD_COUNT"] = df[text + "_POLARITY"].apply(lambda x: x[3][0])
      df[text + "_POLARITY"] = df[text + "_POLARITY"].apply(lambda x: x[4][0])

      df[text + "_POS_WORD_PER_LEN"] = df[[text + "_COMBINED_POS_WORD_COUNT", text + "_COMBINED_LEN"]].apply(lambda x: x[0]/x[1], axis =1)
    else:
      #Numerical features
      df[text + '_NUMBERS_COUNT'] = df[text].progress_apply(lambda x: self.getNumbers(x))
      df[text + '_NUMBERS_PER_LEN'] = df[text + '_NUMBERS_COUNT'].apply(lambda x: x[0]/x[1])
      df[text + '_NUMBERS_COUNT'] = df[text + '_NUMBERS_COUNT'].progress_apply(lambda x: x[0])
      
    return df
  
  def proc_finBERT(self, text):
    """Process parsed data with finBERT"""
    self.tokenizer = BertTokenizer.from_pretrained(self.w_dir + self.model_addr)
    self.model = BertForSequenceClassification.from_pretrained(self.model_addr, num_labels = 3)
    # Switches model to evaluation mode. Not necessary but will speed up code significantly.
    self.model.eval()

    df = self.parsed_df
    print('The processing will be assigned to gpu no. ' + self.get_gpu())
    df[text + "_SENT_BERT"] = df[text].progress_apply(self.bert_sentiment_score)
    print("Aggregating...")
    df[text + "_NUM_SENTENCES"] = df[text + "_SENT_BERT"].apply(lambda x: x[3])
    df[text + "_NEG_SENT_COUNT_BERT"] = df[text + "_SENT_BERT"].apply(lambda x: x[1])
    df[text + "_POS_SENT_COUNT_BERT"] = df[text + "_SENT_BERT"].apply(lambda x: x[2])
    df[text + "_SENT_BERT"] = df[text + "_SENT_BERT"].apply(lambda x: x[0])

    return df
  
  #POSTPROCESSING METHODS
  
  def combine_finBERT(self, fb0df, fb1df, fb2df, fb3df):
    """Merge finBERT outputs"""
    combdf = fb0df
    combdf = combdf.loc[:,~combdf.columns.duplicated()]
    
    dfs = [fb1df, fb2df, fb3df]
    for df in dfs:
      combdf = combdf.merge(df, on = ['EXEC_ANS',
                    'EXEC_DISCUSSION',
                    'CEO_ANS',
                    'CEO_DISCUSSION',
                    'ANALYST_QS',
                    'MGNT_DISCUSSION',
                    'QA_SECTION',
                    'COMPANY_NAME',
                    'EARNINGS_CALL',
                    'TRANSCRIPT_STATUS',
                    'CALL_ID', 
                    'CALL_NAME',
                    'ERROR',
                    'SF_ID',
                    'SF_DATE',
                    'ENTITY_ID', 
                    'DATE'], how = 'inner')
      
    combdf = combdf.drop(['EXEC_ANS',
                    'EXEC_DISCUSSION',
                    'CEO_ANS',
                    'CEO_DISCUSSION',
                    'ANALYST_QS',
                    'MGNT_DISCUSSION',
                    'QA_SECTION',
                    'COMPANY_NAME',
                    'EARNINGS_CALL',
                    'TRANSCRIPT_STATUS',
                    'CALL_ID',
                    'ERROR',
                    'SF_ID',
                    'SF_DATE'], axis = 1)
    
    return combdf

  def combine_all(self, nlpdf, fb0df, fb1df,fb2df, fb3df):
    """Merge nonfinBERT with finBERT outputs"""
    combdf = self.combine_finBERT(fb0df, fb1df,fb2df, fb3df)

    nlpdf = nlpdf.loc[:,~nlpdf.columns.duplicated()]
    nlpdf = nlpdf.drop(['SF_DATE','SF_ID'], axis = 1)
    
    combdf = combdf.merge(nlpdf, on = ['ENTITY_ID','DATE'], how = 'inner')
    combdf = combdf.loc[:,~combdf.columns.duplicated()]

    return combdf
  
  def nan_sum(self, *args):
    if (len(set(np.isnan(list(args)))) > 1) or (not list(set(np.isnan(list(args))))[0]):
      tot = np.nansum(list(args))
    else:
      tot = np.nan

    return tot
  
  def create_aggCols(self, combdf):
    """Generate finBERT features for Mgnt Discussion and QA Section"""
    text = self.aggTexts[0]

    combdf[text + "_NEG_SENT_COUNT_BERT"] = combdf[['CEO_DISCUSSION_NEG_SENT_COUNT_BERT','EXEC_DISCUSSION_NEG_SENT_COUNT_BERT']].apply(lambda x: self.nan_sum(x[0], x[1]), axis = 1)
    combdf[text + "_POS_SENT_COUNT_BERT"] = combdf[['CEO_DISCUSSION_POS_SENT_COUNT_BERT','EXEC_DISCUSSION_POS_SENT_COUNT_BERT']].apply(lambda x: self.nan_sum(x[0], x[1]), axis = 1)                                       
    combdf[text + "_NUM_SENTENCES"] = combdf[['CEO_DISCUSSION_NUM_SENTENCES','EXEC_DISCUSSION_NUM_SENTENCES']].apply(lambda x: self.nan_sum(x[0], x[1]), axis = 1)
    combdf[text + "_SENT_BERT"] = combdf[[text + "_NEG_SENT_COUNT_BERT", text + "_POS_SENT_COUNT_BERT", text + "_NUM_SENTENCES"]].apply(lambda x: (x[1] - x[0])/x[2], axis = 1)

    combdf[text + "_NEG_SENT_COUNT_BERT_PER_SENTENCE"] = combdf[[text + "_NEG_SENT_COUNT_BERT", text + "_NUM_SENTENCES"]].apply(lambda x: x[0]/x[1], axis = 1)
    combdf[text + "_POS_SENT_COUNT_BERT_PER_SENTENCE"] = combdf[[text + "_POS_SENT_COUNT_BERT", text + "_NUM_SENTENCES"]].apply(lambda x: x[0]/x[1], axis = 1)

    text = self.aggTexts[1]

    combdf[text + "_NEG_SENT_COUNT_BERT"] = combdf[['CEO_ANS_NEG_SENT_COUNT_BERT','EXEC_ANS_NEG_SENT_COUNT_BERT', 'ANALYST_QS_NEG_SENT_COUNT_BERT']].apply(lambda x: self.nan_sum(x[0], x[1], x[2]), axis = 1)
    combdf[text + "_POS_SENT_COUNT_BERT"] = combdf[['CEO_ANS_POS_SENT_COUNT_BERT','EXEC_ANS_POS_SENT_COUNT_BERT', 'ANALYST_QS_POS_SENT_COUNT_BERT']].apply(lambda x: self.nan_sum(x[0], x[1], x[2]), axis = 1)                                       
    combdf[text + "_NUM_SENTENCES"] = combdf[['CEO_ANS_NUM_SENTENCES','EXEC_ANS_NUM_SENTENCES', 'ANALYST_QS_NUM_SENTENCES']].apply(lambda x: self.nan_sum(x[0], x[1], x[2]), axis = 1)
    combdf[text + "_SENT_BERT"] = combdf[[text + "_NEG_SENT_COUNT_BERT", text + "_POS_SENT_COUNT_BERT", text + "_NUM_SENTENCES"]].apply(lambda x: (x[1] - x[0])/x[2], axis = 1)

    combdf[text + "_NEG_SENT_COUNT_BERT_PER_SENTENCE"] = combdf[[text + "_NEG_SENT_COUNT_BERT", text + "_NUM_SENTENCES"]].apply(lambda x: x[0]/x[1], axis = 1)
    combdf[text + "_POS_SENT_COUNT_BERT_PER_SENTENCE"] = combdf[[text + "_POS_SENT_COUNT_BERT", text + "_NUM_SENTENCES"]].apply(lambda x: x[0]/x[1], axis = 1)
    
    combdf = combdf[self.outputCols]
    
    combdf['PROCESSED_DATETIME_EASTERN_TZ'] = self.last_parsed_datetime
    
    return combdf