# Databricks notebook source
#sfUtils = sc._jvm.net.snowflake.spark.snowflake.Utils
sc = spark.sparkContext
#sc._jvm.net.snowflake.spark.snowflake.SnowflakeConnectorUtils.enablePushdownSession(sc._jvm.org.apache.spark.sql.SparkSession.builder().getOrCreate())
zone = sc._jvm.java.util.TimeZone
zone.setDefault(sc._jvm.java.util.TimeZone.getTimeZone("UTC"))

# COMMAND ----------

!pip install cryptography

# COMMAND ----------

# MAGIC %sql
# MAGIC SET TIME ZONE 'UTC';
# MAGIC

# COMMAND ----------

import pandas as pd
#import snowflake.connector
#from snowflake.connector.converter_null import SnowflakeNoConverterToPython
#from snowflake.connector import utils
#from snowflake import utils
import base64
import configparser
import logging
from cryptography.fernet import Fernet
from pyspark.sql import functions as F
from pyspark.sql.functions import lit
from pyspark.sql.types import *
import configparser
from cryptography.fernet import Fernet
import urllib


# COMMAND ----------

from dateutil import tz
import pytz
from datetime import date
from datetime import datetime
import pprint
import datetime
import os,sys,csv,urllib,time
from datetime import datetime, date , timedelta , datetime, timezone
from pyspark.sql.functions import col

# COMMAND ----------

# eastern_tzinfo = pytz.timezone("America/New_York")
# load_date_time = utc_to_local(datetime.now(),eastern_tzinfo)
# load_date_prep = load_date_time.date() 
# load_date = load_date_prep.strftime('%Y-%m-%d') 
# print(load_date)

# COMMAND ----------

"""DATABRICKS FILE SYSTEM HELPER CLASS"""


class color:
  """Class to color and modifiy font (colors don't work on databricks but bold and underline do)"""
  PURPLE = '\033[95m'
  CYAN = '\033[96m'
  DARKCYAN = '\033[36m'
  BLUE = '\033[94m'
  GREEN = '\033[92m'
  YELLOW = '\033[93m'
  RED = '\033[91m'
  BOLD = '\033[1m'
  UNDERLINE = '\033[4m'
  END = '\033[0m'   


"""DATABRICKS FILE SYSTEM HELPER CLASS"""


class DBFShelper_sql(color):
  def __init__(self):
    """Functions to interact with Files in Databricks File System (DBFS)."""
    self.myName = self.get_Name()
    self.iniPath = '/FileStore/' + self.myName + '/resources/'
    
  def get_DBFSdir_content(self, folderPath):
    print(folderPath)
    dir_paths = dbutils.fs.ls(folderPath)
    subdir_paths = [self.get_DBFSdir_content(p.path) for p in dir_paths if p.isDir() and p.path != folderPath]
    flat_subdir_paths = [p for subdir in subdir_paths for p in subdir]
    
    return list(map(lambda p: p.path, dir_paths)) + flat_subdir_paths

  def add_DBFSdirectory(self, filePath, newDir):
    """Creates directory in DBFS."""
    dbutils.fs.mkdirs(filePath + newDir)

  def remove_DBFSfile(self, filePath, fileName):
    """Removes file on DBFS."""
    dbutils.fs.rm(filePath + fileName, True)
        
  def read_DBFSfile(self, filePath, fileName):
    """Reads file on DBFS."""
    file_str = ''
    with open('/dbfs' + filePath + fileName, "r") as f_read:
      for line in f_read:
        if line != '\n':
          file_str = file_str + line + '\n'
      print('Current file contents are as follows : ')
      print(file_str)
        
    return file_str
    
  def write_DBFSfile(self, filePath, fileName, contents):
    """Writes file on DBFS."""
    with open('/dbfs' + filePath + fileName, "w") as f_write:
      f_write.write(contents)
      f_write.close()
      
  def get_Name(self):
    dbutils.widgets.text('sql_Name', "")
    y = dbutils.widgets.get('sql_Name')
    
    return y
                      
  def __str__(self):
    """Returns a string with class description"""
    
    return 'This is a class including funtions to interact with Databricks file system.'
  
    
"""AZURE SQL HELPER CLASS"""


class AzureSQLDBhelper(DBFShelper_sql):
  def __init__(self, dbStr, hostStr, portStr, driverStr):
    """Initialize the parameters describing the db object"""
        
    dbutils.widgets.remove("sql_Name")
    self.db = dbStr
    self.driver = driverStr
    self.url = f"jdbc:sqlserver://{hostStr}:{portStr}; databaseName = {dbStr}"
    self.myName = self.get_Name()
    self.iniPath = '/FileStore/' + self.myName + '/resources/'
    self.proc_encryption()
    
  def utc_to_local(self, utc_dt, tz_var):
    return utc_dt.replace(tzinfo=timezone.utc).astimezone(tz=tz_var)
  
  def generate_key(self):
    """generate cred key"""
    self.credKey = Fernet.generate_key()
      
  def encrypt_message(self, message):
    """encrypt message"""
    encoded_message = message.encode()
    f= Fernet(self.credKey)
    encrypted_message = f.encrypt(encoded_message)
    return encrypted_message

  def decrypt_message(self, encrypted_message):
    """decrypt message to use in host system"""
    #key = self.load_key()
    f= Fernet(self.credKey)    
    decrypted_message = f.decrypt(encrypted_message)
    return decrypted_message
  
  def proc_encryption(self):
    """execute entire encryption process involving cred and parameter files"""
    self.generate_key()

    cred_write_config = configparser.RawConfigParser()
    cred_write_config.read("/dbfs/" + self.iniPath + "cred.ini")
    
    db_name_str=str(self.db)
    username=cred_write_config.get(db_name_str,"username")
    password=cred_write_config.get(db_name_str,"password")
    encrypt_username= self.encrypt_message(username)
    encrypt_password= self.encrypt_message(password)
    encrypt_username_string=encrypt_username.decode('utf-8')
    encrypt_password_string=encrypt_password.decode('utf-8')

    self.paramsIni = {"db" : self.db, "username" : self.encrypt_message(username).decode('utf-8'), "password" : self.encrypt_message(password).decode('utf-8')}
    
    myDBFS.remove_DBFSfile(myDBFS.iniPath, 'cred.ini')
  
  def read_from_azure_SQL(self, table):
    """read data from snowflake using encrypted credentials"""
    password_encoded = self.paramsIni["password"].encode('utf-8')
    username_encoded = self.paramsIni["username"].encode('utf-8')
    username_decrypt=self.decrypt_message(username_encoded)
    password_decrypt=self.decrypt_message(password_encoded)
    username=username_decrypt.decode('utf-8')
    password=password_decrypt.decode('utf-8')
      
    options = {
    "url": self.url,
    "user": username,
    "password": password,
    "dbtable": table,
    "trustServerCertificate": "true"  ## Added by Yujing to handle SSL certificate verification issue (switching to 14.3 runtime on 11/20/2024)
    }
    
    df = spark.read \
              .format("jdbc") \
              .options(**options) \
              .load()

    return df

  def query_azure_SQL(self,  query):
    """query data from snowflake using encrypted credentials"""
    password_encoded = self.paramsIni["password"].encode('utf-8')
    username_encoded = self.paramsIni["username"].encode('utf-8')
    username_decrypt = self.decrypt_message(username_encoded)
    password_decrypt = self.decrypt_message(password_encoded)
    username=username_decrypt.decode('utf-8')
    password=password_decrypt.decode('utf-8')
      
    options = {
    "url": self.url,
    "user": username,
    "password": password,
    "query": query,
    "trustServerCertificate": "true" ## Added by Yujing to handle SSL certificate verification issue (switching to 14.3 runtime on 11/20/2024)
    }
    
    df = spark.read \
              .format("jdbc") \
              .options(**options) \
              .load()

    
    return df

  def __str__(self):
    """Returns a string with class description"""
    print("")
    print("This is object is an Azure SQL connection with the following attributes: \n")
    print('url : ' + self.url)
    print('cred file path : ' + self.iniPath)
    print("")
    print('encrypted SF credentials : ')
    pprint.pprint(self.paramsIni)
    print("")
    print('It includes methods to establish, maintain, encrypt and update Azure SQL database credentials.')
    print("")
    print('Also incuded are methods to read Azure SQL tables in the environment for which you have set-up encrypted credentails.')
    return ''