# Databricks notebook source
# MAGIC %md
# MAGIC ## Instruction
# MAGIC CONTEXT DESCRIPTION : Calculate and visualize the sentiment for each fundamentals topic for MASS.  
# MAGIC - Time series line plot  
# MAGIC This part shows that line plot of the 120-day rolling avg sentiment score during specific time range. Within 120 days rolling back window, if one company has several transcripts, we only focus on the latest transcript for each company.
# MAGIC
# MAGIC Reads from: QUANT.PARTHA_FUND_CTS_STG_1_VIEW (historical backfilling only) and QUANT_LIVE.CTS_FUND_COMBINED_SCORES_H
# MAGIC
# MAGIC Writes to: QUANT.YUJING_MASS_FUND_TS_DEV_1
# MAGIC
# MAGIC Recommended cluster: Any Standard D series cluster with 32gb RAM and 8 cores. (14.3 LST runtime)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Load packages

# COMMAND ----------

# MAGIC %run ./../../../data-science-nlp-ml-common-code/impackage/utilities/config_utility

# COMMAND ----------

# MAGIC %run ./../../../data-science-nlp-ml-common-code/impackage/database/snowflake_dbutility

# COMMAND ----------

new_sf = SnowFlakeDBUtility(config.schema, config.eds_db_prod)

# COMMAND ----------

import pandas as pd
import numpy as np
from datetime import datetime
from dateutil.relativedelta import relativedelta
from ast import literal_eval
from collections import Counter
from pyspark.sql.types import *
import warnings
warnings.filterwarnings("ignore")


# COMMAND ----------

# MAGIC %md
# MAGIC ## Connect with SQL database
# MAGIC It has monthly company market cap data

# COMMAND ----------

# MAGIC %run "./../../package_loader/Cloud_DB_module_Azure_SQL_dev_2_Yujing_git.py"

# COMMAND ----------

myDBFS_sql = DBFShelper_sql()
myDBFS_sql.get_DBFSdir_content(myDBFS_sql.iniPath)

# COMMAND ----------

azSQL_LinkUp = pd.read_pickle(r'/dbfs/' + myDBFS_sql.iniPath + 'my_azSQL_LinkUp.pkl')
azSQL_LinkUp.databaseName = 'QNT'
remote_table = azSQL_LinkUp.read_from_azure_SQL("qnt.p_coe.earnings_calls_mapping_table_mcap")
market_cap  = remote_table.toPandas()

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Read Data from Snowflake

# COMMAND ----------

time_series_end_date = datetime.now() 
time_series_start_date = datetime.now() - relativedelta(days=7)
ecall_start_date = datetime.now() - relativedelta(days=150)
time_series_start_date, time_series_end_date, ecall_start_date

# COMMAND ----------

# Read start & end ranges. Note that the range does is NOT inclusive of end month; i.e the range ends at the beginning of the end month
minDateNewQuery = (pd.to_datetime(ecall_start_date)).strftime('%Y-%m-%d')
maxDateNewQuery = (pd.to_datetime(time_series_end_date)).strftime('%Y-%m-%d')
fromDateNewQuery = (pd.to_datetime(time_series_start_date)).strftime('%Y-%m-%d')

mind = "'" + minDateNewQuery + "'"
maxd = "'" + maxDateNewQuery + "'"

print('The next query spans ' + mind + ' to ' + maxd)

# COMMAND ----------

# Query all parsed transcripts parsed after the last known parsed date.
tsQuery= ("SELECT CALL_ID,ENTITY_ID,DATE,CALL_NAME,COMPANY_NAME,EARNINGS_CALL,TRANSCRIPT_STATUS,EVENT_DATETIME_UTC,UPLOAD_DT_UTC,PARSED_DATETIME_EASTERN_TZ, "
                " SENT_FILT_MD,REVENUE_SENT_FILT_MD, "
                " EARNINGS_SENT_FILT_MD, "
                " PROFITABILITY_SENT_FILT_MD, "
                " OPERATING_INCOME_SENT_FILT_MD, "
                " CASH_FLOWS_SENT_FILT_MD, "
                " SHAREHOLDER_RETURNS_SENT_FILT_MD, "
                " CAPITAL_USAGE_SENT_FILT_MD, "
                " GUIDANCE_SENT_FILT_MD,"
                " SENT_FILT_QA, "
                " REVENUE_SENT_FILT_QA, "
                " EARNINGS_SENT_FILT_QA, "
                " PROFITABILITY_SENT_FILT_QA, "
                " OPERATING_INCOME_SENT_FILT_QA, "
                " CASH_FLOWS_SENT_FILT_QA, "
                " SHAREHOLDER_RETURNS_SENT_FILT_QA, "
                " CAPITAL_USAGE_SENT_FILT_QA, "
                " GUIDANCE_SENT_FILT_QA "
    "FROM  EDS_PROD.QUANT_LIVE.CTS_FUND_COMBINED_SCORES_H "
          
   "WHERE DATE >= " + mind  + " AND DATE < " + maxd  + " AND (EARNINGS_CALL > 0) AND (TRANSCRIPT_STATUS = 'CorrectedTranscript');")

resultspkdf = new_sf.read_from_snowflake(tsQuery)

currdf = resultspkdf.toPandas()

if len(currdf)>0:
    print('The data spans from ' + str(currdf['PARSED_DATETIME_EASTERN_TZ'].min()) + ' to ' + str(currdf['PARSED_DATETIME_EASTERN_TZ'].max()) + 'and has ' + str(currdf.shape[0]) + ' rows and ' + str(currdf.shape[1]) + ' columns.')
else:
    print('No new transcripts to parse.')
    dbutils.notebook.exit(1)
    os._exit(1)

# COMMAND ----------

currdf['CALL_ID'].values

# COMMAND ----------

currdf['CALL_ID'] = currdf['CALL_ID'].apply(lambda x: str(x))

# COMMAND ----------

del resultspkdf

# COMMAND ----------

# Keep the earliest version of transcript from the same date.
currdf = currdf.sort_values(['ENTITY_ID', 'DATE','UPLOAD_DT_UTC']).drop_duplicates(['ENTITY_ID', 'DATE'], keep = 'first' )

# COMMAND ----------

currdf['DATE'].values[0]

# COMMAND ----------

currdf

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preprocess Market Cap data

# COMMAND ----------

market_cap = market_cap.sort_values(by=['factset_entity_id','date']).drop_duplicates(['factset_entity_id', 'YearMonth'], keep='last')

# COMMAND ----------

market_cap['YEAR_MONTH'] = pd.to_datetime(market_cap['date'], format='%m/%d/%Y').apply(lambda x: str(x)[:7])
market_cap['MCAP_RANK'] = market_cap.groupby('YEAR_MONTH')['MCAP'].rank(ascending=False, method='first')

# COMMAND ----------

market_cap['biz_group'].unique()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Helper functions

# COMMAND ----------

## Functions to rank companies by different market cap groups
def classify_rank(rank):
  if rank <= 100:
    return '1-Mega firms (top 100)'
  elif rank <= 1000:
    return 'Large firms (top 100 - 1000)'
  else:
    return 'Small firms (1000+)'
  
def classify_rank_C2(rank):
  if rank <= 1000:
    return 'top 1-1000'
  else:
    return 'top 1001-3000'
  
def classify_rank_C3(rank):
  if rank <= 500:
    return 'top 1-500'
  elif rank <= 900:
    return 'top 501-900'
  elif rank <= 1500:
    return 'top 901-1500'
  else:
    return 'top 1501-3000'

def create_plot_df_sentiment(df_raw, start_date, end_date, weight):
  '''
  Create a data frame that contains the sentiment scores for each theme during different time periods.
  
  Input:
    df_raw: the backtest dataframe that contains the sentiment score and topics details for each transcript
    start_date: the start date of the period
    end_date: the end date of the period

  Output:
    df_mean: a dataframe that contains sentiment score for each theme during different time periods

  '''
  
  df = df_raw.copy()
  # Select the data within time range(including the 120 days look-back period before the start date)
  start_date_120days = str(datetime.strptime(start_date,'%Y-%m-%d').date() - relativedelta(days =+ 120))
  startdate = datetime.strptime(start_date_120days, "%Y-%m-%d").date()
  enddate = datetime.strptime(end_date, "%Y-%m-%d").date() 
  time_range = (df['DATE'] > startdate) & (df['DATE'] <= enddate)
  df = df.loc[time_range]
  
  # Select columns
  pre_columns = ['CALL_ID','ENTITY_ID','MCAP','DATE'] 
  df = df[pre_columns + list(df.filter(like = '_' + 'SENT_FILT_').columns)]
  
  df['DATE'] = df['DATE'].apply(lambda x: str(x))
  
  # Calculate the average of MD & QA
  for col in set([i[:-2] for i in df.filter(like = 'SENT').columns]):
    df[col + 'AVERAGE'] = df.filter(regex = col, axis=1).mean(axis=1)

  df_mean = pd.DataFrame()

  # Calculate the 120-day rolling average of latest sentiment score for each company                            
  unique_date = pd.period_range(start = start_date, end = end_date, freq='D').map(str)  
  for d in unique_date:
      tem_range = pd.period_range(end=d, freq='D', periods=120)
      df_rolling = df.loc[df['DATE'].isin(tem_range.map(str))].copy()
      df_rolling = df_rolling.drop_duplicates(subset='ENTITY_ID', keep='last')
      if weight:
        weighted_avg_scores = {}
        for tp in df_rolling.filter(like = 'SENT').columns:
          weighted_avg_scores[tp] = (df_rolling[tp] * df_rolling['MCAP']).sum() / df_rolling['MCAP'].sum()
        weight_sent_df = pd.DataFrame([weighted_avg_scores])
        weight_sent_df['DATE_ROLLING'] = d
        df_mean = df_mean.append(weight_sent_df)
      else:
        series = pd.Series([d],index=['DATE_ROLLING']).append(df_rolling.mean(axis = 0).drop(labels=['CALL_ID', 'MCAP']))
        df_series = pd.DataFrame(series).T
        df_mean = df_mean.append(df_series)
  df_mean = df_mean.dropna(axis=1,how='all').set_index('DATE_ROLLING')
  return df_mean

# Auxiliar functions
def equivalent_type(string, f):
    print(string, f)
    
    if f == 'datetime64[ns]': return TimestampType()
    elif f == 'int64': return LongType()
    elif f == 'int32': return IntegerType()
    elif f == 'float64': return FloatType()
    elif '_SENT_FILT_' in string: return FloatType()
    else: return StringType()

def define_structure(string, format_type):
    typo = equivalent_type(string, format_type)
    print(typo)
    return StructField(string, typo)

# Given pandas dataframe, it will return a spark's dataframe.
def pandas_to_spark(pandas_df):
    columns = list(pandas_df.columns)
    types = list(pandas_df.dtypes)
    struct_list = []
    for column, typo in zip(columns, types): 
      struct_list.append(define_structure(column, typo))
    p_schema = StructType(struct_list)
    return sqlContext.createDataFrame(pandas_df, p_schema)

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC ## Time Series Line Plot

# COMMAND ----------

# MAGIC %md
# MAGIC #### Market Cap Group 1

# COMMAND ----------

market_cap['MCAP_GROUP'] = market_cap['MCAP_RANK'].apply(lambda x: classify_rank(x))
currdf['YEAR_MONTH'] = currdf['DATE'].apply(lambda x: str(x)[:7])
currdf_merge = pd.merge(market_cap[['YEAR_MONTH', 'MCAP_GROUP', 'factset_entity_id','MCAP','biz_group']], currdf,  how='left', left_on=['factset_entity_id','YEAR_MONTH'], right_on = ['ENTITY_ID','YEAR_MONTH'])
currdf_R3K = currdf_merge[~currdf_merge.CALL_ID.isna()]
currdf_R3K_mega = currdf_R3K[currdf_R3K['MCAP_GROUP'] == '1-Mega firms (top 100)' ]
currdf_R3K_large = currdf_R3K[currdf_R3K['MCAP_GROUP'] == 'Large firms (top 100 - 1000)' ]
currdf_R3K_small = currdf_R3K[currdf_R3K['MCAP_GROUP'] == 'Small firms (1000+)' ]

# COMMAND ----------

weights_lst = [True, False]
weights_name = ['MCAP', 'EQUAL']
R3K_dfs = [currdf_R3K, currdf_R3K_mega, currdf_R3K_large, currdf_R3K_small ]
R3K_categories = ['top 1-3000', 'top 1-100', 'top 101-1000', 'top 1001-3000']

sent_df_weights = pd.DataFrame([])
for j, weight in enumerate(weights_lst):
  sent_df_all = pd.DataFrame([])
  for i, df in enumerate(R3K_dfs):
    sent_df = create_plot_df_sentiment(df, 
                start_date = minDateNewQuery, 
                end_date = maxDateNewQuery, 
                weight = weight)
    sent_df.reset_index(inplace=True)
    sent_df['CATEGORY'] = R3K_categories[i]
    sent_df_all = pd.concat([sent_df_all, sent_df])
  sent_df_all['WEIGHT'] = weights_name[j]
  sent_df_weights = pd.concat([sent_df_weights, sent_df_all])

# COMMAND ----------

sent_df_weights[sent_df_weights['DATE_ROLLING'] == fromDateNewQuery]

# COMMAND ----------

# MAGIC %md
# MAGIC #### Market Cap Group 2

# COMMAND ----------

market_cap['MCAP_GROUP'] = market_cap['MCAP_RANK'].apply(lambda x: classify_rank_C2(x))
currdf_merge = pd.merge(market_cap[['YEAR_MONTH', 'MCAP_GROUP', 'factset_entity_id','MCAP','biz_group']], currdf,  how='left', left_on=['factset_entity_id','YEAR_MONTH'], right_on = ['ENTITY_ID','YEAR_MONTH'])
currdf_R3K = currdf_merge[~currdf_merge.CALL_ID.isna()]
currdf_R3K_C2_1 = currdf_R3K[currdf_R3K['MCAP_GROUP'] == 'top 1-1000' ]

# COMMAND ----------

weights_lst = [True, False]
weights_name = ['MCAP', 'EQUAL']
R3K_dfs = [currdf_R3K_C2_1]
R3K_categories = ['top 1-1000']

sent_df_weights_C2 = pd.DataFrame([])
for j, weight in enumerate(weights_lst):
  sent_df_all = pd.DataFrame([])
  for i, df in enumerate(R3K_dfs):
    sent_df = create_plot_df_sentiment(df, 
                start_date = minDateNewQuery, 
                end_date = maxDateNewQuery, 
                weight = weight) 
    sent_df.reset_index(inplace=True)
    sent_df['CATEGORY'] = R3K_categories[i]
    sent_df_all = pd.concat([sent_df_all, sent_df])
  sent_df_all['WEIGHT'] = weights_name[j]
  sent_df_weights_C2 = pd.concat([sent_df_weights_C2, sent_df_all])

# COMMAND ----------

sent_df_weights_C2[sent_df_weights_C2['DATE_ROLLING'] == fromDateNewQuery]

# COMMAND ----------

# MAGIC %md
# MAGIC #### Market Cap Group 3

# COMMAND ----------

market_cap['MCAP_GROUP'] = market_cap['MCAP_RANK'].apply(lambda x: classify_rank_C3(x))
currdf_merge = pd.merge(market_cap[['YEAR_MONTH', 'MCAP_GROUP', 'factset_entity_id','MCAP','biz_group']], currdf,  how='left', left_on=['factset_entity_id','YEAR_MONTH'], right_on = ['ENTITY_ID','YEAR_MONTH'])
currdf_R3K = currdf_merge[~currdf_merge.CALL_ID.isna()]
currdf_R3K_C3_1 = currdf_R3K[currdf_R3K['MCAP_GROUP'] == 'top 1-500' ]
currdf_R3K_C3_2 = currdf_R3K[currdf_R3K['MCAP_GROUP'] == 'top 501-900' ]
currdf_R3K_C3_3 = currdf_R3K[currdf_R3K['MCAP_GROUP'] == 'top 901-1500' ]
currdf_R3K_C3 = currdf_R3K[(currdf_R3K['MCAP_GROUP'] == 'top 1-500')| (currdf_R3K['MCAP_GROUP'] == 'top 501-900')| (currdf_R3K['MCAP_GROUP'] == 'top 901-1500') ]

# COMMAND ----------

weights_lst = [True, False]
weights_name = ['MCAP', 'EQUAL']
R3K_dfs = [currdf_R3K_C3, currdf_R3K_C3_1, currdf_R3K_C3_2, currdf_R3K_C3_3 ]
R3K_categories = ['top 1-1500', 'top 1-500', 'top 501-900', 'top 901-1500']

sent_df_weights_C3 = pd.DataFrame([])
for j, weight in enumerate(weights_lst):
  sent_df_all = pd.DataFrame([])
  for i, df in enumerate(R3K_dfs):
    sent_df = create_plot_df_sentiment(df, 
                start_date = minDateNewQuery, 
                end_date = maxDateNewQuery, 
                weight = weight)
    sent_df.reset_index(inplace=True)
    sent_df['CATEGORY'] = R3K_categories[i]
    sent_df_all = pd.concat([sent_df_all, sent_df])
  sent_df_all['WEIGHT'] = weights_name[j]
  sent_df_weights_C3 = pd.concat([sent_df_weights_C3, sent_df_all])

# COMMAND ----------

sent_df_weights_C3[sent_df_weights_C3['DATE_ROLLING'] == fromDateNewQuery]

# COMMAND ----------

# MAGIC %md
# MAGIC #### Industry Group

# COMMAND ----------

weights_lst = [True, False]
weights_name = ['MCAP', 'EQUAL']

sent_df_weights_gp = pd.DataFrame([]) 
for j, weight in enumerate(weights_lst):
  sent_df_all_gp = pd.DataFrame([])
  for gp in currdf_R3K['biz_group'].unique():
    sent_df_gp = create_plot_df_sentiment(currdf_R3K[currdf_R3K['biz_group'] == gp], 
                    start_date = minDateNewQuery, 
                    end_date = maxDateNewQuery, 
                    weight = weight)
    sent_df_gp.reset_index(inplace=True)
    sent_df_gp['CATEGORY'] = gp
    sent_df_all_gp = pd.concat([sent_df_all_gp, sent_df_gp])
  sent_df_all_gp['WEIGHT'] = weights_name[j]
  sent_df_weights_gp = pd.concat([sent_df_weights_gp, sent_df_all_gp])

# COMMAND ----------

sent_df_weights_gp[sent_df_weights_gp['DATE_ROLLING'] == fromDateNewQuery]

# COMMAND ----------

# MAGIC %md
# MAGIC #### Industry Group (top1500)

# COMMAND ----------

weights_lst = [True, False]
weights_name = ['MCAP', 'EQUAL']

sent_df_weights_gp_top1500 = pd.DataFrame([]) 
for j, weight in enumerate(weights_lst):
  sent_df_all_gp = pd.DataFrame([])
  for gp in currdf_R3K_C3['biz_group'].unique():
    sent_df_gp = create_plot_df_sentiment(currdf_R3K_C3[currdf_R3K_C3['biz_group'] == gp], 
                    start_date = minDateNewQuery, 
                    end_date = maxDateNewQuery, 
                    weight = weight)
    sent_df_gp.reset_index(inplace=True)
    sent_df_gp['CATEGORY'] = 'top 1-1500 | ' + gp
    sent_df_all_gp = pd.concat([sent_df_all_gp, sent_df_gp])
  sent_df_all_gp['WEIGHT'] = weights_name[j]
  sent_df_weights_gp_top1500 = pd.concat([sent_df_weights_gp_top1500, sent_df_all_gp])

# COMMAND ----------

sent_df_weights_gp_top1500

# COMMAND ----------

# MAGIC %md
# MAGIC #### Industry Group (top 500)

# COMMAND ----------

weights_lst = [True, False]
weights_name = ['MCAP', 'EQUAL']

sent_df_weights_gp_top500 = pd.DataFrame([]) 
for j, weight in enumerate(weights_lst):
  sent_df_all_gp = pd.DataFrame([])
  for gp in currdf_R3K_C3_1['biz_group'].unique():
    sent_df_gp = create_plot_df_sentiment(currdf_R3K_C3_1[currdf_R3K_C3_1['biz_group'] == gp], 
                    start_date = minDateNewQuery, 
                    end_date = maxDateNewQuery, 
                    weight = weight)
    sent_df_gp.reset_index(inplace=True)
    sent_df_gp['CATEGORY'] = 'top 1-500 | ' + gp
    sent_df_all_gp = pd.concat([sent_df_all_gp, sent_df_gp])
  sent_df_all_gp['WEIGHT'] = weights_name[j]
  sent_df_weights_gp_top500 = pd.concat([sent_df_weights_gp_top500, sent_df_all_gp])

# COMMAND ----------

sent_df_weights_gp_top500

# COMMAND ----------

# MAGIC %md
# MAGIC #### Combine all the results

# COMMAND ----------

final_sent_df = pd.concat([sent_df_weights, sent_df_weights_C2, sent_df_weights_C3, sent_df_weights_gp, sent_df_weights_gp_top1500, sent_df_weights_gp_top500])
final_sent_df['SENTIMENT'] = 'FINBERT'

# COMMAND ----------

final_sent_df = final_sent_df[(final_sent_df['DATE_ROLLING'] >= fromDateNewQuery) & (final_sent_df['DATE_ROLLING'] < maxDateNewQuery)]

# COMMAND ----------

final_sent_df['DATE_ROLLING'] = pd.to_datetime(final_sent_df['DATE_ROLLING'])

# COMMAND ----------

final_sent_df

# COMMAND ----------

final_sent_df = final_sent_df[['DATE_ROLLING', 'REVENUE_SENT_FILT_MD', 'EARNINGS_SENT_FILT_MD',
       'PROFITABILITY_SENT_FILT_MD', 'OPERATING_INCOME_SENT_FILT_MD',
       'CASH_FLOWS_SENT_FILT_MD', 'SHAREHOLDER_RETURNS_SENT_FILT_MD',
       'CAPITAL_USAGE_SENT_FILT_MD', 'GUIDANCE_SENT_FILT_MD',
       'REVENUE_SENT_FILT_QA', 'EARNINGS_SENT_FILT_QA',
       'PROFITABILITY_SENT_FILT_QA', 'OPERATING_INCOME_SENT_FILT_QA',
       'CASH_FLOWS_SENT_FILT_QA', 'SHAREHOLDER_RETURNS_SENT_FILT_QA',
       'CAPITAL_USAGE_SENT_FILT_QA', 'GUIDANCE_SENT_FILT_QA',
       'PROFITABILITY_SENT_FILT_AVERAGE', 'REVENUE_SENT_FILT_AVERAGE',
       'GUIDANCE_SENT_FILT_AVERAGE', 'EARNINGS_SENT_FILT_AVERAGE',
       'CASH_FLOWS_SENT_FILT_AVERAGE', 'CAPITAL_USAGE_SENT_FILT_AVERAGE',
       'SHAREHOLDER_RETURNS_SENT_FILT_AVERAGE',
       'OPERATING_INCOME_SENT_FILT_AVERAGE', 'CATEGORY', 'WEIGHT',
       'SENTIMENT']]

# COMMAND ----------

final_sent_df

# COMMAND ----------

final_sent_df.to_csv('/dbfs/mnt/access_work/UC25/Topic Modeling/NLI Models/MASS_Fund_time_series_sentiment_R3k_prod_v1_git_' + maxDateNewQuery + '.csv', index = False)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Store time series into Snowflake

# COMMAND ----------

spark_parsedDF = pandas_to_spark(final_sent_df)
spark_parsedDF = spark_parsedDF.replace(np.nan, None)
spark_parsedDF = spark_parsedDF.withColumn("DATE_ROLLING", F.to_timestamp(spark_parsedDF.DATE_ROLLING, 'yyyy-MM-dd'))                                                                      
new_sf.db = 'EDS_PROD'
new_sf.schema = 'QUANT'
 
tablename_curr = 'YUJING_MASS_FUND_TS_DEV_1'
result_curr = new_sf.write_to_snowflake_table(spark_parsedDF, tablename_curr)

# COMMAND ----------

