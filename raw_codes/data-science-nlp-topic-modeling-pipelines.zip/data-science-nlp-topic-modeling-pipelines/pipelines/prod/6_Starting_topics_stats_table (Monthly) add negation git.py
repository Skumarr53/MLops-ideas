# Databricks notebook source
# MAGIC %md
# MAGIC #### QER DTM monthly topic modeling pipeline
# MAGIC This notebook is for dynamic topic modeling pipeline. This notebook is used to update several monthly updated DTM tables.
# MAGIC
# MAGIC Reads from: QUANT.PARTHA_FUND_CTS_STG_1_VIEW (historical backfilling only) and QUANT_LIVE.CTS_FUND_COMBINED_SCORES_H
# MAGIC
# MAGIC Writes to: 
# MAGIC 1. EDS_PROD.QUANT.YUJING_DTM_TP_REL_DEV_2 --> company-level topics relevance score table (It is a very large table and it contains TOTAL and REL related columns)
# MAGIC 2. EDS_PROD.QUANT.YUJING_DTM_TP_REL_SENT_DEV_1 --> company-level topics relevance and sentiment score table
# MAGIC 3. EDS_PROD.QUANT.YUJING_DTM_TP_MONTH_COUNT_DEV_1 --> A table to record how many earnings call we have every month
# MAGIC 4. EDS_PROD.QUANT.YUJING_DTM_TP_STATS_DEV_4 --> A table to record the QoQ and Qo4Q diff, slope, and intercept for topics avg REL, COVERAGE RATE and SENTIMENT
# MAGIC 5. EDS_PROD.QUANT.YUJING_DTM_TP_THEME_DEV_4 --> A table to record the QoQ and Qo4Q diff, slope, and intercept for themes avg REL, COVERAGE RATE and SENTIMENT   
# MAGIC
# MAGIC Match word list: EDS_PROD.QUANT.YUJING_DTM_TP_LST_DEV_1
# MAGIC
# MAGIC Recommended cluster: Any Standard E series cluster with 256gb RAM and 32 cores. (14.3 LTS runtime)
# MAGIC

# COMMAND ----------

pip install spacy==3.5.0 pandas==2.1.1 numpy==1.25.2 tqdm==4.66.1 dask==2023.10.1 distributed==2023.10.1 pyspark==3.5.0

# COMMAND ----------

!pip install https://github.com/explosion/spacy-models/releases/download/en_core_web_sm-3.4.0/en_core_web_sm-3.4.0.tar.gz

# COMMAND ----------

dbutils.library.restartPython() # Must have this line to refresh the environment

# COMMAND ----------

# MAGIC %run ./../../../data-science-nlp-ml-common-code/impackage/utilities/config_utility

# COMMAND ----------

# MAGIC %run ./../../../data-science-nlp-ml-common-code/impackage/database/snowflake_dbutility

# COMMAND ----------

from spacy.lang.en import English
import pandas as pd
import numpy as np
import spacy
import tqdm
from tqdm import tqdm
tqdm.pandas()
from collections import Counter
import dask.dataframe as dd
from dask.distributed import Client
from dask.diagnostics import ProgressBar
from pandas.tseries.offsets import MonthBegin, MonthEnd
from dateutil.relativedelta import relativedelta
from pyspark.sql.types import *
import ast
import gc

client = Client(n_workers=16, threads_per_worker=1)

# COMMAND ----------

new_sf = SnowFlakeDBUtility(config.schema, config.eds_db_prod)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Read Earnings Call data from Snowflake

# COMMAND ----------

# Get the dates for REL table. 
data_end_date = datetime.now().replace(day=1)
data_start_date = datetime.now().replace(day=1) - relativedelta(months=27)
data_last_month = datetime.now().replace(day=1) - relativedelta(months=1)

# COMMAND ----------

data_end_date, data_start_date, data_last_month

# COMMAND ----------

# Record the date range of TN for stats table.
update_end_date = datetime.now().replace(day=1)
update_start_date = datetime.now().replace(day=1) - relativedelta(months=3)

# COMMAND ----------

update_start_date = (pd.to_datetime(format(update_start_date, '%m') + "-01-" + format(update_start_date, '%Y'))).strftime('%Y-%m-%d')
update_end_date = (pd.to_datetime(format(update_end_date, '%m') + "-01-" + format(update_end_date, '%Y'))).strftime('%Y-%m-%d')
print(update_start_date, update_end_date)

# COMMAND ----------

lastDateNewQuery = (pd.to_datetime(format(data_last_month, '%m') + "-01-" + format(data_last_month, '%Y'))).strftime('%Y-%m-%d')
currentDateNewQuery = (pd.to_datetime(format(data_end_date, '%m') + "-01-" + format(data_end_date, '%Y'))).strftime('%Y-%m-%d')

last = "'" + lastDateNewQuery + "'"
current = "'" + currentDateNewQuery + "'"
print(last, current)

# COMMAND ----------

minDateNewQuery = (pd.to_datetime(format(data_start_date, '%m') + "-01-" + format(data_start_date, '%Y'))).strftime('%Y-%m-%d')
maxDateNewQuery = (pd.to_datetime(format(data_end_date, '%m') + "-01-" + format(data_end_date, '%Y'))).strftime('%Y-%m-%d')

mind = "'" + minDateNewQuery + "'"
maxd = "'" + maxDateNewQuery + "'"
print(mind, maxd)

# COMMAND ----------

# Query all parsed transcripts parsed after the last known parsed date.
tsQuery= ("select CALL_ID,ENTITY_ID, DATE, FILT_MD, FILT_QA, CALL_NAME,COMPANY_NAME,EARNINGS_CALL,ERROR,TRANSCRIPT_STATUS,UPLOAD_DT_UTC,VERSION_ID,EVENT_DATETIME_UTC,PARSED_DATETIME_EASTERN_TZ,SENT_LABELS_FILT_MD, SENT_LABELS_FILT_QA from EDS_PROD.QUANT_LIVE.CTS_FUND_COMBINED_SCORES_H t2 "
"WHERE DATE >= " + last + " AND DATE < " + current + " ORDER BY PARSED_DATETIME_EASTERN_TZ DESC;")

resultspkdf = new_sf.read_from_snowflake(tsQuery)

currdf = resultspkdf.toPandas()

if len(currdf)>0:
    print('The data spans from ' + str(currdf['PARSED_DATETIME_EASTERN_TZ'].min()) + ' to ' + str(currdf['PARSED_DATETIME_EASTERN_TZ'].max()) + 'and has ' + str(currdf.shape[0]) + ' rows and ' + str(currdf.shape[1]) + ' columns.')
else:
    print('No new transcripts to parse.')
    dbutils.notebook.exit(1)
    os._exit(1)

# COMMAND ----------

currdf['CALL_ID'] = currdf['CALL_ID'].apply(lambda x: str(x))

# COMMAND ----------

currdf['FILT_MD'] = currdf['FILT_MD'].apply(ast.literal_eval)
currdf['FILT_QA'] = currdf['FILT_QA'].apply(ast.literal_eval)
currdf['SENT_LABELS_FILT_MD'] = currdf['SENT_LABELS_FILT_MD'].apply(ast.literal_eval)
currdf['SENT_LABELS_FILT_QA'] = currdf['SENT_LABELS_FILT_QA'].apply(ast.literal_eval)
currdf['LEN_FILT_MD'] = currdf['FILT_MD'].apply(len)
currdf['LEN_FILT_QA'] = currdf['FILT_QA'].apply(len)


# COMMAND ----------

currdf = currdf.sort_values(by = ['ENTITY_ID', 'DATE','PARSED_DATETIME_EASTERN_TZ']).drop_duplicates(subset = ['ENTITY_ID','DATE'], keep = 'last')

# COMMAND ----------

currdf

# COMMAND ----------

del resultspkdf

# COMMAND ----------

# MAGIC %md
# MAGIC ## Helper functions

# COMMAND ----------

nlp = spacy.load("en_core_web_sm", disable = ['parser'])

# Excluding financially relavant stopwords
nlp.Defaults.stop_words -= {"bottom", "top", "Bottom", "Top", "call", "down"}
nlp.max_length = 1000000000

sections = ['FILT_MD', 'FILT_QA']


# Lemmatizer - for document text
def wordTokenize(doc):
  
  return [ent.lemma_.lower() for ent in nlp(doc) if not ent.is_stop and not ent.is_punct and ent.pos_ != 'NUM']

# Tokenizer/lemmatizer for match words
def matchTokenize(doc):
  ret = []
  for ent in nlp(doc):
    if ent.pos_ == 'PROPN' or ent.text[0].isupper(): #ent.pos_ == 'PROPN' or 
      ret.append(ent.text.lower())
      continue
    if not ent.is_stop and not ent.is_punct and ent.pos_ != 'NUM':
      ret.append(ent.lemma_.lower())
  return ret


# Creates n grams helper fxn
def find_ngrams(input_list, n):
  return zip(*[input_list[i:] for i in range(n)])


def is_valid_keyword(keyword):
  token = nlp(keyword)[0]
  return not (token.is_stop or token.is_punct)

# Create a set of match patterns from match list. This ensures variations such as lemmas & case are handled.
def get_match_set(matches):
  
  bigrams = set([word.lower() for word in matches if len(word.split('_'))==2] + [word.lower().replace(" ", '_') for word in matches if len(word.split(' '))==2] + ['_'.join(matchTokenize(word)) for word in matches if len(word.split(' '))==2])
 
  unigrams = set([matchTokenize(match)[0] for match in matches if ('_' not in match) and (len(match.split(' '))==1) and (len(matchTokenize(match)))] + [match.lower() for match in matches if ('_' not in match) and (len(match.split(' '))==1)])

#  Phrase matching correction
  phrases = [phrase.lower() for phrase in matches if len(phrase.split(" "))>2]
  
  return {'original': matches, 'unigrams': unigrams, 'bigrams': bigrams, 'phrases': phrases}

def match_count_lowStat_negation(texts, match_sets, suppress = None):

  total_counts = {label: [] for label in match_sets.keys()}

  for text in texts:

    text = text.lower()
    unigrams = wordTokenize(text)
    bigrams = ['_'.join(g) for g in find_ngrams(unigrams, 2)]
    
    for label, word_set in match_sets.items():
      if (set(unigrams) & set(word_set['unigrams']) or set(bigrams) & set(word_set['bigrams']) or any(phrase in text for phrase in word_set['phrases'])) and (not any(item in text for item in suppress[label])):
        total_counts[label].append(1)
      else:
        total_counts[label].append(0)
    
  return total_counts

# Used to merge dictionaries that keep track of word counts 
def mergeCount(x):
  
  try:
    merge = Counter(x[0])
 
    for calc in x[1:]:

      merge = merge + Counter(calc)
    if len(merge.keys())==0:
      return {'NO_MATCH': 1}
    return merge
  except:
    return {'ERROR': 1}
  
def sentscore(a, b, weight = True):
  
  # number of relevant sentences
      
  length = len(a)
  if length==0:
      return None
  if length!=len(b):
      return None
  num = len([x for x in a if x>0])
  
  if num==0:
      return None
   
  if weight==True:
    return np.dot(a,b)/num
  else:
    return np.dot([1 if x>0 else 0 for x in a], b)/num

def netscore(a, b):
  
  # number of relevant sentences
      
  length = len(a)
  if length==0:
      return None
  if length!=len(b):
      return None
  num = len([x for x in a if x>0])
  
  if num==0:
      return None
   
  return np.dot([1 if x>0 else 0 for x in a], b)

def sent_all_score(df, tp_sent_md, tp_sent_qa, tp_total_md, tp_total_qa):
  if pd.isna(df[tp_sent_md]) and pd.isna(df[tp_sent_qa]):
    return None
  elif pd.isna(df[tp_sent_md]) and not pd.isna(df[tp_sent_qa]):
    return df[tp_sent_qa]
  elif not pd.isna(df[tp_sent_md]) and pd.isna(df[tp_sent_qa]):
    return df[tp_sent_md]
  else:
    return (df[tp_sent_md] * sum(df[tp_total_md]) + df[tp_sent_qa] * sum(df[tp_total_qa]))/ (sum(df[tp_total_md]) + sum(df[tp_total_qa])) 

def get_period(months_since_start):
  start_month = data_start_date + MonthBegin() * (months_since_start * 3)
  end_month = start_month + MonthEnd(3)
  return f"{start_month.strftime('%Y/%m')} - {end_month.strftime('%Y/%m')}"
  
def equivalent_type(string, f):
    print(string, f)
    
    if f == 'datetime64[ns]': return TimestampType()
    elif f == 'int64': return LongType()
    elif f == 'int32': return IntegerType()
    elif f == 'float64': return FloatType()
    elif string == 'FILT_MD': return ArrayType(StringType())
    elif string == 'FILT_QA': return ArrayType(StringType())
    elif 'total_filt' in string.lower(): return ArrayType(IntegerType())
    elif 'sent_labels' in string.lower(): return ArrayType(IntegerType())
    elif 'TOP60_KEYWORDS_COSINE' == string: return ArrayType(StructType([StructField('word', StringType(), True), StructField('score', FloatType(), True)]))
    elif 'KEYWORDS' == string: return ArrayType(StringType())
    else: return StringType()

def define_structure(string, format_type):
    typo = equivalent_type(string, format_type)
    print(typo)
    return StructField(string, typo)

# Given pandas dataframe, it will return a spark's dataframe.
def pandas_to_spark(pandas_df):
    columns = list(pandas_df.columns)
    types = list(pandas_df.dtypes)
    struct_list = []
    for column, typo in zip(columns, types): 
      struct_list.append(define_structure(column, typo))
    p_schema = StructType(struct_list)
    return sqlContext.createDataFrame(pandas_df, p_schema)

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Load DTM keywords dictionary
# MAGIC Directly load the keywords dictionary from Snowflake

# COMMAND ----------

tsQuery= ("select * from EDS_PROD.QUANT.YUJING_DTM_TP_LST_DEV_1; ")

resultspkdf = new_sf.read_from_snowflake(tsQuery)

labeled_m1_df = resultspkdf.toPandas()

# COMMAND ----------

labeled_m1_df['TOP60_KEYWORDS_COSINE'] = labeled_m1_df['TOP60_KEYWORDS_COSINE'].apply(ast.literal_eval)
labeled_m1_df['KEYWORDS'] = labeled_m1_df['KEYWORDS'].apply(ast.literal_eval)
labeled_m1_df['TOP60_KEYWORDS_COSINE'] = labeled_m1_df['TOP60_KEYWORDS_COSINE'].apply(lambda x: [(item['word'], item['score']) for item in x])
labeled_m1_df['TOPIC_ID'] = labeled_m1_df['TOPIC_ID'].apply(lambda x: int(x))
labeled_m1_df = labeled_m1_df.sort_values(by=['TOPIC_ID'])
labeled_m1_df.reset_index(drop=True, inplace=True)
labeled_m1_df['NEGATION'] = labeled_m1_df['NEGATION'].apply(lambda x: ast.literal_eval(x) if pd.notna(x) else x)
labeled_m1_df = labeled_m1_df[labeled_m1_df['INCLUDED'] == 1]

# COMMAND ----------

# labeled_m1_df.to_csv('/dbfs/mnt/access_work/UC25/Topic Modeling/DTM Phase2/pipeline_results/DATM_topic_list_05_16_2024.csv', index=False)

# COMMAND ----------

# Load keywords for each topic
m1_keywords_df = pd.DataFrame([])
m1_keywords_df['Topic_name'] = labeled_m1_df['TOPIC_NAME']
m1_keywords_df['Topic_keywords'] = labeled_m1_df.apply(lambda x: [w for w, cos in x['TOP60_KEYWORDS_COSINE'][:25]] if '**' not in x['L2_THEME'] else [w for w, cos in x['TOP60_KEYWORDS_COSINE']], axis=1)
match_df = m1_keywords_df.explode('Topic_keywords')
match_df['negate'] = False

# COMMAND ----------

# Load negation words for each topic
neg_keywords_df = pd.DataFrame([])
neg_keywords_df['Topic_name'] = labeled_m1_df['TOPIC_NAME']
neg_keywords_df['Topic_keywords'] = labeled_m1_df['NEGATION']
neg_keywords_df1 = neg_keywords_df.explode('Topic_keywords')
neg_keywords_df1['negate'] = True
neg_keywords_df1.dropna(inplace=True)

# COMMAND ----------

match_df = pd.concat([match_df, neg_keywords_df1])

# COMMAND ----------

match_df = match_df.rename(columns={'Topic_name':'label','Topic_keywords':'match'})

# COMMAND ----------

match_df

# COMMAND ----------

# Since we got the keywords with unsupervised learning, we need to clean the data
match_df = match_df[~match_df['match'].str.isnumeric()]
match_df = match_df[match_df['match'].apply(is_valid_keyword)]

# COMMAND ----------

match_df

# COMMAND ----------

# Read match list
word_set_dict = {topic: get_match_set(match_df[(match_df['label']==topic) & (match_df['negate']==False)]['match'].values) for topic in match_df['label'].unique()}

negate_dict = {topic: [word.lower() for word in match_df[(match_df['label']==topic) & (match_df['negate']==True)]['match'].values.tolist()] for topic in match_df['label'].unique()}

# COMMAND ----------

word_set_dict

# COMMAND ----------

negate_dict1 = {k: [] for k in negate_dict.keys()}
for k, v in negate_dict.items():
  for word in v:
    if len(word.split('_'))==2:
      new_word = ' '.join(word.split('_'))
      negate_dict1[k].append(new_word)
    else:
      negate_dict1[k].append(word)

# COMMAND ----------

negate_dict1

# COMMAND ----------

# MAGIC %md
# MAGIC ## Generate topic REL related metrics
# MAGIC Calculate the relevance score for all the unsupervised topics in last month

# COMMAND ----------

currdf_test = currdf

# COMMAND ----------

currdf_test = dd.from_pandas(currdf_test, npartitions = 32)
for label, section in {'FILT_MD': 'FILT_MD', 'FILT_QA': 'FILT_QA'}.items():

  currdf_test['new_matches_' + label] = currdf_test[section].apply(lambda x: match_count_lowStat_negation(x, word_set_dict, suppress=negate_dict1), meta = ('new_matches_' + label, object))

# COMMAND ----------

gc.collect()

# COMMAND ----------

# Running Dask compute
#%%time
with ProgressBar():
  currdf_test = currdf_test.compute()

# COMMAND ----------

# Dask is not used for below code due to unfixable bugs
# Below code only used to aggregate stats and organize data

#%%time
for label, section in {'FILT_MD': 'MGNT_DISCUSSION', 'FILT_QA': 'QA_SECTION'}.items():
  
  for topic in word_set_dict.keys():
    currdf_test[topic + '_TOTAL_' + label] = currdf_test['new_matches_' + label].apply(lambda x: x[topic])

  currdf_test.drop(['new_matches_' + label], axis = 1, inplace = True)
  # gc.collect()
  

# COMMAND ----------

for label, section in {'FILT_MD': 'MGNT_DISCUSSION', 'FILT_QA': 'QA_SECTION'}.items():
  for topic in word_set_dict.keys():
  
  # relevance = #sentences detected with topic / #total sentences
    currdf_test[topic + '_REL_' + label] = currdf_test.apply(lambda x: sum(x[topic + '_TOTAL_' + label])/x['LEN_' + label] if x['LEN_' + label]>0 else None, axis = 1)
       

# COMMAND ----------

currdf_test['LEN_' + 'ALL'] = currdf_test.apply(lambda x: x['LEN_' + 'FILT_MD'] + x['LEN_' + 'FILT_QA'], axis = 1)    

# COMMAND ----------

# Calculate the REL for the whole transcript
for topic in word_set_dict.keys(): 
  currdf_test[topic + '_REL_' + 'ALL'] = currdf_test.apply(lambda x: (x[topic + '_REL_' + 'FILT_MD'] * x['LEN_' + 'FILT_MD'] + x[topic + '_REL_' + 'FILT_QA'] * x['LEN_' + 'FILT_QA'])/ x['LEN_' + 'ALL'] if x['LEN_' + 'ALL'] > 0 else None, axis = 1)


# COMMAND ----------

currdf_test

# COMMAND ----------

currdf_month = currdf_test.copy()
currdf_month.DATE = pd.to_datetime(currdf_month.DATE)

# COMMAND ----------

# Change the column name to a shorter version
new_column_name = []
for col in currdf_month.columns:
  if " | " in col:
    new_column_name.append('TP' + col.split(' | ')[-1])
  else:
    new_column_name.append(col)

# COMMAND ----------

currdf_month.columns = new_column_name

# COMMAND ----------

currdf_month

# COMMAND ----------

## Read REL table from snowflake (to get the column order)
tsQuery= ("select top 2 * from EDS_PROD.QUANT.YUJING_DTM_TP_REL_DEV_2; ")

resultspkdf = new_sf.read_from_snowflake(tsQuery)

sample_rel_table = resultspkdf.toPandas()

# COMMAND ----------

currdf_month[sample_rel_table.columns]

# COMMAND ----------

spark_parsedDF = pandas_to_spark(currdf_month[sample_rel_table.columns])
spark_parsedDF = spark_parsedDF.replace(np.nan, None)
spark_parsedDF = spark_parsedDF.withColumn("DATE", F.to_timestamp(spark_parsedDF.DATE, 'yyyy-MM-dd'))
spark_parsedDF = spark_parsedDF.withColumn("UPLOAD_DT_UTC", F.to_timestamp(spark_parsedDF.UPLOAD_DT_UTC, 'yyyy-MM-dd HH mm ss'))
spark_parsedDF = spark_parsedDF.withColumn("EVENT_DATETIME_UTC", F.to_timestamp(spark_parsedDF.EVENT_DATETIME_UTC, 'yyyy-MM-dd HH mm ss'))         
spark_parsedDF = spark_parsedDF.withColumn("PARSED_DATETIME_EASTERN_TZ", F.to_timestamp(spark_parsedDF.PARSED_DATETIME_EASTERN_TZ, 'yyyy-MM-dd HH mm ss'))
new_sf.db = 'EDS_PROD'
new_sf.schema = 'QUANT'
 
tablename_curr = 'YUJING_DTM_TP_REL_DEV_2'
result_curr = new_sf.write_to_snowflake_table(spark_parsedDF, tablename_curr)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Generate topic SENT related metrics
# MAGIC Calculate the sentiment score for each unsupervised topic in last month as well. 

# COMMAND ----------

currdf_month = currdf_month[sample_rel_table.columns]

# COMMAND ----------

# Add sentiment scores
topic_names = []
for col in currdf_month.columns:
  if '_TOTAL_' in (col) and '_MD' in (col):
    topic_names.append(col.split('_')[0])

# COMMAND ----------

for label, section in {'FILT_MD': 'MGNT_DISCUSSION', 'FILT_QA': 'QA_SECTION'}.items():
  
  for topic in topic_names:
    currdf_month[topic + '_SENT_' + label] = currdf_month[[topic + '_TOTAL_' + label, 'SENT_LABELS_' + label]].apply(lambda x: sentscore(x[0], x[1], weight = False), axis = 1)

# COMMAND ----------

for topic in topic_names:
  currdf_month[topic + '_SENT_' + 'ALL'] = currdf_month.apply(lambda x: sent_all_score(x, topic + '_SENT_FILT_MD', topic + '_SENT_FILT_QA', topic + '_TOTAL_FILT_MD', topic + '_TOTAL_FILT_QA'), axis = 1)

# COMMAND ----------

included_columns = ['CALL_ID',	'ENTITY_ID',	'DATE',	'CALL_NAME',	'COMPANY_NAME',	'EARNINGS_CALL',	'ERROR',	'TRANSCRIPT_STATUS',	'UPLOAD_DT_UTC',	'VERSION_ID',	'EVENT_DATETIME_UTC',	'PARSED_DATETIME_EASTERN_TZ',	'LEN_FILT_MD',	'LEN_FILT_QA']

# COMMAND ----------

rel_sent_columns = []
for col in currdf_month.columns:
  if '_SENT_ALL' in col or '_REL_ALL' in col:
    rel_sent_columns.append(col)

# COMMAND ----------

sf_df = currdf_month[included_columns + rel_sent_columns]

# COMMAND ----------

sf_df

# COMMAND ----------

## Read REL_SENT table from snowflake (to get the column order)
tsQuery= ("select top 2 * from EDS_PROD.QUANT.YUJING_DTM_TP_REL_SENT_DEV_1; ")

resultspkdf = new_sf.read_from_snowflake(tsQuery)

sample_rel_sent_table = resultspkdf.toPandas()

# COMMAND ----------

sf_df[sample_rel_sent_table.columns]

# COMMAND ----------

spark_parsedDF = pandas_to_spark(sf_df[sample_rel_sent_table.columns])
spark_parsedDF = spark_parsedDF.replace(np.nan, None)
spark_parsedDF = spark_parsedDF.withColumn("DATE", F.to_timestamp(spark_parsedDF.DATE, 'yyyy-MM-dd'))
spark_parsedDF = spark_parsedDF.withColumn("UPLOAD_DT_UTC", F.to_timestamp(spark_parsedDF.UPLOAD_DT_UTC, 'yyyy-MM-dd HH mm ss'))
spark_parsedDF = spark_parsedDF.withColumn("EVENT_DATETIME_UTC", F.to_timestamp(spark_parsedDF.EVENT_DATETIME_UTC, 'yyyy-MM-dd HH mm ss'))         
spark_parsedDF = spark_parsedDF.withColumn("PARSED_DATETIME_EASTERN_TZ", F.to_timestamp(spark_parsedDF.PARSED_DATETIME_EASTERN_TZ, 'yyyy-MM-dd HH mm ss'))
new_sf.db = 'EDS_PROD'
new_sf.schema = 'QUANT'
 
tablename_curr = 'YUJING_DTM_TP_REL_SENT_DEV_1'
result_curr = new_sf.write_to_snowflake_table(spark_parsedDF, tablename_curr)

# COMMAND ----------

sf_df = sf_df[sample_rel_sent_table.columns]

# COMMAND ----------

# MAGIC %md
# MAGIC ## Read recent 9-quarter topic REL_SENT data
# MAGIC Read the recent 9-quarter relevance score and sentiment score data to calculate the QoQ and Qo4Q relevance score and sentiment score changes.

# COMMAND ----------

# Query all parsed transcripts parsed after the last known parsed date.
tsQuery= ("select * from EDS_PROD.QUANT.YUJING_DTM_TP_REL_SENT_DEV_1 "
"WHERE DATE >= " + mind + " AND DATE < " + maxd + " ORDER BY PARSED_DATETIME_EASTERN_TZ DESC;")

resultspkdf = new_sf.read_from_snowflake(tsQuery)

currdf_test = resultspkdf.toPandas()


print('The data spans from ' + str(currdf_test['DATE'].min()) + ' to ' + str(currdf_test['DATE'].max()) + 'and has ' + str(currdf_test.shape[0]) + ' rows and ' + str(currdf_test.shape[1]) + ' columns.')

# COMMAND ----------

currdf_test.head()

# COMMAND ----------

print('The data spans from ' + str(currdf_test['DATE'].min()) + ' to ' + str(currdf_test['DATE'].max()) + 'and has ' + str(currdf_test.shape[0]) + ' rows and ' + str(currdf_test.shape[1]) + ' columns.')

# COMMAND ----------

# data_start_date has to be the first day of the month
data_start_date 

# COMMAND ----------

data_start_date + MonthBegin() * 3

# COMMAND ----------

# Create 'formatted_period' column to record data for the 3-month period it falls into. 'formatted_period' follows yyyy/mm-yyyy/mm format where includes 3 months.
start_date = currdf_test['DATE'].min()
currdf_test['period_index'] = ((pd.to_datetime(currdf_test['DATE'], format='%Y-%m-%d').dt.year - start_date.year) * 12 + pd.to_datetime(currdf_test['DATE'], format='%Y-%m-%d').dt.month - start_date.month)
currdf_test['period'] = np.floor(currdf_test['period_index'] / 3)
currdf_test['formatted_period'] = currdf_test['period'].apply(lambda x: get_period(int(x)))

# COMMAND ----------

currdf_test[['DATE', 'formatted_period']]['formatted_period'].unique()

# COMMAND ----------

# Use level2|level1|topic_id to rename columns
new_columns_name = []
for col in currdf_test.columns:
  if '_REL_ALL' in col or '_SENT_ALL' in col:
    new_columns_name.append('_'.join([labeled_m1_df[labeled_m1_df['TOPIC_ID'] == int(col.split('_')[0][2:])]['TOPIC_NAME'].values[0]] + col.split('_')[1:]))
  else:
    new_columns_name.append(col)

# COMMAND ----------

currdf_test.columns = new_columns_name

# COMMAND ----------

currdf_test

# COMMAND ----------

# MAGIC %md
# MAGIC ## Calculate stats metrics for REL and SENT columns

# COMMAND ----------

# Calculate the average REL and SENT for each topic in each quarter
stats_df = pd.DataFrame([])
stats_sent_df = pd.DataFrame([])
for topic in word_set_dict.keys(): 
   stats_df[topic + '_REL'] = currdf_test.groupby('formatted_period')[topic + '_REL_' + 'ALL'].mean(numeric_only=False).to_frame()
   stats_sent_df[topic + '_SENT'] = currdf_test.groupby('formatted_period')[topic + '_SENT_' + 'ALL'].mean(numeric_only=False).to_frame()

# COMMAND ----------

stats_df

# COMMAND ----------

stats_sent_df

# COMMAND ----------

# Record the num. of earnings call in each period.
currdf_test['year-month'] = pd.to_datetime(currdf_test['DATE'], format='%Y-%m-%d').dt.to_period('M')
month_count = pd.DataFrame({'count': currdf_test.groupby(['formatted_period', 'year-month']).size()}).reset_index()

# COMMAND ----------

# Get the num. of earnings call in last month
month_count['month_start'] = pd.to_datetime(month_count['year-month'].dt.strftime('%Y-%m-01'))
month_count.drop(columns= ['formatted_period'], inplace=True)
month_count.rename(columns = {'year-month':'year_month'}, inplace=True)
month_count['year_month'] = month_count['year_month'].apply(str)
month_count1 = month_count.tail(1)

# COMMAND ----------

month_count1

# COMMAND ----------

spark_parsedDF = pandas_to_spark(month_count1)
spark_parsedDF = spark_parsedDF.replace(np.nan, None)
spark_parsedDF = spark_parsedDF.withColumn("month_start", F.to_timestamp(spark_parsedDF.month_start, 'yyyy-MM-dd'))
new_sf.db = 'EDS_PROD'
new_sf.schema = 'QUANT'
 
tablename_curr = 'YUJING_DTM_TP_MONTH_COUNT_DEV_1'
result_curr = new_sf.write_to_snowflake_table(spark_parsedDF, tablename_curr)

# COMMAND ----------

stats_df

# COMMAND ----------

# REL CODE
plot_df = stats_df.reset_index()
stats_df = stats_df.T.reset_index()
stats_df.columns = [str(c) for c in stats_df.columns]

# COMMAND ----------

#SENT CODE
plot_sent_df = stats_sent_df.reset_index()
stats_sent_df = stats_sent_df.T.reset_index()
stats_sent_df.columns = [str(c) for c in stats_sent_df.columns]

# COMMAND ----------

stats_df

# COMMAND ----------

stats_sent_df

# COMMAND ----------

# MAGIC %md
# MAGIC #### Qo4Q diff

# COMMAND ----------

# Create table with Qo4Q avg relevance score diff (for relevance score, we are using % diff)
yoy_stats_df = pd.DataFrame() 
periods = list(stats_df.columns[-5:])
for p in periods:
  prev_p = str(int(p[:4]) - 1) + p[4:10] + str(int(p[10:14]) - 1) + p[14:]
  if prev_p in stats_df:
    yoy_stats_df[p +'/' + prev_p] = (stats_df[p] - stats_df[prev_p]) / stats_df[prev_p]
  else:
    pass

# COMMAND ----------

# Create table with Qo4Q avg sentiment score diff (for sentiment score, we are using absolute diff)
yoy_stats_sent_df = pd.DataFrame() 
periods = list(stats_sent_df.columns[-5:])
for p in periods:
  prev_p = str(int(p[:4]) - 1) + p[4:10] + str(int(p[10:14]) - 1) + p[14:]
  if prev_p in stats_sent_df:
      yoy_stats_sent_df[p +'/' + prev_p] = stats_sent_df.apply(lambda x: x[p] - x[prev_p], axis=1)
  else:
    pass

# COMMAND ----------

yoy_stats_df

# COMMAND ----------

yoy_stats_sent_df

# COMMAND ----------

# MAGIC %md
# MAGIC #### Qo4Q slope and intercept

# COMMAND ----------

yoy_plot_df = yoy_stats_df.T.reset_index()

# COMMAND ----------

yoy_plot_sent_df = yoy_stats_sent_df.T.reset_index()

# COMMAND ----------

# Slope and intercept for Qo4Q REL changes
yoy_plot_concat_norm_df = yoy_plot_df.iloc[:,1:].clip(lower = -1, upper = 1) # Keep the Qo4Q diff within -1 to 1.
yoy_slope_df = pd.DataFrame(list(word_set_dict.keys()), columns = ['Topic'])
for periods in [5]:
  slope_dic = {}
  intercept_dic = {}
  for col in yoy_plot_concat_norm_df.columns:
    # Time variable (X) is [-2, -1, 0, 1, 2]. Intercept shows the estimated Qo4Q change at time 0 which is the middle of time variable.
    slope_dic[col] = np.polyfit(np.arange(periods) - 2, yoy_plot_concat_norm_df[col][-1 * periods:],1)[0]  
    intercept_dic[col] = np.polyfit(np.arange(periods) - 2, yoy_plot_concat_norm_df[col][-1 * periods:],1)[1]
  yoy_slope_df[str(periods) + '-quarter slope (Qo4Q)'] = slope_dic.values() 
  yoy_slope_df[str(periods) + '-quarter intercept (Qo4Q)'] = intercept_dic.values()   

# COMMAND ----------

yoy_stats_df['Topic'] = stats_df['index']

# COMMAND ----------

# Slope and intercept for Qo4Q SENT changes
yoy_plot_concat_norm_sent_df = yoy_plot_sent_df.iloc[:,1:] 
yoy_slope_sent_df = pd.DataFrame(list(word_set_dict.keys()), columns = ['Topic'])
for periods in [5]:
  slope_dic = {}
  intercept_dic = {}
  for col in yoy_plot_concat_norm_sent_df.columns:
    # Time variable (X) is [-2, -1, 0, 1, 2]. Intercept shows the estimated Qo4Q change at time 0 which is the middle of time variable.
    slope_dic[col] = np.polyfit(np.arange(periods) - 2, yoy_plot_concat_norm_sent_df[col][-1 * periods:],1)[0]  
    intercept_dic[col] = np.polyfit(np.arange(periods) - 2, yoy_plot_concat_norm_sent_df[col][-1 * periods:],1)[1]
  yoy_slope_sent_df[str(periods) + '-quarter slope (Qo4Q)'] = slope_dic.values() 
  yoy_slope_sent_df[str(periods) + '-quarter intercept (Qo4Q)'] = intercept_dic.values()   

# COMMAND ----------

yoy_stats_sent_df['Topic'] = stats_sent_df['index']

# COMMAND ----------

yoy_stats_sent_df

# COMMAND ----------

# MAGIC %md
# MAGIC #### MA (Moving average) slope and intercept

# COMMAND ----------

ma_stats_df = pd.DataFrame()
period_columns = stats_df.columns[1:]
for column in period_columns:
  ma_stats_df[column +'_ma'] = stats_df[stats_df.columns[1:]].rolling(window=4, min_periods=1, axis=1).mean()[column]

# COMMAND ----------

ma_stats_sent_df = pd.DataFrame()
period_sent_columns = stats_sent_df.columns[1:]
for column in period_sent_columns:
  ma_stats_sent_df[column +'_ma'] = stats_sent_df[stats_sent_df.columns[1:]].rolling(window=4, min_periods=1, axis=1).mean()[column]

# COMMAND ----------

ma_plot_df = ma_stats_df[ma_stats_df.columns[4:]].T.reset_index()

# COMMAND ----------

ma_plot_sent_df = ma_stats_sent_df[ma_stats_sent_df.columns[4:]].T.reset_index()

# COMMAND ----------

# MA REL slope and intercept
ma_plot_concat_norm_df = ma_plot_df.iloc[:,1:].apply(lambda x: x/x.sum(), axis = 0)
ma_slope_df = pd.DataFrame(list(word_set_dict.keys()), columns = ['Topic'])
for periods in [5]:
  slope_dic = {}
  intercept_dic = {}
  for col in ma_plot_concat_norm_df.columns:
    slope_dic[col] = np.polyfit(np.arange(periods), ma_plot_concat_norm_df[col][-1 * periods:],1)[0]  #
    intercept_dic[col] = np.polyfit(np.arange(periods), ma_plot_concat_norm_df[col][-1 * periods:],1)[1]
  ma_slope_df[str(periods) + '-quarter slope (MA)'] = slope_dic.values() 
  ma_slope_df[str(periods) + '-quarter intercept (MA)'] = intercept_dic.values()   

# COMMAND ----------

# MA SENT slope and intercept
ma_plot_concat_norm_sent_df = ma_plot_sent_df.iloc[:,1:]
ma_slope_sent_df = pd.DataFrame(list(word_set_dict.keys()), columns = ['Topic'])
for periods in [5]:
  slope_dic = {}
  intercept_dic = {}
  for col in ma_plot_concat_norm_sent_df.columns:
    slope_dic[col] = np.polyfit(np.arange(periods), ma_plot_concat_norm_sent_df[col][-1 * periods:],1)[0]  #
    intercept_dic[col] = np.polyfit(np.arange(periods), ma_plot_concat_norm_sent_df[col][-1 * periods:],1)[1]
  ma_slope_sent_df[str(periods) + '-quarter slope (MA)'] = slope_dic.values() 
  ma_slope_sent_df[str(periods) + '-quarter intercept (MA)'] = intercept_dic.values()   

# COMMAND ----------

ma_slope_df.sort_values(by=['5-quarter slope (MA)']).tail(15)

# COMMAND ----------

ma_slope_sent_df.sort_values(by=['5-quarter slope (MA)']).head(15)

# COMMAND ----------

ma_slope_sent_df.sort_values(by=['5-quarter slope (MA)']).tail(15)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Slope and Intercept

# COMMAND ----------

# Only need recent 5-quarter data to calculate the slope and intercept
stats_df = stats_df.drop(columns=stats_df.columns[1:5])  

# COMMAND ----------

stats_sent_df = stats_sent_df.drop(columns=stats_sent_df.columns[1:5]) 

# COMMAND ----------

stats_df

# COMMAND ----------

stats_sent_df

# COMMAND ----------

plot_concat_norm_df = plot_df.loc[4:,:].iloc[:,1:].apply(lambda x: x/x.sum(), axis = 0)
slope_df = pd.DataFrame(list(word_set_dict.keys()), columns = ['Topic'])
for periods in [5]:
  slope_dic = {}
  for col in plot_concat_norm_df.columns:
    slope_dic[col] = np.polyfit(np.arange(periods), plot_concat_norm_df[col][-1 * periods:],1)[0]
  slope_df[str(periods) + '-quarter slope'] = slope_dic.values()  

# COMMAND ----------

plot_concat_norm_sent_df = plot_sent_df.loc[4:,:].iloc[:,1:]
slope_sent_df = pd.DataFrame(list(word_set_dict.keys()), columns = ['Topic'])
for periods in [5]:
  slope_dic = {}
  for col in plot_concat_norm_sent_df.columns:
    slope_dic[col] = np.polyfit(np.arange(periods), plot_concat_norm_sent_df[col][-1 * periods:],1)[0]
  slope_sent_df[str(periods) + '-quarter slope'] = slope_dic.values()  

# COMMAND ----------

slope_df.sort_values('5-quarter slope')

# COMMAND ----------

slope_sent_df.sort_values('5-quarter slope').tail(20)

# COMMAND ----------

slope_df

# COMMAND ----------

# MAGIC %md
# MAGIC #### Coverage rate

# COMMAND ----------

currdf_test.DATE = pd.to_datetime(currdf_test.DATE)

# COMMAND ----------

current_date = datetime.strptime(maxDateNewQuery, '%Y-%m-%d')

# COMMAND ----------

date_1q = (current_date - relativedelta(months=3)).strftime('%Y-%m-%d')
date_2q = (current_date - relativedelta(months=6)).strftime('%Y-%m-%d')
date_3q = (current_date - relativedelta(months=9)).strftime('%Y-%m-%d')
date_4q = (current_date - relativedelta(months=12)).strftime('%Y-%m-%d')
date_5q = (current_date - relativedelta(months=15)).strftime('%Y-%m-%d')

# COMMAND ----------

# Calculate the company coverage rate
out_test1 = currdf_test.loc[(currdf_test.DATE >= date_1q) & (currdf_test.DATE < maxDateNewQuery), :]
out_test1 = out_test1.sort_values(by=['DATE']).drop_duplicates(subset='ENTITY_ID', keep='last').copy()
coverage_df = pd.DataFrame(list(word_set_dict.keys()), columns = ['Topic'])
coverage_df['COVERAGE_RATE_TN_0'] = coverage_df['Topic'].apply(lambda x: sum([ 1 for i in out_test1[x+'_REL_ALL'] if i > 0])/len(out_test1))

# COMMAND ----------

# Calculate the company coverage rate (1-quarter ago)
out_test2 = currdf_test.loc[(currdf_test.DATE >= date_2q) & (currdf_test.DATE < date_1q), :]
out_test2 = out_test2.sort_values(by=['DATE']).drop_duplicates(subset='ENTITY_ID', keep='last').copy()
coverage_df['COVERAGE_RATE_TN_1'] = coverage_df['Topic'].apply(lambda x: sum([ 1 for i in out_test2[x+'_REL_ALL'] if i > 0])/len(out_test2))

# COMMAND ----------

# Calculate the company coverage rate (2-quarter ago)
out_test3 = currdf_test.loc[(currdf_test.DATE >= date_3q) & (currdf_test.DATE < date_2q), :]
out_test3 = out_test3.sort_values(by=['DATE']).drop_duplicates(subset='ENTITY_ID', keep='last').copy()
coverage_df['COVERAGE_RATE_TN_2'] = coverage_df['Topic'].apply(lambda x: sum([ 1 for i in out_test3[x+'_REL_ALL'] if i > 0])/len(out_test3))

# COMMAND ----------

# Calculate the company coverage rate (3-quarter ago)
out_test4 = currdf_test.loc[(currdf_test.DATE >= date_4q) & (currdf_test.DATE < date_3q), :]
out_test4 = out_test4.sort_values(by=['DATE']).drop_duplicates(subset='ENTITY_ID', keep='last').copy()
coverage_df['COVERAGE_RATE_TN_3'] = coverage_df['Topic'].apply(lambda x: sum([ 1 for i in out_test4[x+'_REL_ALL'] if i > 0])/len(out_test4))

# COMMAND ----------

# Calculate the company coverage rate (12 months ago)
out_test5 = currdf_test.loc[(currdf_test.DATE >= date_5q) & (currdf_test.DATE < date_4q), :]
out_test5 = out_test5.sort_values(by=['DATE']).drop_duplicates(subset='ENTITY_ID', keep='last').copy()
coverage_df['COVERAGE_RATE_TN_4'] = coverage_df['Topic'].apply(lambda x: sum([ 1 for i in out_test5[x+'_REL_ALL'] if i > 0])/len(out_test5))

# COMMAND ----------

coverage_df['COVERAGE_RATE_DIFF_QOQ'] = coverage_df.apply(lambda x: (x['COVERAGE_RATE_TN_0'] - x['COVERAGE_RATE_TN_1']) / x['COVERAGE_RATE_TN_1'], axis=1)
coverage_df['COVERAGE_RATE_DIFF_QO4Q'] = coverage_df.apply(lambda x: (x['COVERAGE_RATE_TN_0'] - x['COVERAGE_RATE_TN_4']) / x['COVERAGE_RATE_TN_4'], axis=1)

# COMMAND ----------

coverage_df

# COMMAND ----------

yoy_slope_df

# COMMAND ----------

slope_df

# COMMAND ----------

coverage_df.columns[5]

# COMMAND ----------

# MAGIC %md
# MAGIC #### Create final stats table

# COMMAND ----------

final_df = pd.DataFrame([])
final_df['TOPIC_NAME'] = coverage_df['Topic']
final_df['AVG_REL_TN_4'] = stats_df[stats_df.columns[1]] 
final_df['AVG_REL_TN_3'] = stats_df[stats_df.columns[2]] 
final_df['AVG_REL_TN_2'] = stats_df[stats_df.columns[3]] 
final_df['AVG_REL_TN_1'] = stats_df[stats_df.columns[4]] 
final_df['AVG_REL_TN_0'] = stats_df[stats_df.columns[5]] 
final_df[coverage_df.columns[5]] = coverage_df[coverage_df.columns[5]]
final_df[coverage_df.columns[4]] = coverage_df[coverage_df.columns[4]]
final_df[coverage_df.columns[3]] = coverage_df[coverage_df.columns[3]]
final_df[coverage_df.columns[2]] = coverage_df[coverage_df.columns[2]]
final_df[coverage_df.columns[1]] = coverage_df[coverage_df.columns[1]]
final_df[coverage_df.columns[6]] = coverage_df[coverage_df.columns[6]]
final_df[coverage_df.columns[7]] = coverage_df[coverage_df.columns[7]]
final_df['AVG_REL_DIFF_QOQ']  = ( final_df['AVG_REL_TN_0'] - final_df['AVG_REL_TN_1'] )/final_df['AVG_REL_TN_1'] 
final_df['AVG_REL_DIFF_QO4Q']  = ( final_df['AVG_REL_TN_0'] - final_df['AVG_REL_TN_4'] )/final_df['AVG_REL_TN_4'] 
final_df['PERIODS_REL_SLOPE'] = slope_df['5-quarter slope']
final_df['PERIODS_REL_SLOPE_MA'] = ma_slope_df['5-quarter slope (MA)']
final_df['PERIODS_REL_SLOPE_QO4Q'] = yoy_slope_df['5-quarter slope (Qo4Q)']
final_df['PERIODS_REL_INTERCEPT_QO4Q'] = yoy_slope_df['5-quarter intercept (Qo4Q)']


# COMMAND ----------

final_df['AVG_SENT_TN_4'] = stats_sent_df[stats_sent_df.columns[1]] 
final_df['AVG_SENT_TN_3'] = stats_sent_df[stats_sent_df.columns[2]] 
final_df['AVG_SENT_TN_2'] = stats_sent_df[stats_sent_df.columns[3]] 
final_df['AVG_SENT_TN_1'] = stats_sent_df[stats_sent_df.columns[4]] 
final_df['AVG_SENT_TN_0'] = stats_sent_df[stats_sent_df.columns[5]] 
final_df['AVG_SENT_DIFF_QOQ']  = final_df.apply(lambda x:  x['AVG_SENT_TN_0'] - x['AVG_SENT_TN_1']  , axis = 1)
final_df['AVG_SENT_DIFF_QO4Q']  = final_df.apply(lambda x:  x['AVG_SENT_TN_0'] - x['AVG_SENT_TN_4'] , axis = 1)
final_df['PERIODS_SENT_SLOPE'] = slope_sent_df['5-quarter slope']
final_df['PERIODS_SENT_SLOPE_MA'] = ma_slope_sent_df['5-quarter slope (MA)']
final_df['PERIODS_SENT_SLOPE_QO4Q'] = yoy_slope_sent_df['5-quarter slope (Qo4Q)']
final_df['PERIODS_SENT_INTERCEPT_QO4Q'] = yoy_slope_sent_df['5-quarter intercept (Qo4Q)']

# COMMAND ----------

starting_tp_df = labeled_m1_df[labeled_m1_df['INCLUDED'] == 1]

# COMMAND ----------

# Add theme-L2 & L1
final_df['L2_THEME'] = starting_tp_df['L2_THEME'].values
final_df['L1_THEME'] = starting_tp_df['L1_THEME'].values
final_df['TOPIC_ID'] = starting_tp_df['TOPIC_ID'].values

# COMMAND ----------

# Add top 60 keywords
final_df['TOP60_KEYWORDS_COSINE'] = starting_tp_df["TOP60_KEYWORDS_COSINE"].values
final_df['TOP60_KEYWORDS_COSINE'] = final_df['TOP60_KEYWORDS_COSINE'].apply(lambda x:[(w, float(s)) for w, s in x])
final_df['KEYWORDS'] = starting_tp_df["KEYWORDS"].values

# COMMAND ----------

# Add topic creation date to final_df
final_df['TP_DATE'] = starting_tp_df["TP_DATE"].values

# COMMAND ----------

rel_diff_avg = final_df.groupby('L1_THEME').apply(lambda x: np.average(x[final_df.columns[14]], weights = x[final_df.columns[5]])).reset_index()
coverage_diff_avg = final_df.groupby('L1_THEME').apply(lambda x: np.average(x[final_df.columns[12]], weights = x[final_df.columns[5]])).reset_index()
slope_avg = final_df.groupby('L1_THEME').apply(lambda x: np.average(x['PERIODS_REL_SLOPE'], weights = x[final_df.columns[5]])).reset_index()
ma_slope_avg = final_df.groupby('L1_THEME').apply(lambda x: np.average(x['PERIODS_REL_SLOPE_MA'], weights = x[final_df.columns[5]])).reset_index()
qo4q_slope_avg = final_df.groupby('L1_THEME').apply(lambda x: np.average(x['PERIODS_REL_SLOPE_QO4Q'], weights = x[final_df.columns[5]])).reset_index()
qo4q_intercept_avg = final_df.groupby('L1_THEME').apply(lambda x: np.average(x['PERIODS_REL_INTERCEPT_QO4Q'], weights = x[final_df.columns[5]])).reset_index()

# COMMAND ----------

sent_diff_avg = final_df.groupby('L1_THEME').apply(lambda x: np.average(x[final_df.columns[25]], weights = x[final_df.columns[5]])).reset_index()
sent_slope_avg = final_df.groupby('L1_THEME').apply(lambda x: np.average(x['PERIODS_SENT_SLOPE'], weights = x[final_df.columns[5]])).reset_index()
sent_ma_slope_avg = final_df.groupby('L1_THEME').apply(lambda x: np.average(x['PERIODS_SENT_SLOPE_MA'], weights = x[final_df.columns[5]])).reset_index()
sent_qo4q_slope_avg = final_df.groupby('L1_THEME').apply(lambda x: np.average(x['PERIODS_SENT_SLOPE_QO4Q'], weights = x[final_df.columns[5]])).reset_index()
sent_qo4q_intercept_avg = final_df.groupby('L1_THEME').apply(lambda x: np.average(x['PERIODS_SENT_INTERCEPT_QO4Q'], weights = x[final_df.columns[5]])).reset_index()

# COMMAND ----------

rel_diff_avg.columns = ['L1_THEME', 'WEIGHTED_AVG_REL_DIFF_QO4Q']

# COMMAND ----------

theme_df = rel_diff_avg
theme_df['WEIGHTED_COVERAGE_RATE_DIFF_QO4Q'] = coverage_diff_avg[0].values
theme_df['WEIGHTED_PERIODS_REL_SLOPE'] = slope_avg[0].values
theme_df['WEIGHTED_PERIODS_REL_SLOPE_MA'] = ma_slope_avg[0].values
theme_df['WEIGHTED_PERIODS_REL_SLOPE_QO4Q'] = qo4q_slope_avg[0].values
theme_df['WEIGHTED_PERIODS_REL_INTERCEPT_QO4Q'] = qo4q_intercept_avg[0].values
theme_df['WEIGHTED_AVG_SENT_DIFF_QO4Q'] = sent_diff_avg[0].values
theme_df['WEIGHTED_PERIODS_SENT_SLOPE'] = sent_slope_avg[0].values
theme_df['WEIGHTED_PERIODS_SENT_SLOPE_MA'] = sent_ma_slope_avg[0].values
theme_df['WEIGHTED_PERIODS_SENT_SLOPE_QO4Q'] = sent_qo4q_slope_avg[0].values
theme_df['WEIGHTED_PERIODS_SENT_INTERCEPT_QO4Q'] = sent_qo4q_intercept_avg[0].values

# COMMAND ----------

final_df = pd.merge(final_df, theme_df, on='L1_THEME', how='inner')

# COMMAND ----------

final_df

# COMMAND ----------

final_df['TN_0'] = stats_df.columns[5]
final_df['TN_1'] = stats_df.columns[4]
final_df['TN_2'] = stats_df.columns[3]
final_df['TN_3'] = stats_df.columns[2]
final_df['TN_4'] = stats_df.columns[1]
final_df['TN_START_DATE'] = update_start_date
final_df['TN_END_DATE'] = update_end_date
final_df['UPDATE_DATE'] = data_end_date.strftime('%Y-%m-%d')
final_df['UPDATE_DATE'] = pd.to_datetime(final_df['UPDATE_DATE'])
final_df['TN_START_DATE'] = pd.to_datetime(final_df['TN_START_DATE'])
final_df['TN_END_DATE'] = pd.to_datetime(final_df['TN_END_DATE'])
final_df['TN_0_M_0'] = month_count['count'].values[-1]
final_df['TN_0_M_1'] = month_count['count'].values[-2]
final_df['TN_0_M_2'] = month_count['count'].values[-3]

# COMMAND ----------

final_df

# COMMAND ----------

spark_parsedDF = pandas_to_spark(final_df)
spark_parsedDF = spark_parsedDF.replace(np.nan, None)
spark_parsedDF = spark_parsedDF.withColumn("TN_START_DATE", F.to_timestamp(spark_parsedDF.TN_START_DATE, 'yyyy-MM-dd'))
spark_parsedDF = spark_parsedDF.withColumn("TN_END_DATE", F.to_timestamp(spark_parsedDF.TN_END_DATE, 'yyyy-MM-dd'))
spark_parsedDF = spark_parsedDF.withColumn("UPDATE_DATE", F.to_timestamp(spark_parsedDF.UPDATE_DATE, 'yyyy-MM-dd'))
spark_parsedDF = spark_parsedDF.withColumn("TP_DATE", F.to_timestamp(spark_parsedDF.TP_DATE, 'yyyy-MM-dd'))
new_sf.db = 'EDS_PROD'
new_sf.schema = 'QUANT'
 
tablename_curr = 'YUJING_DTM_TP_STATS_DEV_4'
result_curr = new_sf.write_to_snowflake_table(spark_parsedDF, tablename_curr)

# COMMAND ----------

theme_df['TN'] = stats_df.columns[5]
theme_df['TN_START_DATE'] = update_start_date
theme_df['TN_END_DATE'] = update_end_date
theme_df['UPDATE_DATE'] = data_end_date.strftime('%Y-%m-%d')
theme_df['UPDATE_DATE'] = pd.to_datetime(theme_df['UPDATE_DATE'])
theme_df['TN_START_DATE'] = pd.to_datetime(theme_df['TN_START_DATE'])
theme_df['TN_END_DATE'] = pd.to_datetime(theme_df['TN_END_DATE'])
theme_df['TN_0_M_0'] = month_count['count'].values[-1]
theme_df['TN_0_M_1'] = month_count['count'].values[-2]
theme_df['TN_0_M_2'] = month_count['count'].values[-3]

# COMMAND ----------

theme_df

# COMMAND ----------

spark_parsedDF = pandas_to_spark(theme_df)
spark_parsedDF = spark_parsedDF.replace(np.nan, None)
spark_parsedDF = spark_parsedDF.withColumn("TN_START_DATE", F.to_timestamp(spark_parsedDF.TN_START_DATE, 'yyyy-MM-dd'))
spark_parsedDF = spark_parsedDF.withColumn("TN_END_DATE", F.to_timestamp(spark_parsedDF.TN_END_DATE, 'yyyy-MM-dd'))
spark_parsedDF = spark_parsedDF.withColumn("UPDATE_DATE", F.to_timestamp(spark_parsedDF.UPDATE_DATE, 'yyyy-MM-dd'))

new_sf.db = 'EDS_PROD'
new_sf.schema = 'QUANT'

tablename_curr = 'YUJING_DTM_TP_THEME_DEV_4'
result_curr = new_sf.write_to_snowflake_table(spark_parsedDF, tablename_curr)

# COMMAND ----------

