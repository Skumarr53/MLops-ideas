# Databricks notebook source
# MAGIC %md
# MAGIC #### SF Equity super stock topics monthly NLI pipeline
# MAGIC This notebook is used to create monthly company-level super stock topics table for SF Equity Team. They focus more on the extracted text for each topic, so we have 'EXTRACT' related columns for this use case.
# MAGIC
# MAGIC Reads from: QUANT.PARTHA_FUND_CTS_STG_1_VIEW (historical backfilling only) and QUANT_LIVE.CTS_FUND_COMBINED_SCORES_H
# MAGIC
# MAGIC Writes to: QUANT_STG.CTS_SF_SUPER_STOCK_NLI_M_LR_1
# MAGIC
# MAGIC Recommended cluster: GPU cluster with 13.3 LTS runtime (It will take around 2 mins to load the NLI model). If you're using other runtime, it will take more than 10 mins.
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Load packages

# COMMAND ----------

!pip install transformers==4.40.1
# !pip install safetensors==4.40.1

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %run ./../../../data-science-nlp-ml-common-code/impackage/utilities/config_utility

# COMMAND ----------

# MAGIC %run ./../../../data-science-nlp-ml-common-code/impackage/database/snowflake_dbutility

# COMMAND ----------

new_sf = SnowFlakeDBUtility(config.schema, config.eds_db_prod)

# COMMAND ----------

import ast
from IPython.display import clear_output
import numpy as np
from dateutil.relativedelta import relativedelta
import pickle 
import pandas as pd
from pyspark.sql.types import *
from transformers import pipeline
from transformers import AutoTokenizer, AutoModelForSequenceClassification, AutoModel
from transformers import TextClassificationPipeline
from transformers import ZeroShotClassificationPipeline
import torch

device = 0 if torch.cuda.is_available() else -1

# COMMAND ----------

# MAGIC %md
# MAGIC ## Load model

# COMMAND ----------

class_data_path = "/dbfs/mnt/access_work/UC25/Topic Modeling/NLI Models/"
topic_set = ["This text is about the company's business or market demand, not accounting metrics, will have a strong looking-forward increase or acceleration in the future", "This text is about the company still shows confidence or strong demand from market in macro difficult time", "This text is about positive sentiment"]
labels = topic_set
model_1_folder_name = "deberta-v3-large-zeroshot-v2"
model_folder_path = "/dbfs/mnt/access_work/UC25/Libraries/HuggingFace/"

tokenizer_1 = AutoTokenizer.from_pretrained(model_folder_path + model_1_folder_name)
model_1 = AutoModelForSequenceClassification.from_pretrained(model_folder_path + model_1_folder_name)
pl_inference1 = pipeline(task="text-classification", model = model_1, tokenizer = tokenizer_1, device = device)

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC ## Read Earnings Call data from Snowflake

# COMMAND ----------

data_end_date = datetime.now().replace(day=1) 
data_last_month = datetime.now().replace(day=1) - relativedelta(months=1)

# COMMAND ----------

lastDateNewQuery = (pd.to_datetime(format(data_last_month, '%m') + "-01-" + format(data_last_month, '%Y'))).strftime('%Y-%m-%d')
currentDateNewQuery = (pd.to_datetime(format(data_end_date, '%m') + "-01-" + format(data_end_date, '%Y'))).strftime('%Y-%m-%d')

mind = "'" + lastDateNewQuery + "'"
maxd = "'" + currentDateNewQuery + "'"
print('The next query spans ' + mind + ' to ' + maxd)

# COMMAND ----------

tsQuery= ("select CALL_ID,ENTITY_ID, DATE, FILT_MD, FILT_QA, CALL_NAME,COMPANY_NAME,EARNINGS_CALL,ERROR,TRANSCRIPT_STATUS,UPLOAD_DT_UTC,VERSION_ID,EVENT_DATETIME_UTC,PARSED_DATETIME_EASTERN_TZ,SENT_LABELS_FILT_MD, SENT_LABELS_FILT_QA from EDS_PROD.QUANT_LIVE.CTS_FUND_COMBINED_SCORES_H  WHERE DATE >= " + mind + " AND DATE < " + maxd + " ORDER BY PARSED_DATETIME_EASTERN_TZ DESC;")

resultspkdf = new_sf.read_from_snowflake(tsQuery)

currdf = resultspkdf.toPandas()

if len(currdf)>0:
    print('The data spans from ' + str(currdf['PARSED_DATETIME_EASTERN_TZ'].min()) + ' to ' + str(currdf['PARSED_DATETIME_EASTERN_TZ'].max()) + 'and has ' + str(currdf.shape[0]) + ' rows and ' + str(currdf.shape[1]) + ' columns.')
else:
    print('No new transcripts to parse.')
    dbutils.notebook.exit(1)
    os._exit(1)

# COMMAND ----------

currdf['CALL_ID'] = currdf['CALL_ID'].apply(lambda x: str(x))

# COMMAND ----------

currdf['FILT_MD'] = currdf['FILT_MD'].apply(ast.literal_eval)
currdf['FILT_QA'] = currdf['FILT_QA'].apply(ast.literal_eval)
currdf['SENT_LABELS_FILT_MD'] = currdf['SENT_LABELS_FILT_MD'].apply(ast.literal_eval)
currdf['SENT_LABELS_FILT_QA'] = currdf['SENT_LABELS_FILT_QA'].apply(ast.literal_eval)
currdf['LEN_FILT_MD'] = currdf['FILT_MD'].apply(len)
currdf['LEN_FILT_QA'] = currdf['FILT_QA'].apply(len)

# COMMAND ----------

currdf.shape

# COMMAND ----------

currdf = currdf.sort_values(by = 'UPLOAD_DT_UTC').drop_duplicates(subset = ['ENTITY_ID', 'EVENT_DATETIME_UTC'], keep = 'first')

# COMMAND ----------

# Skip the questions in QA section
currdf['SENT_LABELS_FILT_QA'] = currdf.apply(lambda x: [x['SENT_LABELS_FILT_QA'][i] for i, sent in enumerate(x['FILT_QA']) if not sent.endswith('?')], axis=1)
currdf['FILT_QA'] = currdf['FILT_QA'].apply(lambda x: [sent for sent in x if not sent.endswith('?')])
currdf['LEN_FILT_QA'] = currdf['FILT_QA'].apply(lambda x: len(x))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Helper functions

# COMMAND ----------

def create_text_pair(transcript,  labels, inference_template = ""):
  template = inference_template + "{label}."
  text1, text2 = [], []
  for t in transcript:
      for l in labels:
          text1.append(t)
          text2.append(template.format(label=l))
  return text1, text2

def inference_summary1(text1, text2, inference_result, threshold = 0.91):
  result_dict = {tp +'.': [] for tp in topic_set}
  total_dict = {tp +'.': [] for tp in topic_set}
  for i, sentence in enumerate(text1):
    for s in inference_result[i]:
      if s['label'] == 'entailment':
        if s['score'] > threshold:
          result_dict[text2[i]].append(sentence)
          total_dict[text2[i]].append(1)
        else:
          total_dict[text2[i]].append(0)
  return result_dict, total_dict

def sentscore(a, b, weight = True):
  
  # number of relevant sentences
      
  length = len(a)
  if length==0:
      return None
  if length!=len(b):
      return None
  num = len([x for x in a if x>0])
  
  if num==0:
      return None
   
  if weight==True:
    return np.dot(a,b)/num
  else:
    return np.dot([1 if x>0 else 0 for x in a], b)/num

def extract_inf(row, section, section_len):
  count_col = {}
  rel_col = {}
  extract_col = {}
  for tp, sent in row.items():
    count_col[f'{tp}_COUNT_{section}'] = len(sent)
    if section_len != 0:
      rel_col[f'{tp}_REL_{section}'] = len(sent) / section_len
    else:
      rel_col[f'{tp}_REL_{section}'] = None
    extract_col[f'{tp}_EXTRACT_{section}'] = sent
  return pd.Series({**count_col,**rel_col,**extract_col})


def equivalent_type(string, f):
    print(string, f)
    
    if f == 'datetime64[ns]': return TimestampType()
    elif f == 'int64': return LongType()
    elif f == 'int32': return IntegerType()
    elif f == 'float64': return FloatType()
    elif "EXTRACT" in string: return ArrayType(StringType())
    else: return StringType()

def define_structure(string, format_type):
    typo = equivalent_type(string, format_type)
    print(typo)
    return StructField(string, typo)

# Given pandas dataframe, it will return a spark's dataframe.
def pandas_to_spark(pandas_df):
    columns = list(pandas_df.columns)
    types = list(pandas_df.dtypes)
    struct_list = []
    for column, typo in zip(columns, types): 
      struct_list.append(define_structure(column, typo))
    p_schema = StructType(struct_list)
    return sqlContext.createDataFrame(pandas_df, p_schema)
  


# COMMAND ----------

# MAGIC %md
# MAGIC ## Generate topic metrics
# MAGIC For SF Equity use case, they mainly focus on the extracted text for two topics. We also generated the sentiment score for these topics to doublecheck they are positive. We used both FINBERT sentiment score and NLI sentiment score. FINBERT sentiment score is ranged from -1 and 1, and NLI sentiment score is ranged from 0 to 1. In this case, we didn't generate positive, neutral and negative three sentiment NLI labels and get the one with largest entailment score we don't care that much about neutral and negative group. We just want to get the positive extraction. 

# COMMAND ----------

# Implement NLI model on ECalls
for section in ['MD', 'QA']:
  currdf['TEXT1_'+ section] = currdf['FILT_'+ section].apply(lambda x: create_text_pair(x,  topic_set)[0])
  currdf['TEXT2_'+ section] = currdf['FILT_'+ section].apply(lambda x: create_text_pair(x, topic_set)[1])
  currdf[section +'_RESULT'] = currdf.apply(lambda x: pl_inference1([f"{x['TEXT1_'+ section][i]}</s></s>{x['TEXT2_'+ section][i]}" for i in range(len(x['TEXT1_'+ section])) ], padding=True, top_k=None, batch_size = 16, truncation = True, max_length = 512), axis=1)
  currdf[section + '_FINAL'] = currdf.apply(lambda x: inference_summary1(x['TEXT1_'+ section], x['TEXT2_'+ section], x[section + '_RESULT'], 0.91)[0], axis=1)
  currdf[section + '_FINAL_TOTAL'] = currdf.apply(lambda x: inference_summary1(x['TEXT1_'+ section], x['TEXT2_'+ section], x[section + '_RESULT'], 0.91)[1], axis=1)

# COMMAND ----------

# Get the sentiment score for each topic
for section in ['MD', 'QA']:
  currdf['TP1_SENT_NLI_'+ section] = currdf[section + '_FINAL_TOTAL'].apply(lambda x: sentscore(x["This text is about the company's business or market demand, not accounting metrics, will have a strong looking-forward increase or acceleration in the future."], x['This text is about positive sentiment.'], weight = False))
  currdf['TP2_SENT_NLI_'+ section] = currdf[section + '_FINAL_TOTAL'].apply(lambda x: sentscore(x["This text is about the company still shows confidence or strong demand from market in macro difficult time."], x['This text is about positive sentiment.'], weight = False))
  currdf['TP1_SENT_FINBERT_'+ section] = currdf.apply(lambda x: sentscore(x[section + '_FINAL_TOTAL']["This text is about the company's business or market demand, not accounting metrics, will have a strong looking-forward increase or acceleration in the future."], x['SENT_LABELS_FILT_'+ section], weight = False), axis =1)
  currdf['TP2_SENT_FINBERT_'+ section] = currdf.apply(lambda x: sentscore(x[section + '_FINAL_TOTAL']["This text is about the company still shows confidence or strong demand from market in macro difficult time."], x['SENT_LABELS_FILT_'+ section], weight = False), axis = 1)

# COMMAND ----------

currdf_final = pd.concat([currdf[['ENTITY_ID','DATE','CALL_NAME','COMPANY_NAME', 'LEN_FILT_MD', 'LEN_FILT_QA', 'TP1_SENT_NLI_MD', 'TP2_SENT_NLI_MD','TP1_SENT_FINBERT_MD','TP2_SENT_FINBERT_MD','TP1_SENT_NLI_QA', 'TP2_SENT_NLI_QA','TP1_SENT_FINBERT_QA','TP2_SENT_FINBERT_QA']], currdf.apply(lambda x: extract_inf(x['MD_FINAL'], 'FILT_MD', x['LEN_FILT_MD']), axis =1), currdf.apply(lambda x: extract_inf(x['QA_FINAL'], 'FILT_QA', x['LEN_FILT_QA']), axis =1)], axis=1)


# COMMAND ----------

currdf_final

# COMMAND ----------

"/dbfs/mnt/access_work/UC25/Topic Modeling/NLI Models/SF_NLI_" + lastDateNewQuery[5:7] + "_" + lastDateNewQuery[2:4] + "_" + currentDateNewQuery[5:7] + "_" + currentDateNewQuery[2:4] +  "_v2_git.csv"

# COMMAND ----------

# Save the table into blob
currdf_final.to_csv("/dbfs/mnt/access_work/UC25/Topic Modeling/NLI Models/SF_NLI_" + lastDateNewQuery[5:7] + "_" + lastDateNewQuery[2:4] + "_" + currentDateNewQuery[5:7] + "_" + currentDateNewQuery[2:4] +  "_v2_git.csv")

# COMMAND ----------

df_all = currdf_final

# COMMAND ----------

df_all["TP1_EXTRACT_FILT_MD"] = df_all["This text is about the company's business or market demand, not accounting metrics, will have a strong looking-forward increase or acceleration in the future._EXTRACT_FILT_MD"]
df_all["TP1_EXTRACT_FILT_QA"] = df_all["This text is about the company's business or market demand, not accounting metrics, will have a strong looking-forward increase or acceleration in the future._EXTRACT_FILT_QA"]
df_all["TP2_EXTRACT_FILT_MD"] = df_all["This text is about the company still shows confidence or strong demand from market in macro difficult time._EXTRACT_FILT_MD"]
df_all["TP2_EXTRACT_FILT_QA"] = df_all["This text is about the company still shows confidence or strong demand from market in macro difficult time._EXTRACT_FILT_QA"]

# COMMAND ----------

df_all = df_all.drop(columns = ["This text is about positive sentiment._COUNT_FILT_MD", "This text is about positive sentiment._REL_FILT_MD", "This text is about positive sentiment._COUNT_FILT_QA", "This text is about positive sentiment._REL_FILT_QA", "This text is about positive sentiment._EXTRACT_FILT_MD", "This text is about positive sentiment._EXTRACT_FILT_QA", "This text is about the company's business or market demand, not accounting metrics, will have a strong looking-forward increase or acceleration in the future._EXTRACT_FILT_MD","This text is about the company's business or market demand, not accounting metrics, will have a strong looking-forward increase or acceleration in the future._EXTRACT_FILT_QA","This text is about the company still shows confidence or strong demand from market in macro difficult time._EXTRACT_FILT_MD", "This text is about the company still shows confidence or strong demand from market in macro difficult time._EXTRACT_FILT_QA" ])


# COMMAND ----------

df_all

# COMMAND ----------

df_all.columns

# COMMAND ----------

df_all.columns = ['ENTITY_ID', 'DATE', 'CALL_NAME', 'COMPANY_NAME', 'LEN_FILT_MD',
       'LEN_FILT_QA', 'TP1_SENT_NLI_MD', 'TP2_SENT_NLI_MD',
       'TP1_SENT_FINBERT_MD', 'TP2_SENT_FINBERT_MD', 'TP1_SENT_NLI_QA',
       'TP2_SENT_NLI_QA', 'TP1_SENT_FINBERT_QA', 'TP2_SENT_FINBERT_QA',
       "TP1_COUNT_FILT_MD",
       'TP2_COUNT_FILT_MD',
       "TP1_REL_FILT_MD",
       'TP2_REL_FILT_MD',
       "TP1_COUNT_FILT_QA",
       'TP2_COUNT_FILT_QA',
       "TP1_REL_FILT_QA",
       'TP2_REL_FILT_QA',
       'TP1_EXTRACT_FILT_MD', 'TP1_EXTRACT_FILT_QA', 'TP2_EXTRACT_FILT_MD',
       'TP2_EXTRACT_FILT_QA']

# COMMAND ----------

df_all['TP1_EXTRACT_FILT_MD'] = df_all['TP1_EXTRACT_FILT_MD'].apply(lambda x: x if x!=[] else None)
df_all['TP2_EXTRACT_FILT_MD'] = df_all['TP2_EXTRACT_FILT_MD'].apply(lambda x: x if x!=[] else None)
df_all['TP1_EXTRACT_FILT_QA'] = df_all['TP1_EXTRACT_FILT_QA'].apply(lambda x: x if x!=[] else None)
df_all['TP2_EXTRACT_FILT_QA'] = df_all['TP2_EXTRACT_FILT_QA'].apply(lambda x: x if x!=[] else None)

# COMMAND ----------

df_all['DATE'] = pd.to_datetime(df_all['DATE'])

# COMMAND ----------




# COMMAND ----------

# MAGIC %md
# MAGIC ## Write table to Snowflake

# COMMAND ----------

spark_parsedDF = pandas_to_spark(df_all)
spark_parsedDF = spark_parsedDF.replace(np.nan, None)
spark_parsedDF = spark_parsedDF.withColumn("DATE", F.to_timestamp(spark_parsedDF.DATE, 'yyyy-MM-dd'))

new_sf.db = 'EDS_PROD'
new_sf.schema = 'QUANT_STG'
 
tablename_curr = 'CTS_SF_SUPER_STOCK_NLI_M_LR_1'
result_curr = new_sf.write_to_snowflake_table(spark_parsedDF, tablename_curr)

# COMMAND ----------

