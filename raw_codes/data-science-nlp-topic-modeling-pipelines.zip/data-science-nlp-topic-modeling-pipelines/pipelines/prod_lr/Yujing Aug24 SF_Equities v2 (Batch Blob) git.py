# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC #### SF Equities Stock Recovery notebook (Limited Release)
# MAGIC
# MAGIC This notebook filters for transcripts with top mentions of recovery, cyclical growth and demand, and produces a monthly report
# MAGIC
# MAGIC Input tables: QUANT.PARTHA_FUND_CTS_STG_1_VIEW(historical backfilling only) and QUANT_LIVE.CTS_FUND_COMBINED_SCORES_H
# MAGIC
# MAGIC Output tables: QUANT_STG.CTS_SF_REPORT_M_LR_1, writes reports to Blob as well: '/dbfs/mnt/access_work/UC25/SF_Equities_Reports/'
# MAGIC
# MAGIC Frequency: 1st of every month, run manually
# MAGIC
# MAGIC Match word list: /dbfs/mnt/access_work/UC25/Embeddings/Word lists/sf_equities_edit_v2.csv
# MAGIC
# MAGIC Recommended cluster: F_72s_v2 (minimum 144gb RAM recommended. Dask core count must be configured to cluster. Note that monthly transcript frequency varies, necessitating higher RAM overhead.)
# MAGIC
# MAGIC Est. time to complete 1 full run: 5-10 min, depending on cluster start time and core count.
# MAGIC
# MAGIC Misc
# MAGIC - Dask powers multiprocessing on this notebook. Use n_tasks = number of cores on instance
# MAGIC - Sent model path should lead to a Hugging Face BERT-based sentiment classifcation model
# MAGIC - Note that range needs to be specified to run notebook. End month is not inclusive. ie if start month = 12, end month = 1, then transcripts from December only would be processed.

# COMMAND ----------

# MAGIC %md
# MAGIC #### Install packages

# COMMAND ----------

pip install spacy==3.5.0 pandas==2.1.1 numpy==1.25.2 tqdm==4.66.1 dask==2023.10.1 distributed==2023.10.1 pyspark==3.5.0

# COMMAND ----------

!pip install https://github.com/explosion/spacy-models/releases/download/en_core_web_sm-3.4.0/en_core_web_sm-3.4.0.tar.gz

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %run ./../../../data-science-nlp-ml-common-code/impackage/utilities/config_utility

# COMMAND ----------

# MAGIC %run ./../../../data-science-nlp-ml-common-code/impackage/database/snowflake_dbutility

# COMMAND ----------

import spacy
from spacy.lang.en import English
import pandas as pd
import numpy as np
import spacy
import tqdm
from tqdm import tqdm
tqdm.pandas()
from collections import Counter
import dask.dataframe as dd
from dask.distributed import Client
from dask.diagnostics import ProgressBar
from pyspark.sql.types import *
import ast
import gc


# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC #### Set Dask cores

# COMMAND ----------

## IMPORTANT =  Set to number of Cores !!
n_tasks = 32

# Dask client 
client = Client(n_workers=n_tasks, threads_per_worker=1)

# COMMAND ----------

new_sf = SnowFlakeDBUtility(config.schema, config.eds_db_prod)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Monthly query

# COMMAND ----------

# Read start & end ranges. Range not inclusive of end date. 
month = datetime.now().month
year = datetime.now().year

minDateNewQuery = str(year - (1 if month == 1 else 0)) + '-' + (('0' if (month<11 and month>1) else '') + str(month - (1 if month > 1 else -11))) + "-01"
maxDateNewQuery = str(year) + '-' + (('0' if month<10 else '') + str(month)) + "-01"

mind = "'" + minDateNewQuery + "'"
maxd = "'" + maxDateNewQuery + "'"

print('The next query spans ' + mind + ' to ' + maxd)

# COMMAND ----------

# Query transcripts.
tsQuery= ("SELECT CALL_ID,ENTITY_ID, FILT_MD, FILT_QA, SENT_LABELS_FILT_MD, SENT_LABELS_FILT_QA, CALL_NAME,COMPANY_NAME,EARNINGS_CALL,ERROR,TRANSCRIPT_STATUS,UPLOAD_DT_UTC,VERSION_ID,EVENT_DATETIME_UTC,PARSED_DATETIME_EASTERN_TZ "
          
   "FROM EDS_PROD.QUANT_LIVE.CTS_FUND_COMBINED_SCORES_H "
          
   "WHERE EVENT_DATETIME_UTC >= " + mind  + " AND EVENT_DATETIME_UTC < " + maxd  + " AND (EARNINGS_CALL > 0) AND (TRANSCRIPT_STATUS = 'CorrectedTranscript');")

resultspkdf = new_sf.read_from_snowflake(tsQuery)

currdf = resultspkdf.toPandas()

if len(currdf)>0:
    print('The data spans from ' + str(currdf['PARSED_DATETIME_EASTERN_TZ'].min()) + ' to ' + str(currdf['PARSED_DATETIME_EASTERN_TZ'].max()) + 'and has ' + str(currdf.shape[0]) + ' rows and ' + str(currdf.shape[1]) + ' columns.')
else:
    print('No new transcripts to parse.')
    dbutils.notebook.exit(1)
    os._exit(1)

# COMMAND ----------

del resultspkdf

# COMMAND ----------

currdf['CALL_ID'] = currdf['CALL_ID'].apply(lambda x: str(x))

# COMMAND ----------

currdf.sort_values(by = 'UPLOAD_DT_UTC').head(3)

# COMMAND ----------

len(currdf)

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC #### FILTER FOR POS SENT AND NO QUESTIONS
# MAGIC
# MAGIC Removing questions, and keeping only positive sentiment sentences

# COMMAND ----------

# Convert to Python list from string
currdf['FILT_MD'] = currdf['FILT_MD'].apply(ast.literal_eval)
currdf['FILT_QA'] = currdf['FILT_QA'].apply(ast.literal_eval)
currdf['SENT_LABELS_FILT_MD'] = currdf['SENT_LABELS_FILT_MD'].apply(ast.literal_eval)
currdf['SENT_LABELS_FILT_QA'] = currdf['SENT_LABELS_FILT_QA'].apply(ast.literal_eval)

currdf['LEN_MD'] = currdf['FILT_MD'].apply(len)
currdf['LEN_QA'] = currdf['FILT_QA'].apply(len)

# COMMAND ----------

# Remove questions and keep +ve sentiment only
currdf['FILT_MD'] = currdf[['FILT_MD', 'SENT_LABELS_FILT_MD']].apply(lambda x: [y for y,z in zip(x[0], x[1]) if ((z==1) & (not y.endswith('?')))], axis = 1)
currdf['FILT_QA'] = currdf[['FILT_QA', 'SENT_LABELS_FILT_QA']].apply(lambda x: [y for y,z in zip(x[0], x[1]) if ((z==1) & (not y.endswith('?')))], axis = 1)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Helper functions

# COMMAND ----------

nlp = spacy.load("en_core_web_sm", disable = ['parser'])

# Excluding financially relavant stopwords
nlp.Defaults.stop_words -= {"bottom", "top", "Bottom", "Top", "call", "down"}
nlp.max_length = 1000000000


# Lemmatizer - for document text
def wordTokenize(doc):
  
  return [ent.lemma_.lower() for ent in nlp(doc) if not ent.is_stop and not ent.is_punct and ent.pos_ != 'NUM']


# Tokenizer/lemmatizer for match words
def matchTokenize(doc):
  ret = []
  for ent in nlp(doc):
    if ent.pos_ == 'PROPN' or ent.text[0].isupper():
      ret.append(ent.text.lower())
      continue
    if not ent.is_stop and not ent.is_punct and ent.pos_ != 'NUM':
      ret.append(ent.lemma_.lower())
  return ret


# Creates n grams helper fxn
def find_ngrams(input_list, n):
  return zip(*[input_list[i:] for i in range(n)])


# Create a set of match patterns from match list. This ensures variations such as lemmas & case are handled.
def get_match_set(matches):
  
  bigrams = set([word.lower() for word in matches if len(word.split('_'))==2] + [word.lower().replace(" ", '_') for word in matches if len(word.split(' '))==2] + ['_'.join(matchTokenize(word)) for word in matches if len(word.split(' '))==2])
 
  unigrams = set([matchTokenize(match)[0] for match in matches if ('_' not in match) and (len(match.split(' '))==1)] + [match.lower() for match in matches if ('_' not in match) and (len(match.split(' '))==1)])

#  Phrase matching correction
  phrases = [phrase.lower() for phrase in matches if len(phrase.split(" "))>2]
  
  return {'original': matches, 'unigrams': unigrams, 'bigrams': bigrams, 'phrases': phrases}
  
# Counting fxn. Phrase matching increases compute time - consider use case before enabling it. Set to true as fxn default.
def match_count_noStat(text, match_sets, phrases = True, suppress = None):
  suppressed = {label: False for label in match_sets.keys()}
  unigrams = wordTokenize(text)
  
  vocab = {word: 0 for word in set(unigrams)}
  bigrams = ['_'.join(g) for g in find_ngrams(unigrams, 2)]
  
  total_count = {label : 0 for label, match_set in match_sets.items()}
  
  for label, match_set in match_sets.items(): 
    for word in unigrams:
      if label in suppress.keys():
        if word in suppress[label]:
          suppressed[label] = True
          continue
      if word in match_set['unigrams']:
        total_count[label]+=1
    for word in bigrams:
      if label in suppress.keys():
        if word in suppress[label]:
          suppressed[label] = True
          continue
      if word in match_set['bigrams']:
        total_count[label]+=1
    
    if phrases:
      total_count[label] = uni_count[label] + bi_count[label] + sum([1 if phrase in text.lower() else 0 for phrase in match_set['phrases']]) 
  
  return {label : total_count[label] if not suppressed[label] else 0 for label in match_sets.keys()}
    

def match_count_lowStat(texts, match_sets, phrases = True, suppress = None):

  count_dict = {label : {matchw: 0 for matchw in match_set['unigrams'].union(match_set['bigrams']) } for label, match_set in match_sets.items()}
  total_counts = {label: [] for label in match_sets.keys()}

  for text in texts:
    
    counted = {label: 0 for label in match_sets.keys()}
    unigrams = wordTokenize(text)
    bigrams = ['_'.join(g) for g in find_ngrams(unigrams, 2)]
    
    text = text.lower()
    for label, match_set in match_sets.items(): 
      
      if any(item in text for item in suppress[label]):
        counted[label] += 0
        continue
        
      for word in unigrams:
        if word in match_set['unigrams']:
          count_dict[label][word]+=1
          counted[label] += 1

      for word in bigrams:
        if word in match_set['bigrams']:
          count_dict[label][word]+=1
          counted[label] += 1
      
      if phrases:
        if any(phrase in text for phrase in match_set['phrases']):
          counted[label] += 1
          continue

    for label in match_sets.keys():
      
      total_counts[label].append(counted[label])

    
  return {label : {'total': total_counts[label], 'stats' : count_dict[label]} for label in match_sets.keys()}
  

# Used to merge dictionaries that keep track of word counts 
def mergeCount(x):
  
  try:
    merge = Counter(x[0])
 
    for calc in x[1:]:

      merge = merge + Counter(calc)
    if len(merge.keys())==0:
      return {'NO_MATCH': 1}
    return merge
  except:
    return {'ERROR': 1}
  
def sentscore(a, b, weight = True):
  
  # number of relevant sentences
      
  length = len(a)
  if length==0:
      return None
  if length!=len(b):
      return None
  num = len([x for x in a if x>0])
  
  if num==0:
      return None
   
  if weight==True:
    return np.dot(a,b)/num
  else:
    return np.dot([1 if x>0 else 0 for x in a], b)/num

def netscore(a, b):
  
  # number of relevant sentences
  length = len(a)
  if length==0:
      return None
  if length!=len(b):
      return None
  num = len([x for x in a if x>0])
  
  if num==0:
      return None
   
  return np.dot([1 if x>0 else 0 for x in a], b)

# Auxiliar functions
def equivalent_type(string, f):
    print(string, f)
   
    if f == 'datetime64[ns]': return TimestampType()
    elif f == 'int64': return LongType()
    elif f == 'int32': return IntegerType()
    elif f == 'float64': return FloatType()
    elif 'FILT_MD' == string: return ArrayType(StringType())
    elif 'FILT_QA' == string: return ArrayType(StringType())
    elif 'len' in string.lower(): return ArrayType(IntegerType())
    elif 'total' in string.lower(): return ArrayType(IntegerType())
    elif 'count' in string.lower(): return IntegerType()
    elif 'stats' in string.lower(): return MapType(StringType(), IntegerType())
    elif 'sent_scores' in string.lower(): return ArrayType(FloatType())
    elif 'sent_labels' in string.lower(): return ArrayType(IntegerType())
    else: return StringType()

# Given pandas dataframe, it will return a spark's dataframe.
def pandas_to_spark(pandas_df):
    columns = list(pandas_df.columns)
    types = list(pandas_df.dtypes)
    struct_list = []
    for column, typo in zip(columns, types): 
      struct_list.append(define_structure(column, typo))
    p_schema = StructType(struct_list)
    return sqlContext.createDataFrame(pandas_df, p_schema)
  
def define_structure(string, format_type):
  typo = equivalent_type(string, format_type)
  print(typo)
  return StructField(string, typo)

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC #### Word list counts
# MAGIC

# COMMAND ----------

# Read match list and create match set
match_df = pd.read_csv(dbutils.widgets.get("Match list path"))

word_set_dict = {topic.replace(' ', '_').upper() : get_match_set(match_df[(match_df['label']==topic) & (match_df['negate']==False)]['match'].values) for topic in match_df['label'].unique()}

negate_dict = {topic.replace(' ', '_').upper() : [word.lower() for word in match_df[(match_df['label']==topic) & (match_df['negate']==True)]['match'].values.tolist()] for topic in match_df['label'].unique()}

# COMMAND ----------

negate_dict

# COMMAND ----------

# MAGIC %md
# MAGIC #### Generate topic metrics

# COMMAND ----------

currdf = dd.from_pandas(currdf, npartitions = n_tasks)
for label, section in {'FILT_MD': 'FILT_MD', 'FILT_QA': 'FILT_QA'}.items():

  currdf['matches_' + label] = currdf[section].apply(lambda x: match_count_lowStat(x, word_set_dict, suppress = negate_dict), meta = ('matches_' + label, object))

# COMMAND ----------

gc.collect()

# COMMAND ----------

# Running Dask compute
#%%time
with ProgressBar():
  currdf = currdf.compute()

# COMMAND ----------

#%%time
for label, section in {'FILT_MD': 'MGNT_DISCUSSION', 'FILT_QA': 'QA_SECTION'}.items():
  
  for topic in word_set_dict.keys():
    currdf[topic + '_TOTAL_' + label] = currdf['matches_' + label].apply(lambda x: x[topic]['total'])
    currdf[topic + '_STATS_' + label] = currdf['matches_' + label].apply(lambda x: x[topic]['stats'])

  currdf.drop(['matches_' + label], axis = 1, inplace = True)
  gc.collect()

# COMMAND ----------

# Calculate additional stats derived from count stats & sentiment

#%%time
for label, section in {'FILT_MD': 'MGNT_DISCUSSION', 'FILT_QA': 'QA_SECTION'}.items():
  
  for topic in word_set_dict.keys():
  
  # relevance = #sentences detected with topic / #total sentences
    currdf[topic + '_REL_' + label] = currdf[topic + '_TOTAL_' + label].apply(lambda x: len([a for a in x if a>0]) if len(x)>0 else None)
    currdf[topic + '_EXTRACT_' + label] = currdf[[label, topic + '_TOTAL_' + label]].apply(lambda x: ' '.join([y for y,z in zip(x[0], x[1]) if ((z>0))]), axis = 1)


# COMMAND ----------

currdf.head()

# COMMAND ----------

currdf.drop_duplicates('ENTITY_ID').describe()

# COMMAND ----------

# MAGIC %md
# MAGIC #### Generate report of top 100 calls for each topic:

# COMMAND ----------

# Recovery report

rdf = currdf.sort_values('RECOVERY_REL_FILT_MD', ascending= False)[['ENTITY_ID', 'CALL_NAME', 'EVENT_DATETIME_UTC', 'COMPANY_NAME', 'RECOVERY_REL_FILT_MD', 'RECOVERY_STATS_FILT_MD','RECOVERY_EXTRACT_FILT_MD']].drop_duplicates('ENTITY_ID').head(102).dropna(subset = ['RECOVERY_REL_FILT_MD'])
rdf = rdf[rdf['RECOVERY_REL_FILT_MD']>0]

# COMMAND ----------

# Cycle report

cdf = currdf.sort_values('CYCLE_REL_FILT_MD', ascending= False)[['ENTITY_ID', 'CALL_NAME', 'EVENT_DATETIME_UTC','COMPANY_NAME', 'CYCLE_REL_FILT_MD', 'CYCLE_STATS_FILT_MD','CYCLE_EXTRACT_FILT_MD']].drop_duplicates('ENTITY_ID').head(102).dropna(subset = ['CYCLE_REL_FILT_MD'])
cdf = cdf[cdf['CYCLE_REL_FILT_MD']>0]

# COMMAND ----------

# Supply & Demand report

sdf = currdf.sort_values('S&D_REL_FILT_MD', ascending= False)[['ENTITY_ID', 'CALL_NAME', 'EVENT_DATETIME_UTC','COMPANY_NAME', 'S&D_REL_FILT_MD', 'S&D_STATS_FILT_MD','S&D_EXTRACT_FILT_MD']].drop_duplicates('ENTITY_ID').head(102).dropna(subset = ['S&D_REL_FILT_MD'])
sdf = sdf[sdf['S&D_REL_FILT_MD']>0]

# COMMAND ----------

# Joining results of top 100 matches for each topic
concatdf = pd.concat([rdf, cdf, sdf])
concatdf.reset_index(inplace = True)
concatdf.drop(['index'], axis = 1, inplace = True)

# COMMAND ----------

# Redundant, but removes any records that have no relevance score in any topic. This happens sometimes as less than 100 records for a topic may have a match, but we sample top 100 either way.
concatdf = concatdf[(concatdf['RECOVERY_REL_FILT_MD']>0) | (concatdf['CYCLE_REL_FILT_MD']>0) | (concatdf['S&D_REL_FILT_MD']>0)]

# COMMAND ----------

# Function to switch dictionary key-value pairs and check if values>0
def simpDict(x):
  return {key : val for key, val in x.items() if val!=0}

# COMMAND ----------

# Applying function above.
for col in concatdf.columns:
  if 'STATS' in col:
    concatdf[col] = concatdf[col].apply(lambda x: simpDict(x) if type(x)==dict else None)

# COMMAND ----------

concatdf

# COMMAND ----------

# MAGIC %md
# MAGIC #### Writing to Blob

# COMMAND ----------

concatdf['REPORT_DATE'] = pd.to_datetime(maxd[1:-1])
concatdf.to_csv('/dbfs/mnt/access_work/UC25/SF_Equities_Reports/sf_equities_report_' + str(month) + '_' + str(year) + '.csv')
concatdf

# COMMAND ----------

# MAGIC %md
# MAGIC #### Configure and write to Snowflake

# COMMAND ----------

spark_parsedDF = pandas_to_spark(concatdf)
spark_parsedDF = spark_parsedDF.replace(np.nan, None)
spark_parsedDF = spark_parsedDF.withColumn("REPORT_DATE", F.to_timestamp(spark_parsedDF.REPORT_DATE, 'yyyy-MM-dd HH mm ss'))
spark_parsedDF = spark_parsedDF.withColumn("EVENT_DATETIME_UTC", F.to_timestamp(spark_parsedDF.EVENT_DATETIME_UTC, 'yyyy-MM-dd HH mm ss'))                                                                            
new_sf.db = 'EDS_PROD'
new_sf.schema = 'QUANT_STG'
 
tablename_curr = 'CTS_SF_REPORT_M_LR_1'
result_curr = new_sf.write_to_snowflake_table(spark_parsedDF, tablename_curr)

# COMMAND ----------

datetime.now()

# COMMAND ----------

