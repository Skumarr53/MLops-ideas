# Databricks notebook source
def create_text_pair(transcript, inference_template, labels):
  template = inference_template + "{label}."
  text1, text2 = [], []
  for t in transcript:
      for l in labels:
          text1.append(t)
          text2.append(template.format(label=l))
  return text1, text2


def inference_summary1(text1, text2, inference_result, labels):
  score_dict = {tp +'.': [] for tp in labels}
  for i, sentence in enumerate(text1):
    for s in inference_result[i]:
      if s['label'] == 'entailment':
        score_dict[text2[i]].append(s['score'])
  return score_dict



def inference_exec(currdf, sect, labels):
  inference_template = ""
  currdf[f'TEXT1_{sect}'] = currdf[f'FILT_{sect}'].apply(lambda x: create_text_pair(x, inference_template, labels)[0])
  currdf[f'TEXT2_{sect}'] = currdf[f'FILT_{sect}'].apply(lambda x: create_text_pair(x, inference_template, labels)[1])
  currdf[f'{sect}_RESULT'] = currdf.apply(lambda x: pl_inference1([dict(text=x[f'TEXT1_{sect}'][i], text_pair=x[f'TEXT2_{sect}'][i]) for i in range(len(x[f'TEXT1_{sect}'])) ], padding=True, top_k=None, batch_size = 16, truncation = True, max_length = 512), axis=1)
  currdf[f'{sect}_FINAL_SCORE'] = currdf.apply(lambda x: inference_summary1(x[f'TEXT1_{sect}'], x[f'TEXT2_{sect}'], x[f'{sect}_RESULT'], labels), axis=1)
  return currdf



def create_speaker_identifier_NA_last_match(row):
    """
    Create speaker identifiers with fuzzy matching for unmatched cases
    Parameters:
    -----------
    row : pandas Series
        Input row containing filtered text columns
    threshold : int, default=80
        Fuzzy matching threshold (0-100)
    Returns:
    --------
    tuple : (speaker_identifiers, na_indices)
        speaker_identifiers : list of identified speakers
        na_indices : list of indices where original matching failed
    """
    speaker_identifier = []
    na_indices = []
    filt_all_cleaned = [clean_text(sentence) for sentence in row['FILT_ALL']]
    ceo_md_cleaned = [clean_text(sentence) for sentence in row['FILT_CEO_MD']]
    exec_md_cleaned = [clean_text(sentence) for sentence in row['FILT_EXEC_MD']]
    ceo_qa_cleaned = [clean_text(sentence) for sentence in row['FILT_CEO_QA']]
    exec_qa_cleaned = [clean_text(sentence) for sentence in row['FILT_EXEC_QA']]
    anl_qa_cleaned = [clean_text(sentence) for sentence in row['FILT_ANL_QA']]
    
    last_speaker = None  # Variable to hold the last matched speaker
    for idx, sentence in enumerate(filt_all_cleaned):
        if sentence in ceo_md_cleaned:
            speaker_identifier.append('CEO')
            last_speaker = 'CEO'
        elif sentence in exec_md_cleaned:
            speaker_identifier.append('EXEC')
            last_speaker = 'EXEC'
        elif sentence in ceo_qa_cleaned:
            speaker_identifier.append('CEO')
            last_speaker = 'CEO'
        elif sentence in exec_qa_cleaned:
            speaker_identifier.append('EXEC')
            last_speaker = 'EXEC'
        elif sentence in anl_qa_cleaned:
            speaker_identifier.append('ANL')
            last_speaker = 'ANL'
        else:
            # If no exact match, use the last known speaker
            na_indices.append(idx)
            if last_speaker is not None:
                speaker_identifier.append(last_speaker)
            else:
                speaker_identifier.append('CEO')  # If no previous speaker exists
    return speaker_identifier

def text_clean(txt):
  txt = re.sub(r'\s+', ' ', txt)
  return txt.strip()

def clean_text(text):
    text = re.sub(r'[^A-Za-z0-9\s]', '', text)
    text = re.sub(r'\s+', ' ', text)
    return text.strip()

def get_max_label(row, section, labels):
  max_labels = []
  for pos, neu, neg in zip(row['This text has the positive sentiment._SCORE_' + section], row['This text has the neutral sentiment._SCORE_' + section], row['This text has the negative sentiment._SCORE_'  + section]):
    if pos >= neu and pos >= neg:
        max_labels.append(1)
    elif neu >= pos and neu >= neg:
        max_labels.append(0)
    else:
        max_labels.append(-1)
  return max_labels


def combine_lists(row, md_col, qa_col):
    if row[md_col] and row[qa_col]:
        return row[md_col] + row[qa_col]
    elif row[md_col]:
        return row[md_col]
    elif row[qa_col]:
        return row[qa_col]
    else:
        return []


# Function to replace phrases in column names
def replace_phrases(col_name, replacements):
    for phrase, abbreviation in replacements.items():
        col_name = col_name.replace(phrase, abbreviation)
    return col_name

def  compute_net_sentiment_score(data):
  pos, neg, neu = data
  pos, neg, neu = np.array(pos), np.array(neg), np.array(neu)
  net_sentiment_score = (pos - neg)/(pos + neg + neu)
  return [float(val) for val in net_sentiment_score]

def extract_inf(row, section, section_len):
  count_col = {}
  rel_col = {}
  score_col = {}
  total_col = {}
  for tp, score in row.items():
    if section_len != 0:
      score_col[f'{tp}_SCORE_{section}'] = [round(s, 4) for s in score]
    else:
      score_col[f'{tp}_SCORE_{section}'] = []

  return pd.Series({**score_col})

def combine_lists(row, md_col, qa_col):
    if row[md_col] and row[qa_col]:
        return row[md_col] + row[qa_col]
    elif row[md_col]:
        return row[md_col]
    elif row[qa_col]:
        return row[qa_col]
    else:
        return []

# Auxiliar functions
def equivalent_type(string, f):
    print(string, f)
   # if 'DATE' == string: return StringType()
    
    if f == 'datetime64[ns]': return TimestampType()
    elif f == 'int64': return LongType()
    elif f == 'int32': return IntegerType()
    elif f == 'float64': return FloatType()
    elif 'FILT_MD' == string: return ArrayType(StringType())
    elif 'FILT_QA' == string: return ArrayType(StringType())
    elif 'FILT_ALL' == string: return ArrayType(StringType())
    elif 'sent_labels' in string.lower(): return ArrayType(IntegerType())
    elif '_score_' in string.lower(): return ArrayType(FloatType())
    elif 'net_sentiment_score' in string.lower(): return ArrayType(FloatType())
    elif 'IDENTIFIER' in string.upper(): return ArrayType(StringType())
 #   elif f == 'object': return ArrayType()
 #   elif f == 'list': return ArrayType()
    else: return StringType()

def define_structure(string, format_type):
    #try: 
    typo = equivalent_type(string, format_type)
    print(typo)
    #except: typo = StringType()
    return StructField(string, typo)

# Given pandas dataframe, it will return a spark's dataframe.
def pandas_to_spark(pandas_df):
    columns = list(pandas_df.columns)
    types = list(pandas_df.dtypes)
    struct_list = []
    for column, typo in zip(columns, types): 
      struct_list.append(define_structure(column, typo))
    p_schema = StructType(struct_list)
    return sqlContext.createDataFrame(pandas_df, p_schema)