# Databricks notebook source
# MAGIC %md
# MAGIC # NLI using transformers

# COMMAND ----------

!pip install transformers==4.40.1
!pip install --upgrade safetensors

dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Import Modules

# COMMAND ----------

# MAGIC %run ./../../../../data-science-nlp-ml-common-code/impackage/utilities/config_utility

# COMMAND ----------

# MAGIC %run ./../../../../data-science-nlp-ml-common-code/impackage/database/snowflake_dbutility

# COMMAND ----------

# MAGIC %run ./helper

# COMMAND ----------

# MAGIC %run ./constants

# COMMAND ----------

new_sf = SnowFlakeDBUtility(config.schema, config.eds_db_prod)

# COMMAND ----------

import ast
from IPython.display import clear_output
import numpy as np
from dateutil.relativedelta import relativedelta
import pickle 
import pandas as pd
import multiprocessing as mp

# Load model directly
from transformers import pipeline
from transformers import AutoTokenizer, AutoModelForSequenceClassification, AutoModel
from transformers import TextClassificationPipeline
from transformers import ZeroShotClassificationPipeline
from pyspark.sql.functions import current_timestamp
import torch


# COMMAND ----------

# MAGIC %md
# MAGIC ## User Configuration

# COMMAND ----------


device = 0 if torch.cuda.is_available() else -1

model_1_folder_name = "deberta-v3-large-zeroshot-v2"

model_folder_path = "/dbfs/mnt/access_work/UC25/Libraries/HuggingFace/"

tokenizer_1 = AutoTokenizer.from_pretrained(model_folder_path + model_1_folder_name)
model_1 = AutoModelForSequenceClassification.from_pretrained(model_folder_path + model_1_folder_name)


pl_inference1 = pipeline(task="text-classification", model = model_1, tokenizer = tokenizer_1, device = device)

OUT_TABLE = "YUJING_ECALL_NLI_SENTIMENT_SCORE_PY_DEV_4"

# COMMAND ----------

class_data_path = "/dbfs/mnt/access_work/UC25/Topic Modeling/NLI Models/"

# COMMAND ----------

# MAGIC %md
# MAGIC # Read raw data

# COMMAND ----------

# MAGIC %md
# MAGIC ## Query data if no csv exists

# COMMAND ----------

tsQuery = f"""
            SELECT
                CAST(CALL_ID AS STRING) AS CALL_ID,
                ENTITY_ID,
                DATE,
                FILT_MD,
                FILT_QA,
                FILT_CEO_MD, FILT_EXEC_MD, FILT_CEO_QA, FILT_EXEC_QA, FILT_ANL_QA,
                CALL_NAME,
                COMPANY_NAME,
                EARNINGS_CALL,
                ERROR,
                TRANSCRIPT_STATUS,
                UPLOAD_DT_UTC,
                VERSION_ID,
                EVENT_DATETIME_UTC,
                PARSED_DATETIME_EASTERN_TZ,
                SENT_LABELS_FILT_QA,
                SENT_LABELS_FILT_MD
            FROM
                EDS_PROD.QUANT_LIVE.CTS_FUND_COMBINED_SCORES_H t2
            WHERE
                NOT EXISTS (
                    SELECT 1
                    FROM EDS_PROD.{config.schema}.{OUT_TABLE} t1
                    WHERE
                        CAST(t1.CALL_ID AS VARCHAR(16777216)) = CAST(t2.CALL_ID AS VARCHAR(16777216)) AND
                        t1.ENTITY_ID = t2.ENTITY_ID AND
                        t1.VERSION_ID = t2.VERSION_ID
                )
            ORDER BY
                PARSED_DATETIME_EASTERN_TZ DESC
      """
resultspkdf = new_sf.read_from_snowflake(tsQuery)

currdf = resultspkdf.toPandas()

if len(currdf)>0:
    print('The data spans from ' + str(currdf['PARSED_DATETIME_EASTERN_TZ'].min()) + ' to ' + str(currdf['PARSED_DATETIME_EASTERN_TZ'].max()) + 'and has ' + str(currdf.shape[0]) + ' rows and ' + str(currdf.shape[1]) + ' columns.')
else:
    print('No new transcripts to parse.')
    dbutils.notebook.exit(1)
    os._exit(1)

# COMMAND ----------

for col in EVAL_LIT_COLS:
    currdf[col] = currdf[col].apply(ast.literal_eval)

currdf['LEN_FILT_MD'] = currdf['FILT_MD'].apply(len)
currdf['LEN_FILT_QA'] = currdf['FILT_QA'].apply(len)

# COMMAND ----------

currdf = inference_exec(currdf, 'MD', LABELS)
currdf = inference_exec(currdf, 'QA', LABELS)

# COMMAND ----------


# Combine 'FILT_MD' and 'FILT_QA' into 'FILT_ALL'
currdf['FILT_ALL'] = currdf['FILT_MD'] + currdf['FILT_QA']

# Create 'SECTION_IDENTIFIER' and SPEAKER IDENTIFIER column
currdf['SECTION_IDENTIFIER'] = [['MD'] * len(md) + ['QA'] * len(qa) for md, qa in zip(currdf['FILT_MD'], currdf['FILT_QA'])]
currdf['SPEAKER_IDENTIFIER'] = currdf.apply(create_speaker_identifier_NA_last_match, axis=1)

# COMMAND ----------

currdf_all = pd.concat([currdf[MER_RETAIN_COLS],currdf.apply(lambda x: extract_inf(x['MD_FINAL_SCORE'], 'FILT_MD', x['LEN_FILT_MD']), axis =1), currdf.apply(lambda x: extract_inf(x['QA_FINAL_SCORE'], 'FILT_QA', x['LEN_FILT_QA']), axis =1)], axis=1)

# COMMAND ----------


# Apply the function to create the new column
currdf_all['NLI_SENT_LABELS_FILT_MD'] = currdf_all.apply(lambda x: get_max_label(x, 'FILT_MD', LABELS), axis=1)
currdf_all['NLI_SENT_LABELS_FILT_QA'] = currdf_all.apply(lambda x: get_max_label(x, 'FILT_QA', LABELS), axis=1)

# COMMAND ----------

currdf_all['DATE'] = pd.to_datetime(currdf_all['DATE'])
currdf_all['UPLOAD_DT_UTC'] = pd.to_datetime(currdf_all['UPLOAD_DT_UTC'])
currdf_all['PARSED_DATETIME_EASTERN_TZ'] = pd.to_datetime(currdf_all['PARSED_DATETIME_EASTERN_TZ'])

# COMMAND ----------

# Apply the function to rename columns
currdf_all.rename(columns=lambda x: replace_phrases(x, REPLACEMENTS), inplace=True)

# COMMAND ----------

# Define the (col1, col2, target_col) triplets
combine_targets = [
    ('SENT_LABELS_FILT_MD', 'SENT_LABELS_FILT_QA', 'SENT_LABELS_FILT_ALL'),
    ('POS_SCORE_FILT_MD', 'POS_SCORE_FILT_QA', 'POS_SCORE_FILT_ALL'),
    ('NEG_SCORE_FILT_MD', 'NEG_SCORE_FILT_QA', 'NEG_SCORE_FILT_ALL'),
    ('NEU_SCORE_FILT_MD', 'NEU_SCORE_FILT_QA', 'NEU_SCORE_FILT_ALL'),
    ('NLI_SENT_LABELS_FILT_MD', 'NLI_SENT_LABELS_FILT_QA', 'NLI_SENT_LABELS_FILT_ALL'),
]
 
# Perform combining in a loop
for col1, col2, target in combine_targets:
    currdf_all[target] = currdf_all.apply(lambda x: combine_lists(x, col1, col2), axis=1)

# COMMAND ----------

## calculate sentiment score 
with mp.Pool(min(mp.cpu_count(), 16)) as pool:
  currdf_all['NET_SENTIMENT_SCORE'] = pool.map(compute_net_sentiment_score, zip(currdf_all['POS_SCORE_FILT_ALL'], 
                                                                                       currdf_all['NEG_SCORE_FILT_ALL'], 
                                                                                       currdf_all['NEU_SCORE_FILT_ALL']))

# COMMAND ----------


currdf_all = currdf_all.rename(columns=FIN_RNM_COLS)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Section to add Sentiment Score and Identifiers

# COMMAND ----------

spark_parsedDF = pandas_to_spark(currdf_all)
spark_parsedDF = spark_parsedDF.replace(np.nan, None)
spark_parsedDF = spark_parsedDF.withColumn("DATE", F.to_timestamp(spark_parsedDF.DATE, 'yyyy-MM-dd'))
spark_parsedDF = spark_parsedDF.withColumn("UPLOAD_DT_UTC", F.to_timestamp(spark_parsedDF.UPLOAD_DT_UTC, 'yyyy-MM-dd'))
spark_parsedDF = spark_parsedDF.withColumn("PARSED_DATETIME_EASTERN_TZ", F.to_timestamp(spark_parsedDF.PARSED_DATETIME_EASTERN_TZ, 'yyyy-MM-dd HH mm ss'))
spark_parsedDF = spark_parsedDF.withColumn("BATCH_LOAD_DT", current_timestamp())

spark_parsedDF = spark_parsedDF.select(FIN_FIXED_COLS)                    

 
result_curr = new_sf.write_to_snowflake_table(spark_parsedDF, OUT_TABLE)

# COMMAND ----------

