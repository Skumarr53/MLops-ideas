# Databricks notebook source
# MAGIC %md
# MAGIC ### INSTRUCTIONS
# MAGIC
# MAGIC Get the stats metrics for topics from re-estimated model

# COMMAND ----------

!pip install gensim==4.2.0
!pip install spacy==3.4.4
!pip install https://github.com/explosion/spacy-models/releases/download/en_core_web_sm-3.4.0/en_core_web_sm-3.4.0.tar.gz
!pip install dask distributed --upgrade
!pip install dask==2023.5.0

# COMMAND ----------

pip install -U pydantic spacy==3.4.4

# COMMAND ----------

# MAGIC %run "./../../package_loader/call_transcript_NLP_BERT_libs_stg5_pl4.py" 

# COMMAND ----------

# MAGIC %run ./../../../data-science-nlp-ml-common-code/impackage/utilities/config_utility

# COMMAND ----------

# MAGIC %run ./../../../data-science-nlp-ml-common-code/impackage/database/snowflake_dbutility

# COMMAND ----------

from dateutil.relativedelta import relativedelta

# COMMAND ----------

#import seaborn as sns
#from gensim.models import Word2Vec
import spacy
from spacy.lang.en import English
#from transformers import TextClassificationPipeline
import pandas as pd
import numpy as np
import spacy
import tqdm
from tqdm import tqdm
tqdm.pandas()
#import sklearn.datasets
#import plotly.express as px
#from gensim.models import Phrases
from collections import Counter
import dask.dataframe as dd
from dask.distributed import Client
from dask.diagnostics import ProgressBar
import gc
from pandas.tseries.offsets import MonthBegin, MonthEnd

# Dask client - intended for NC6 v3 GPU instance
client = Client(n_workers=32, threads_per_worker=1)

# COMMAND ----------

new_sf = SnowFlakeDBUtility(config.schema, config.eds_db_prod)

# COMMAND ----------

end_date = datetime.now() 
start_date = datetime.now() - relativedelta(months=27)

# COMMAND ----------

minDateNewQuery = (pd.to_datetime(format(start_date, '%m') + "-01-" + format(start_date, '%Y'))).strftime('%Y-%m-%d')
maxDateNewQuery = (pd.to_datetime(format(end_date, '%m') + "-01-" + format(end_date, '%Y'))).strftime('%Y-%m-%d')

mind = "'" + minDateNewQuery + "'"
maxd = "'" + maxDateNewQuery + "'"
print(mind, maxd)

# COMMAND ----------

# Query all parsed transcripts parsed after the last known parsed date.
tsQuery= ("select CALL_ID,ENTITY_ID, DATE, FILT_MD, FILT_QA, CALL_NAME,COMPANY_NAME,EARNINGS_CALL,ERROR,TRANSCRIPT_STATUS,UPLOAD_DT_UTC,VERSION_ID,EVENT_DATETIME_UTC,PARSED_DATETIME_EASTERN_TZ from EDS_PROD.QUANT.PARTHA_FUND_CTS_STG_1_VIEW t2 "
"WHERE DATE >= " + mind + " AND DATE < " + maxd + " ORDER BY PARSED_DATETIME_EASTERN_TZ DESC;")

resultspkdf = new_sf.read_from_snowflake(tsQuery)

currdf = resultspkdf.toPandas()

if len(currdf)>0:
    print('The data spans from ' + str(currdf['PARSED_DATETIME_EASTERN_TZ'].min()) + ' to ' + str(currdf['PARSED_DATETIME_EASTERN_TZ'].max()) + 'and has ' + str(currdf.shape[0]) + ' rows and ' + str(currdf.shape[1]) + ' columns.')
else:
    print('No new transcripts to parse.')
    dbutils.notebook.exit(1)
    os._exit(1)

# COMMAND ----------

currdf.sort_values('DATE')

# COMMAND ----------

currdf['FILT_MD'] = currdf['FILT_MD'].apply(ast.literal_eval)
currdf['FILT_QA'] = currdf['FILT_QA'].apply(ast.literal_eval)
# currdf['SENT_LABELS_FILT_MD'] = currdf['SENT_LABELS_FILT_MD'].apply(ast.literal_eval)
# currdf['SENT_LABELS_FILT_QA'] = currdf['SENT_LABELS_FILT_QA'].apply(ast.literal_eval)

currdf['LEN_FILT_MD'] = currdf['FILT_MD'].apply(len)
currdf['LEN_FILT_QA'] = currdf['FILT_QA'].apply(len)


# COMMAND ----------

currdf = currdf.sort_values(by = ['ENTITY_ID', 'DATE','PARSED_DATETIME_EASTERN_TZ']).drop_duplicates(subset = ['ENTITY_ID','DATE'], keep = 'last')

# COMMAND ----------

currdf

# COMMAND ----------

del resultspkdf

# COMMAND ----------

nlp = spacy.load("en_core_web_sm", disable = ['parser'])

# Excluding financially relavant stopwords
nlp.Defaults.stop_words -= {"bottom", "top", "Bottom", "Top", "call", "down"}
nlp.max_length = 1000000000


# Lemmatizer - for document text
def wordTokenize(doc):
  
  return [ent.lemma_.lower() for ent in nlp(doc) if not ent.is_stop and not ent.is_punct and ent.pos_ != 'NUM']


# Tokenizer/lemmatizer for match words
def matchTokenize(doc):
  ret = []
  for ent in nlp(doc):
    if ent.pos_ == 'PROPN' or ent.text[0].isupper(): #ent.pos_ == 'PROPN' or 
      ret.append(ent.text.lower())
      continue
    if not ent.is_stop and not ent.is_punct and ent.pos_ != 'NUM':
      ret.append(ent.lemma_.lower())
  return ret


# Creates n grams helper fxn
def find_ngrams(input_list, n):
  return zip(*[input_list[i:] for i in range(n)])


sections = ['FILT_MD', 'FILT_QA']

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Word list counts
# MAGIC

# COMMAND ----------

def is_valid_keyword(keyword):
  token = nlp(keyword)[0]
  return not (token.is_stop or token.is_punct)

# COMMAND ----------

# Create a set of match patterns from match list. This ensures variations such as lemmas & case are handled.
def get_match_set(matches):
  
  bigrams = set([word.lower() for word in matches if len(word.split('_'))==2] + [word.lower().replace(" ", '_') for word in matches if len(word.split(' '))==2] + ['_'.join(matchTokenize(word)) for word in matches if len(word.split(' '))==2])
 
  unigrams = set([matchTokenize(match)[0] for match in matches if ('_' not in match) and (len(match.split(' '))==1) and (len(matchTokenize(match)))] + [match.lower() for match in matches if ('_' not in match) and (len(match.split(' '))==1)])

#  phrases = set([phrase.lower() for phrase in matches if len(phrase.split(" "))>2] + [' '.join(matchTokenize(phrase)) for phrase in matches if len(phrase.split(" "))>2])

#  Phrase matching correction
  phrases = [phrase.lower() for phrase in matches if len(phrase.split(" "))>2]
  
  #print(matches)
  #print(unigrams, bigrams, phrases)
  return {'original': matches, 'unigrams': unigrams, 'bigrams': bigrams, 'phrases': phrases}

# COMMAND ----------

def match_count_lowStat(texts, match_sets):

  total_counts = {label: 0 for label in match_sets.keys()}

  for text in texts:

    counted = {label: 0 for label in match_sets.keys()}
    text = text.lower()
    unigrams = wordTokenize(text)
    bigrams = ['_'.join(g) for g in find_ngrams(unigrams, 2)]
    
    for label, word_set in word_set_dict.items():
      if set(unigrams) & set(word_set['unigrams']) or set(bigrams) & set(word_set['bigrams']):
        total_counts[label] += 1
    
  return total_counts

# COMMAND ----------


# Counting fxn. Phrase matching increases compute time - consider use case before enabling it. Set to true as fxn default.
def match_count_lowStat_old(texts, match_sets):

  total_counts = {label: 0 for label in match_sets.keys()}

  for text in texts:
    
    counted = {label: 0 for label in match_sets.keys()}
    unigrams = wordTokenize(text)
    bigrams = ['_'.join(g) for g in find_ngrams(unigrams, 2)]
    
    text = text.lower()

    #unigrams = {label: any(item in unigrams for item in match_set['unigrams']) for label, match_set in match_sets.items()}
    #bigrams = {label: any(item in bigrams for item in match_set['bigrams']) for label, match_set in match_sets.items()}
    # final = [uni OR bi for uni, bi in zip(unigrams, bigrams)]
    unigrams_dict = {label: any(item in unigrams for item in match_words['unigrams']) for label, match_words in match_sets.items()}
    bigrams_dict = {label: any(item in bigrams for item in match_words['bigrams']) for label, match_words in match_sets.items()}
    final = {label: unigrams_dict.get(label, False) or bigrams_dict.get(label, False) for label in match_sets.keys()}
    filtered_final = {k: v for k, v in final.items() if v}
    if filtered_final != dict():
      for label, is_true in filtered_final.items():
        total_counts[label] += 1

    
  return total_counts
    


# Used to merge dictionaries that keep track of word counts 
def mergeCount(x):
  
  try:
    merge = Counter(x[0])
 
    for calc in x[1:]:

      merge = merge + Counter(calc)
    if len(merge.keys())==0:
      return {'NO_MATCH': 1}
    return merge
  except:
    return {'ERROR': 1}
  
def sentscore(a, b, weight = True):
  
  # number of relevant sentences
      
  length = len(a)
  if length==0:
      return None
  if length!=len(b):
      return None
  num = len([x for x in a if x>0])
  
  if num==0:
      return None
   
  if weight==True:
    return np.dot(a,b)/num
  else:
    return np.dot([1 if x>0 else 0 for x in a], b)/num

def netscore(a, b):
  
  # number of relevant sentences
      
  length = len(a)
  if length==0:
      return None
  if length!=len(b):
      return None
  num = len([x for x in a if x>0])
  
  if num==0:
      return None
   
  return np.dot([1 if x>0 else 0 for x in a], b)
# def statscore(a, b):
  
  
  
#   c = 
  
#   return []

# COMMAND ----------

earnings_quarter = datetime.now() - relativedelta(months=3)
quarter = (earnings_quarter.month - 1) // 3 + 1
update_quarter = f"{earnings_quarter.year % 100}Q{quarter}"
print(update_quarter)

# COMMAND ----------

m2_cluster_tp_path = '/dbfs/mnt/access_work/UC25/Topic Modeling/DTM Phase2/pipeline_results/new_tp_E' + update_quarter +'_v1.csv'

# COMMAND ----------

m2_cluster_tp_path

# COMMAND ----------

m2_cluster_tp_df = pd.read_csv(m2_cluster_tp_path)

# COMMAND ----------

m2_cluster_tp_df.head(2)

# COMMAND ----------

m2_cluster_tp_df['Top 5 keywords (m2)'] = m2_cluster_tp_df['Top 5 keywords (m2)'].apply(ast.literal_eval)
m2_cluster_tp_df['Top 60 keywords + cosine (m2)'] = m2_cluster_tp_df['Top 60 keywords + cosine (m2)'].apply(ast.literal_eval)

# COMMAND ----------

m2_keywords_df = pd.DataFrame([])
m2_keywords_df['Topic_name'] = m2_cluster_tp_df.apply(lambda x: str(x['Topic (m2)']) + "_" + "_".join(x['Top 5 keywords (m2)'][:3]), axis =1)
m2_keywords_df['Topic_keywords'] = m2_cluster_tp_df['Top 60 keywords + cosine (m2)'].apply(lambda x: [w for w, cos in x[:25]])
m2_keywords_df = m2_keywords_df.explode('Topic_keywords')

# COMMAND ----------



# COMMAND ----------

match_df = m2_keywords_df

# COMMAND ----------

match_df['negate'] = False

# COMMAND ----------

match_df

# COMMAND ----------

match_df = match_df.rename(columns={'Topic_name':'label','Topic_keywords':'match'})

# COMMAND ----------

match_df = match_df[~match_df['match'].str.isnumeric()]

# COMMAND ----------

match_df = match_df[match_df['match'].apply(is_valid_keyword)]

# COMMAND ----------

match_df

# COMMAND ----------



# COMMAND ----------

# Read match list
word_set_dict = {topic.replace(' ', '_') : get_match_set(match_df[(match_df['label']==topic) & (match_df['negate']==False)]['match'].values) for topic in match_df['label'].unique()}

# COMMAND ----------

word_set_dict

# COMMAND ----------

currdf_test = currdf

# COMMAND ----------

currdf_test = dd.from_pandas(currdf_test, npartitions = 32)
for label, section in {'FILT_MD': 'FILT_MD', 'FILT_QA': 'FILT_QA'}.items():

  currdf_test['new_matches_' + label] = currdf_test[section].apply(lambda x: match_count_lowStat(x, word_set_dict), meta = ('new_matches_' + label, object))
  #currdf[label] = currdf['matches_' + label].apply(lambda x: [str(calc['filt']) for calc in x], meta = ('FILT_' + label, object))

# COMMAND ----------

gc.collect()

# COMMAND ----------

# Running Dask compute
#%%time
with ProgressBar():
  currdf_test = currdf_test.compute()

# COMMAND ----------

currdf_test

# COMMAND ----------

# Dask is not used for below code due to unfixable bugs
# Below code only used to aggregate stats and organize data

#%%time
for label, section in {'FILT_MD': 'MGNT_DISCUSSION', 'FILT_QA': 'QA_SECTION'}.items():
  
  for topic in word_set_dict.keys():
    currdf_test[topic + '_TOTAL_' + label] = currdf_test['new_matches_' + label].apply(lambda x: x[topic])

  currdf_test.drop(['new_matches_' + label], axis = 1, inplace = True)
  # gc.collect()
  

# COMMAND ----------

currdf_test.drop(['FILT_MD', 'FILT_QA'], axis = 1, inplace = True)

# COMMAND ----------

currdf_test

# COMMAND ----------

# Calculate rel scores

#%%time
for label, section in {'FILT_MD': 'MGNT_DISCUSSION', 'FILT_QA': 'QA_SECTION'}.items():
  for topic in word_set_dict.keys():
  
  # relevance = #sentences detected with topic / #total sentences
    currdf_test[topic + '_REL_' + label] = currdf_test.apply(lambda x: x[topic + '_TOTAL_' + label]/x['LEN_' + label] if x['LEN_' + label]>0 else None, axis = 1)
       

# COMMAND ----------

currdf_test.head(20)

# COMMAND ----------



# COMMAND ----------

currdf_test['LEN_' + 'ALL'] = currdf_test.apply(lambda x: x['LEN_' + 'FILT_MD'] + x['LEN_' + 'FILT_QA'], axis = 1)    

# COMMAND ----------

for topic in word_set_dict.keys():   
  currdf_test[topic + '_REL_' + 'ALL'] = currdf_test.apply(lambda x: (x[topic + '_REL_' + 'FILT_MD'] * x['LEN_' + 'FILT_MD'] + x[topic + '_REL_' + 'FILT_QA'] * x['LEN_' + 'FILT_QA'])/ x['LEN_' + 'ALL'] if x['LEN_' + 'ALL'] > 0 else None, axis = 1)
  

# COMMAND ----------

def get_period(months_since_start):
  start_month = start_date + MonthBegin() * (months_since_start * 3)
  end_month = start_month + MonthEnd(3)
  return f"{start_month.strftime('%Y/%m')} - {end_month.strftime('%Y/%m')}"

# COMMAND ----------

# Create 'formatted_period' column to record data for the 3-month period it falls into. 'formatted_period' follows yyyy/mm-yyyy/mm format where includes 3 months.
start_date = currdf_test['DATE'].min()
currdf_test['period_index'] = ((pd.to_datetime(currdf_test['DATE'], format='%Y-%m-%d').dt.year - start_date.year) * 12 + pd.to_datetime(currdf_test['DATE'], format='%Y-%m-%d').dt.month - start_date.month)
currdf_test['period'] = np.floor(currdf_test['period_index'] / 3)
currdf_test['formatted_period'] = currdf_test['period'].apply(lambda x: get_period(int(x)))

# COMMAND ----------



# COMMAND ----------

stats_df = pd.DataFrame([])

for topic in word_set_dict.keys(): 
   stats_df[topic + '_REL'] = currdf_test.groupby('formatted_period')[topic + '_REL_' + 'ALL'].mean(numeric_only=False).to_frame()

# COMMAND ----------

stats_df

# COMMAND ----------

# Record the month precent within each period.
currdf_test['year-month'] = pd.to_datetime(currdf_test['DATE'], format='%Y-%m-%d').dt.to_period('M')
month_count = pd.DataFrame({'count': currdf_test.groupby(['formatted_period', 'year-month']).size()}).reset_index()

# COMMAND ----------

month_count['month_start'] = pd.to_datetime(month_count['year-month'].dt.strftime('%Y-%m-01'))

# COMMAND ----------

month_count.drop(columns= ['formatted_period'], inplace=True)

# COMMAND ----------

month_count.rename(columns = {'year-month':'year_month'}, inplace=True)

# COMMAND ----------

month_count['year_month'] = month_count['year_month'].apply(str)

# COMMAND ----------

plot_df = stats_df.reset_index()
stats_df = stats_df.T.reset_index()
stats_df.columns = [str(c) for c in stats_df.columns]

# COMMAND ----------

stats_df

# COMMAND ----------

# Create table with Qo4Q avg relevance score
yoy_stats_df = pd.DataFrame() 
periods = list(stats_df.columns[-5:])
for p in periods:
  prev_p = str(int(p[:4]) - 1) + p[4:10] + str(int(p[10:14]) - 1) + p[14:]
  if prev_p in stats_df:
    yoy_stats_df[p +'/' + prev_p] = (stats_df[p] - stats_df[prev_p]) / stats_df[prev_p]
  else:
    pass

# COMMAND ----------

yoy_stats_df

# COMMAND ----------

yoy_plot_df = yoy_stats_df.T.reset_index()

# COMMAND ----------

yoy_plot_df

# COMMAND ----------

# new slope (Qo4Q change)
yoy_plot_concat_norm_df = yoy_plot_df.iloc[:,1:].clip(lower = -1, upper = 1) # Keep the Qo4Q within -1 to 1.
yoy_slope_df = pd.DataFrame(list(word_set_dict.keys()), columns = ['Topic'])
for periods in [5]:
  slope_dic = {}
  intercept_dic = {}
  for col in yoy_plot_concat_norm_df.columns:
    # Time variable (X) is [-2, -1, 0, 1, 2]. Intercept shows the estimated Qo4Q change at time 0 which is the middle of time variable.
    slope_dic[col] = np.polyfit(np.arange(periods) - 2, yoy_plot_concat_norm_df[col][-1 * periods:],1)[0]  #
    intercept_dic[col] = np.polyfit(np.arange(periods) - 2, yoy_plot_concat_norm_df[col][-1 * periods:],1)[1]
  yoy_slope_df[str(periods) + '-quarter slope (Qo4Q)'] = slope_dic.values() 
  yoy_slope_df[str(periods) + '-quarter intercept (Qo4Q)'] = intercept_dic.values()   

# COMMAND ----------

yoy_stats_df['Topic'] = stats_df['index']

# COMMAND ----------

stats_df

# COMMAND ----------

ma_stats_df = pd.DataFrame()
period_columns = stats_df.columns[1:]
for column in period_columns:
  ma_stats_df[column +'_ma'] = stats_df[stats_df.columns[1:]].rolling(window=4, min_periods=1, axis=1).mean()[column]

# COMMAND ----------

ma_plot_df = ma_stats_df[ma_stats_df.columns[4:]].T.reset_index()

# COMMAND ----------

ma_plot_df

# COMMAND ----------

# new slope (MA change)
ma_plot_concat_norm_df = ma_plot_df.iloc[:,1:].apply(lambda x: x/x.sum(), axis = 0)
ma_slope_df = pd.DataFrame(list(word_set_dict.keys()), columns = ['Topic'])
for periods in [5]:
  slope_dic = {}
  intercept_dic = {}
  for col in ma_plot_concat_norm_df.columns:
    slope_dic[col] = np.polyfit(np.arange(periods), ma_plot_concat_norm_df[col][-1 * periods:],1)[0]  #
    intercept_dic[col] = np.polyfit(np.arange(periods), ma_plot_concat_norm_df[col][-1 * periods:],1)[1]
  ma_slope_df[str(periods) + '-quarter slope (MA)'] = slope_dic.values() 
  ma_slope_df[str(periods) + '-quarter intercept (MA)'] = intercept_dic.values()   

# COMMAND ----------

ma_slope_df.sort_values(by=['5-quarter slope (MA)']).tail(15)

# COMMAND ----------

stats_df_old = stats_df.copy()

# COMMAND ----------

stats_df_old

# COMMAND ----------

stats_df = stats_df.drop(columns=stats_df.columns[1:5])  #['2021Q3','2021Q4','2022Q1', '2022Q2']

# COMMAND ----------

stats_df

# COMMAND ----------

plot_concat_norm_df = plot_df.loc[4:,:].iloc[:,1:].apply(lambda x: x/x.sum(), axis = 0)
slope_df = pd.DataFrame(list(word_set_dict.keys()), columns = ['Topic'])
for periods in [5]:
  slope_dic = {}
  for col in plot_concat_norm_df.columns:
    slope_dic[col] = np.polyfit(np.arange(periods), plot_concat_norm_df[col][-1 * periods:],1)[0]
  slope_df[str(periods) + '-quarter slope'] = slope_dic.values()  

# COMMAND ----------

slope_df.sort_values('5-quarter slope')

# COMMAND ----------

currdf_test.DATE = pd.to_datetime(currdf_test.DATE)#.strftime('%Y-%m-%d')

# COMMAND ----------

# Get the dates for REL table.
data_end_date = datetime.now() 
data_start_date = datetime.now() - relativedelta(months=27)
data_last_month = datetime.now() - relativedelta(months=1)

# COMMAND ----------

current_date = datetime.strptime(maxDateNewQuery, '%Y-%m-%d')

# COMMAND ----------

date_1q = (current_date - relativedelta(months=3)).strftime('%Y-%m-%d')
date_2q = (current_date - relativedelta(months=6)).strftime('%Y-%m-%d')
date_3q = (current_date - relativedelta(months=9)).strftime('%Y-%m-%d')
date_4q = (current_date - relativedelta(months=12)).strftime('%Y-%m-%d')
date_5q = (current_date - relativedelta(months=15)).strftime('%Y-%m-%d')

# COMMAND ----------

print(current_date, date_1q)

# COMMAND ----------

# Calculate the company coverage rate
out_test1 = currdf_test.loc[(currdf_test.DATE >= date_1q) & (currdf_test.DATE < maxDateNewQuery), :]
out_test1 = out_test1.sort_values(by=['DATE']).drop_duplicates(subset='ENTITY_ID', keep='last').copy()
coverage_df = pd.DataFrame(list(word_set_dict.keys()), columns = ['Topic'])
coverage_df['company coverage rate'+ '(' + stats_df.columns[5] + ')'] = coverage_df['Topic'].apply(lambda x: sum([ 1 for i in out_test1[x+'_REL_ALL'] if i > 0])/len(out_test1))

# COMMAND ----------

# Calculate the company coverage rate (1-quarter ago)
out_test2 = currdf_test.loc[(currdf_test.DATE >= date_2q) & (currdf_test.DATE < date_1q), :]
out_test2 = out_test2.sort_values(by=['DATE']).drop_duplicates(subset='ENTITY_ID', keep='last').copy()
coverage_df['company coverage rate'+ '(' + stats_df.columns[4] + ')'] = coverage_df['Topic'].apply(lambda x: sum([ 1 for i in out_test2[x+'_REL_ALL'] if i > 0])/len(out_test2))

# COMMAND ----------

# Calculate the company coverage rate (2-quarter ago)
out_test3 = currdf_test.loc[(currdf_test.DATE >= date_3q) & (currdf_test.DATE < date_2q), :]
out_test3 = out_test3.sort_values(by=['DATE']).drop_duplicates(subset='ENTITY_ID', keep='last').copy()
coverage_df['company coverage rate'+ '(' + stats_df.columns[3] + ')'] = coverage_df['Topic'].apply(lambda x: sum([ 1 for i in out_test3[x+'_REL_ALL'] if i > 0])/len(out_test3))

# COMMAND ----------

# Calculate the company coverage rate (3-quarter ago)
out_test4 = currdf_test.loc[(currdf_test.DATE >= date_4q) & (currdf_test.DATE < date_3q), :]
out_test4 = out_test4.sort_values(by=['DATE']).drop_duplicates(subset='ENTITY_ID', keep='last').copy()
coverage_df['company coverage rate'+ '(' + stats_df.columns[2] + ')'] = coverage_df['Topic'].apply(lambda x: sum([ 1 for i in out_test4[x+'_REL_ALL'] if i > 0])/len(out_test4))

# COMMAND ----------

# Calculate the company coverage rate (12 months ago)
out_test5 = currdf_test.loc[(currdf_test.DATE >= date_5q) & (currdf_test.DATE < date_4q), :]
out_test5 = out_test5.sort_values(by=['DATE']).drop_duplicates(subset='ENTITY_ID', keep='last').copy()
coverage_df['company coverage rate'+ '(' + stats_df.columns[1] + ')'] = coverage_df['Topic'].apply(lambda x: sum([ 1 for i in out_test5[x+'_REL_ALL'] if i > 0])/len(out_test5))

# COMMAND ----------

coverage_df["coverage rate diff ("+ stats_df.columns[5] + "/" + stats_df.columns[4] + ")"] = coverage_df.apply(lambda x: (x['company coverage rate'+ '(' + stats_df.columns[5] + ')'] - x['company coverage rate'+ '(' + stats_df.columns[4] + ')']) / x['company coverage rate'+ '(' + stats_df.columns[4] + ')'], axis=1)
coverage_df["coverage rate diff ("+ stats_df.columns[5] + "/" + stats_df.columns[1] + ")"] = coverage_df.apply(lambda x: (x['company coverage rate'+ '(' + stats_df.columns[5] + ')'] - x['company coverage rate'+ '(' + stats_df.columns[1] + ')']) / x['company coverage rate'+ '(' + stats_df.columns[1] + ')'], axis=1)

# COMMAND ----------

coverage_df

# COMMAND ----------

final_df = pd.DataFrame([])
final_df['Topic'] = coverage_df['Topic']
final_df['avg relevance score ('+ stats_df.columns[1] + ')'] = stats_df[stats_df.columns[1]] 
final_df['avg relevance score ('+ stats_df.columns[2] + ')'] = stats_df[stats_df.columns[2]] 
final_df['avg relevance score ('+ stats_df.columns[3] + ')'] = stats_df[stats_df.columns[3]] 
final_df['avg relevance score ('+ stats_df.columns[4] + ')'] = stats_df[stats_df.columns[4]] 
final_df['avg relevance score ('+ stats_df.columns[5] + ')'] = stats_df[stats_df.columns[5]] 
final_df[coverage_df.columns[5]] = coverage_df[coverage_df.columns[5]]
final_df[coverage_df.columns[4]] = coverage_df[coverage_df.columns[4]]
final_df[coverage_df.columns[3]] = coverage_df[coverage_df.columns[3]]
final_df[coverage_df.columns[2]] = coverage_df[coverage_df.columns[2]]
final_df[coverage_df.columns[1]] = coverage_df[coverage_df.columns[1]]
final_df[coverage_df.columns[6]] = coverage_df[coverage_df.columns[6]]
final_df[coverage_df.columns[7]] = coverage_df[coverage_df.columns[7]]
final_df["avg relevance score diff ("+ stats_df.columns[5] + "/" + stats_df.columns[4] + ")"]  = ( final_df['avg relevance score ('+ stats_df.columns[5] + ')'] - final_df['avg relevance score ('+ stats_df.columns[4] + ')'] )/final_df['avg relevance score ('+ stats_df.columns[4] + ')'] 
final_df["avg relevance score diff ("+ stats_df.columns[5] + "/" + stats_df.columns[1] + ")"]  = ( final_df['avg relevance score ('+ stats_df.columns[5] + ')'] - final_df['avg relevance score ('+ stats_df.columns[1] + ')'] )/final_df['avg relevance score ('+ stats_df.columns[1] + ')'] 
final_df['5-quarter slope'] = slope_df['5-quarter slope']
final_df['5-quarter slope (MA)'] = ma_slope_df['5-quarter slope (MA)']
final_df['5-quarter slope (Qo4Q)'] = yoy_slope_df['5-quarter slope (Qo4Q)']
final_df['5-quarter intercept (Qo4Q)'] = yoy_slope_df['5-quarter intercept (Qo4Q)']

# COMMAND ----------

final_df

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC ## new code

# COMMAND ----------

new_m2_cluster_tp_df = m2_cluster_tp_df 

# COMMAND ----------

new_m2_cluster_tp_df

# COMMAND ----------

# Add best mateched topic's cosine similarity to final_df
final_df['Best matched topic cosine (m1)'] = new_m2_cluster_tp_df['Best matched topic cosine (m1)'].values

# COMMAND ----------

# Add best mateched topic's name to final_df
final_df['Best matched topic name (m1)'] = new_m2_cluster_tp_df["Best matched topic's - Topic name (m1)"].values

# COMMAND ----------

# Add best mateched topic's top 10 keywords to final_df
final_df['Best matched topic top 10 keywords (m1)'] = new_m2_cluster_tp_df["Best matched topic's top 10 keywords (m1)"].values

# COMMAND ----------

# Add m2 topic's top 60 keywords to final_df
final_df['Top 60 keywords + cosine (m2)'] = new_m2_cluster_tp_df["Top 60 keywords + cosine (m2)"].values

# COMMAND ----------

final_df

# COMMAND ----------

final_df

# COMMAND ----------

# final_df.sort_values(by=['avg relevance score diff (2023/12 - 2024/02/2022/12 - 2023/02)'], ascending=False).head(30)

# COMMAND ----------

final_df_path = '/dbfs/mnt/access_work/UC25/Topic Modeling/DTM Phase2/pipeline_results/new_tp_stats_E' + update_quarter + '_v1.csv'

# COMMAND ----------

print(final_df_path)

# COMMAND ----------

final_df.to_csv(final_df_path, index=False)

# COMMAND ----------

maxDateNewQuery

# COMMAND ----------

update_date = "'" + maxDateNewQuery + "'"
print(update_date)

# COMMAND ----------

# Query all parsed transcripts parsed after the last known parsed date.
tsQuery= ("select * from EDS_PROD.QUANT.YUJING_DTM_TP_STATS_DEV_4 "
"WHERE UPDATE_DATE = " + update_date + " ;")

resultspkdf = new_sf.read_from_snowflake(tsQuery)

currdf = resultspkdf.toPandas()

# COMMAND ----------

currdf

# COMMAND ----------

currdf['TOP60_KEYWORDS_COSINE'] = currdf['TOP60_KEYWORDS_COSINE'].apply(ast.literal_eval)

# COMMAND ----------

currdf['KEYWORDS'] = currdf['KEYWORDS'].apply(ast.literal_eval)

# COMMAND ----------

starting_stats_df_path = '/dbfs/mnt/access_work/UC25/Topic Modeling/DTM Phase2/pipeline_results/starting_tp_stats_E' + update_quarter + '_v1.csv'

# COMMAND ----------

currdf.to_csv(starting_stats_df_path, index=False)

# COMMAND ----------

# Query all parsed transcripts parsed after the last known parsed date.
tsQuery= ("select * from EDS_PROD.QUANT.YUJING_DTM_TP_THEME_DEV_4 "
"WHERE UPDATE_DATE = " + update_date + " ;")

resultspkdf = new_sf.read_from_snowflake(tsQuery)

currdf = resultspkdf.toPandas()

# COMMAND ----------

currdf

# COMMAND ----------

theme_stats_df_path = '/dbfs/mnt/access_work/UC25/Topic Modeling/DTM Phase2/pipeline_results/starting_theme_stats_E' + update_quarter + '_v1.csv'

# COMMAND ----------

currdf.to_csv(theme_stats_df_path, index=False)

# COMMAND ----------

