# Databricks notebook source
# MAGIC %md
# MAGIC ### Load Modules

# COMMAND ----------

# MAGIC %pip install transformers==4.40
# MAGIC %pip install mlflow==2.18.0
# MAGIC %pip install omegaconf
# MAGIC
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %run "./../../../package_loader/Cloud_DB_module_Azure_SQL_dev_2_Yujing_git.py"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Import Modules

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %run ./../../../../data-science-nlp-ml-common-code/impackage/utilities/config_utility

# COMMAND ----------

# MAGIC %run ./../../../../data-science-nlp-ml-common-code/impackage/database/snowflake_dbutility

# COMMAND ----------

# MAGIC %run ./common

# COMMAND ----------

from omegaconf import OmegaConf, DictConfig
import sys
from typing import Any
import mlflow
from pyspark.sql.types import StructType, StructField, StringType, FloatType, ArrayType, MapType, DoubleType, IntegerType
from pyspark.sql import SparkSession
from pyspark.sql.functions import (udf, col, size, explode, collect_list, 
                                   when, expr, pandas_udf, PandasUDFType, current_timestamp)
import json
import torch
from transformers import pipeline, AutoTokenizer, AutoModelForSequenceClassification
import pandas as pd
import numpy as np
from pyspark.sql import functions as F
from pyspark.sql import DataFrame

# COMMAND ----------

# MAGIC %md
# MAGIC ## Load Run Configuration 

# COMMAND ----------

run_config = OmegaConf.load('config.yml')

if run_config.user_validate:
  user_config_check(run_config)

# COMMAND ----------

# # Step 2: Initialize Spark Session (if not already initialized)
spark = (SparkSession.builder.appName("Optimized_NLI_Inference")
         .config("spark.sql.shuffle.partitions",run_config.run_parameters.n_partitions)
         .config("spark.executor.resource.gpu.amount", "1")
         .config("spark.task.resource.gpu.amount", "0.8")
         .getOrCreate())

spark.sparkContext.setLogLevel("DEBUG")

LABELS = run_config.model.labels
labels_broadcast = spark.sparkContext.broadcast(LABELS)

nli_pipeline = None

OUT_TABLE = get_table_name(run_config.backfill.output_table)


print(OUT_TABLE)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Define spark UDF Functions

# COMMAND ----------

# Define the schema for the UDF
schema_summary = StructType([
    StructField("total_dict", MapType(StringType(), ArrayType(IntegerType())), False),
    StructField("score_dict", MapType(StringType(), ArrayType(FloatType())), False)
])


# Define the schema for the inference results
dict_schema = StructType([
    StructField("label", StringType(), False),
    StructField("score", FloatType(), False)
])


# Define the schema for the output of the UDF
inference_schema = ArrayType(ArrayType(dict_schema))

# COMMAND ----------


# UDF to parse JSON lists
parse_json_udf = udf(parse_json_list, ArrayType(StringType()))

# UDF to create text pairs
create_text_pairs_udf = udf(create_text_pairs, ArrayType(StringType()))


#EDITED: Define UDF for parsing string representations of lists
parse_udf = udf(lambda x: ast.literal_eval(x) if x else [], ArrayType(StringType()))
summary_udf = udf(lambda texts, inference_result: inference_summary(texts, inference_result), schema_summary)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Fetch Input data

# COMMAND ----------

# MAGIC %md
# MAGIC ### Call transcript data

# COMMAND ----------

new_sf = SnowFlakeDBUtility(config.schema, config.eds_db_prod)

# COMMAND ----------

# #EDITED: Construct and execute the Snowflake query using Spark
tsQuery = f"""
            SELECT
                CAST(CALL_ID AS STRING) AS CALL_ID,
                ENTITY_ID,
                DATE,
                FILT_MD,
                FILT_QA,
                CALL_NAME,
                COMPANY_NAME,
                EARNINGS_CALL,
                ERROR,
                TRANSCRIPT_STATUS,
                UPLOAD_DT_UTC,
                VERSION_ID,
                EVENT_DATETIME_UTC,
                PARSED_DATETIME_EASTERN_TZ,
                SENT_LABELS_FILT_QA,
                SENT_LABELS_FILT_MD
            FROM
                EDS_PROD.QUANT_LIVE.CTS_FUND_COMBINED_SCORES_H t2
            WHERE
                NOT EXISTS (
                    SELECT 1
                    FROM EDS_PROD.{config.schema}.{OUT_TABLE} t1
                    WHERE
                        CAST(t1.CALL_ID AS VARCHAR(16777216))= CAST(t2.CALL_ID AS VARCHAR(16777216)) AND
                        t1.ENTITY_ID = t2.ENTITY_ID AND
                        t1.VERSION_ID = t2.VERSION_ID
                )
            ORDER BY
                PARSED_DATETIME_EASTERN_TZ DESC
      """

currdf_spark = new_sf.read_from_snowflake(tsQuery)  


# COMMAND ----------

# Convert stringified lists to actual arrays
currdf_spark = (currdf_spark 
    .withColumn('FILT_MD', parse_json_udf(col('FILT_MD'))) 
    .withColumn('FILT_QA', parse_json_udf(col('FILT_QA'))) 
    .withColumn('LEN_FILT_MD', size(col('FILT_MD'))) 
    .withColumn('LEN_FILT_QA', size(col('FILT_QA'))) 
    .dropDuplicates(['ENTITY_ID', 'EVENT_DATETIME_UTC']) 
    .orderBy(col('UPLOAD_DT_UTC').asc()))


# COMMAND ----------

import ast
array_int_type_cols = ["SENT_LABELS_FILT_MD",
                       "SENT_LABELS_FILT_QA"]                
      
array_int_convert_udf = udf(literal_eval_safe, ArrayType(IntegerType())) 

for col_name in array_int_type_cols:
    currdf_spark = currdf_spark.withColumn(col_name, array_int_convert_udf(currdf_spark[col_name]))

# COMMAND ----------

# Create text pairs for MD and QA
currdf_spark = currdf_spark \
    .withColumn('TEXT_PAIRS_MD', create_text_pairs_udf(col('FILT_MD'))) \
    .withColumn('TEXT_PAIRS_QA', create_text_pairs_udf(col('FILT_QA')))

# COMMAND ----------

from functools import partial

currdf_spark = currdf_spark.repartition(run_config.run_parameters.n_partitions)

# Step 9: Apply Inference UDFs to DataFrame
currdf_spark = (currdf_spark 
    .withColumn('MD_RESULT', inference_udf(col('TEXT_PAIRS_MD'))) 
    .withColumn('QA_RESULT', inference_udf(col('TEXT_PAIRS_QA'))))

currdf_spark.cache()

currdf_spark = currdf_spark \
    .withColumn("MD_SUMMARY", summary_udf(col("TEXT_PAIRS_MD"),col("MD_RESULT"))) \
    .withColumn("QA_SUMMARY", summary_udf(col("TEXT_PAIRS_QA"),col("QA_RESULT")))

# #EDITED: Extract summary fields
currdf_spark = (currdf_spark
    .withColumn("MD_FINAL_TOTAL", col("MD_SUMMARY.total_dict")) 
    .withColumn("MD_FINAL_SCORE", col("MD_SUMMARY.score_dict")) 
    .withColumn("QA_FINAL_TOTAL", col("QA_SUMMARY.total_dict")) 
    .withColumn("QA_FINAL_SCORE", col("QA_SUMMARY.score_dict")))

# COMMAND ----------

# Register the UDF
extract_inf_udf = udf(extract_inf, MapType(StringType(), StringType()))

# Apply the UDF for MD_FINAL_SCORE and QA_FINAL_SCORE
currdf_spark = currdf_spark.withColumn(
    'MD_FINAL_SCORE_EXTRACTED',
    extract_inf_udf(col('MD_FINAL_SCORE'), lit('FILT_MD'), col('LEN_FILT_MD'), lit(0.8))
).withColumn(
    'QA_FINAL_SCORE_EXTRACTED',
    extract_inf_udf(col('QA_FINAL_SCORE'), lit('FILT_QA'), col('LEN_FILT_QA'), lit(0.8))
)

# COMMAND ----------


# Extract the keys from the UDF output and create new columns
md_final_score_extracted_cols = currdf_spark.select('MD_FINAL_SCORE_EXTRACTED').first().asDict()['MD_FINAL_SCORE_EXTRACTED'].keys()
qa_final_score_extracted_cols = currdf_spark.select('QA_FINAL_SCORE_EXTRACTED').first().asDict()['QA_FINAL_SCORE_EXTRACTED'].keys()

for col_name in md_final_score_extracted_cols:
    currdf_spark = currdf_spark.withColumn(col_name, col('MD_FINAL_SCORE_EXTRACTED').getItem(col_name))

for col_name in qa_final_score_extracted_cols:
    currdf_spark = currdf_spark.withColumn(col_name, col('QA_FINAL_SCORE_EXTRACTED').getItem(col_name))



# COMMAND ----------

# Drop the intermediate columns
currdf_spark = currdf_spark.drop('MD_FINAL_SCORE_EXTRACTED', 'QA_FINAL_SCORE_EXTRACTED')

new_columns = [col.replace('.', '') for col in currdf_spark.columns]
for old_col, new_col in zip(currdf_spark.columns, new_columns):
    currdf_spark = currdf_spark.withColumnRenamed(old_col, new_col)

columns_filt =(['ENTITY_ID', 'CALL_ID', 'VERSION_ID', 'DATE', 'CALL_NAME', 'COMPANY_NAME', 'UPLOAD_DT_UTC',  'PARSED_DATETIME_EASTERN_TZ', 'LEN_FILT_MD', 'LEN_FILT_QA', 'FILT_MD', 'FILT_QA', 'SENT_LABELS_FILT_MD', 'SENT_LABELS_FILT_QA'] + 
           [col.replace('.', '') for col in md_final_score_extracted_cols] + 
          [col.replace('.', '') for col in qa_final_score_extracted_cols])
currdf_spark = currdf_spark.select(*columns_filt)

# COMMAND ----------


label_columns = generate_label_columns(LABELS)

# Filter columns based on the defined substrings
float_type_cols = filter_columns(label_columns, ['_COUNT_', '_REL_'])
array_type_cols = filter_columns(label_columns, ['_SCORE_', '_TOTAL_'])

# Define a UDF to apply ast.literal_eval

array_convert_udf = udf(literal_eval_safe, ArrayType(DoubleType()))
float_convert_udf = udf(literal_eval_safe, DoubleType())

for col_name in float_type_cols:
    currdf_spark = currdf_spark.withColumn(col_name, float_convert_udf(currdf_spark[col_name]))

for col_name in array_type_cols:
    currdf_spark = currdf_spark.withColumn(col_name, array_convert_udf(currdf_spark[col_name]))

# COMMAND ----------

# Define the mapping of original labels to new labels
LABELS_MAPPING = {
    "This text is about a weak consumer or reduced consumption": "REDUCED_CONSUMPTION",
    "This text is about a strong consumer or increased consumption": "INCREASED_CONSUMPTION",
}

# Create a new list for the updated column names
new_columns = []


currdf_spark = rename_columns(currdf_spark, LABELS_MAPPING)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Write to Table

# COMMAND ----------

columns_order = ['ENTITY_ID', 'CALL_ID', 'VERSION_ID', 'DATE', 'CALL_NAME',
       'COMPANY_NAME', 'UPLOAD_DT_UTC',  'PARSED_DATETIME_EASTERN_TZ','LEN_FILT_MD', 'LEN_FILT_QA', 'FILT_MD', 'FILT_QA', 'SENT_LABELS_FILT_MD', 'SENT_LABELS_FILT_QA',
       'INCREASED_CONSUMPTION_COUNT_FILT_MD', 'INCREASED_CONSUMPTION_REL_FILT_MD',
       'INCREASED_CONSUMPTION_SCORE_FILT_MD', 'INCREASED_CONSUMPTION_TOTAL_FILT_MD', 
       'REDUCED_CONSUMPTION_COUNT_FILT_MD', 'REDUCED_CONSUMPTION_REL_FILT_MD',
       'REDUCED_CONSUMPTION_SCORE_FILT_MD', 'REDUCED_CONSUMPTION_TOTAL_FILT_MD',
       'INCREASED_CONSUMPTION_COUNT_FILT_QA', 'INCREASED_CONSUMPTION_REL_FILT_QA',
       'INCREASED_CONSUMPTION_SCORE_FILT_QA', 'INCREASED_CONSUMPTION_TOTAL_FILT_QA',
       'REDUCED_CONSUMPTION_COUNT_FILT_QA', 'REDUCED_CONSUMPTION_REL_FILT_QA',
       'REDUCED_CONSUMPTION_SCORE_FILT_QA', 'REDUCED_CONSUMPTION_TOTAL_FILT_QA']


# spark_parsedDF = pandas_to_spark(currdf_all[currdf_sample.columns])
currdf_spark = currdf_spark.select(*columns_order)
currdf_spark = currdf_spark.replace(np.nan, None)
currdf_spark = currdf_spark.withColumn("DATE", F.to_timestamp(currdf_spark.DATE, 'yyyy-MM-dd'))
currdf_spark = currdf_spark.withColumn("BATCH_LOAD_DT", current_timestamp())

# COMMAND ----------


print("Writing to snowflake table:", OUT_TABLE)

result_curr = new_sf.write_to_snowflake_table(currdf_spark, OUT_TABLE)

# COMMAND ----------

