# Databricks notebook source
# MAGIC %md
# MAGIC ## Instruction
# MAGIC CONTEXT DESCRIPTION : Calculate the coverage rate and relevance score time series for each topic.  
# MAGIC - Time series line plot  
# MAGIC This part shows that line plot of the 120-day rolling avg coverage rate and relevance score during specific time range. Within 120 days rolling back window, if one company has several transcripts, we only focus on the latest transcript for each company.
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Load Packages

# COMMAND ----------

import pandas as pd
import numpy as np
from datetime import datetime
from dateutil.relativedelta import relativedelta
from ast import literal_eval
from collections import Counter
from pyspark.sql.types import *
import warnings
warnings.filterwarnings("ignore")


# COMMAND ----------

# MAGIC %md
# MAGIC ## Connect to Snowflake table

# COMMAND ----------

# MAGIC %run ./../../../../data-science-nlp-ml-common-code/impackage/utilities/config_utility

# COMMAND ----------

# MAGIC %run ./../../../../data-science-nlp-ml-common-code/impackage/database/snowflake_dbutility

# COMMAND ----------

new_sf = SnowFlakeDBUtility(config.schema, config.eds_db_prod)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Connect with SQL database
# MAGIC It has monthly company market cap data

# COMMAND ----------

# MAGIC %run "./../../../package_loader/Cloud_DB_module_Azure_SQL_dev_2_Yujing_git.py"

# COMMAND ----------

myDBFS_sql = DBFShelper_sql()
myDBFS_sql.get_DBFSdir_content(myDBFS_sql.iniPath)

# COMMAND ----------

azSQL_LinkUp = pd.read_pickle(r'/dbfs/' + myDBFS_sql.iniPath + 'my_azSQL_LinkUp.pkl')
azSQL_LinkUp.databaseName = 'QNT'
remote_table = azSQL_LinkUp.read_from_azure_SQL("qnt.p_coe.earnings_calls_mapping_table_mcap")
market_cap  = remote_table.toPandas()

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Read Data from Snowflake

# COMMAND ----------

time_series_end_date = datetime.strptime(dbutils.widgets.get('End Date'), "%Y-%m-%d")
time_series_start_date = datetime.strptime(dbutils.widgets.get('Start Date'), "%Y-%m-%d")

# since we have look back period, we should get the earnings calls for the date prior to our time series start date as well
ecall_start_date = datetime.strptime(dbutils.widgets.get('Start Date'), "%Y-%m-%d") - relativedelta(days=150)

ecall_start_date,time_series_start_date, time_series_end_date

# COMMAND ----------

minDateNewQuery = (pd.to_datetime(ecall_start_date)).strftime('%Y-%m-%d')
maxDateNewQuery = (pd.to_datetime(time_series_end_date)).strftime('%Y-%m-%d')
fromDateNewQuery = (pd.to_datetime(time_series_start_date)).strftime('%Y-%m-%d')

mind = "'" + minDateNewQuery + "'"
maxd = "'" + maxDateNewQuery + "'"
print(mind, maxd)

# COMMAND ----------

# Query all parsed transcripts parsed after the last known parsed date.
tsQuery= ("SELECT * "
    f"FROM  EDS_PROD.QUANT.SANTHOSH_MASS_FT_NLI_DEMAND_DEV_202503_BACKFILL "
          
   "WHERE DATE >= " + mind  + " AND DATE <= " + maxd  + " ;")

resultspkdf = new_sf.read_from_snowflake(tsQuery)

currdf = resultspkdf.toPandas()

if len(currdf)>0:
    print('The data spans from ' + str(currdf['DATE'].min()) + ' to ' + str(currdf['DATE'].max()) + 'and has ' + str(currdf.shape[0]) + ' rows and ' + str(currdf.shape[1]) + ' columns.')
else:
    print('No new transcripts to parse.')
    dbutils.notebook.exit(1)
    os._exit(1)

# COMMAND ----------

del resultspkdf

# COMMAND ----------

# Keep the earliest version of transcript from the same date.
currdf = currdf.sort_values(['ENTITY_ID', 'DATE', 'UPLOAD_DT_UTC']).drop_duplicates(['ENTITY_ID', 'DATE'], keep = 'first' )

# COMMAND ----------

currdf['DATE'] = currdf['DATE'].dt.date

# COMMAND ----------

for col in currdf.filter(like = 'COUNT'):
  currdf[col[:-13] + 'COVERAGE' + col[-8:]] = currdf[col].apply(lambda x: 1 if x>=1 else 0)

# COMMAND ----------

currdf

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preprocessing Market Cap data

# COMMAND ----------

market_cap = market_cap.sort_values(by=['factset_entity_id','date']).drop_duplicates(['factset_entity_id', 'YearMonth'], keep='last')

# COMMAND ----------

market_cap['YEAR_MONTH'] = pd.to_datetime(market_cap['date'], format='%Y-%m-%d').apply(lambda x: str(x)[:7])
market_cap['MCAP_RANK'] = market_cap.groupby('YEAR_MONTH')['MCAP'].rank(ascending=False, method='first')

# COMMAND ----------

market_cap.columns

# COMMAND ----------

# MAGIC %md
# MAGIC ## Helper functions

# COMMAND ----------

def create_plot_df(df_raw, start_date, end_date):
  '''
  Create one data frame that contains the relevance scores for each theme during different time period.
  
  Input:
    df_raw: the backtest dataframe that contains the relevance scores and topics details for each transcript
    start_date: the start date of the period
    end_date: the end date of the period

  Output:
    df_mean: a dataframe that contains relevance score for each theme during different time period

  '''
  
  df = df_raw.copy()
  # Select the data within time range(including the 120 days look-back period before the start date)
  start_date_120days = str(datetime.strptime(start_date,'%Y-%m-%d').date() - relativedelta(days =+ 120))
  startdate = datetime.strptime(start_date_120days, "%Y-%m-%d").date()
  enddate = datetime.strptime(end_date, "%Y-%m-%d").date() 
  time_range = (df['DATE'] > startdate) & (df['DATE'] <= enddate)
  df = df.loc[time_range]

  pre_columns = ['CALL_ID','ENTITY_ID','DATE'] 

  # Select Relevance columns.
  col_type = 'REL'
  df = df[pre_columns + list(df.filter(like = 'REL_FILT_').columns)]
  
  df['DATE'] = df['DATE'].apply(lambda x: str(x))
  
  # Calculate the average of MD & QA
  for col in set([i[:-2] for i in df.filter(like = col_type).columns]):
    df[col + 'AVERAGE'] = df.filter(regex = col, axis=1).mean(axis=1)

  df_mean = pd.DataFrame()
  # Calculate the 120-day rolling average of latest relevance score for each company                            
  unique_date = pd.period_range(start = start_date, end = end_date, freq='D').map(str)  
  for d in unique_date:
      tem_range = pd.period_range(end=d, freq='D', periods=120)
      df_rolling = df.loc[df['DATE'].isin(tem_range.map(str))].copy()
      df_rolling = df_rolling.drop_duplicates(subset='ENTITY_ID', keep='last')
      series = pd.Series([d],index=['DATE_ROLLING']).append(df_rolling.mean(axis = 0).drop(labels=['CALL_ID']))
      df_series = pd.DataFrame(series).T
      df_mean = df_mean.append(df_series)
  df_mean = df_mean.dropna(axis=1,how='all').set_index('DATE_ROLLING')
  return df_mean            

def create_plot_df_coverage_rate(df_raw, start_date, end_date):
  '''
  Create one data frame that contains the coverage rate for each theme during different time period.
  
  Input:
    df_raw: the backfilled dataframe that contains the coverage rate and topics details for each transcript
    start_date: the start date of the period
    end_date: the end date of the period

  Output:
    df_mean: a dataframe that contains coverage rate for each theme/section during different time period

  '''
  
  df = df_raw.copy()
  # Select the data within time range(including the 120 days look-back period before the start date)
  start_date_120days = str(datetime.strptime(start_date,'%Y-%m-%d').date() - relativedelta(days =+ 120))
  startdate = datetime.strptime(start_date_120days, "%Y-%m-%d").date()
  enddate = datetime.strptime(end_date, "%Y-%m-%d").date() 
  time_range = (df['DATE'] > startdate) & (df['DATE'] <= enddate)
  df = df.loc[time_range]
  
  pre_columns = ['CALL_ID','ENTITY_ID','DATE'] 

  # Select coverage rate columns.
  col_type = 'COVERAGE'
  df = df[pre_columns +  list(df.filter(like = '_' + col_type + '_FILT_').columns)]
  
  df['DATE'] = df['DATE'].apply(lambda x: str(x))
  
  # Calculate the average of MD & QA
  for col in set([i[:-2] for i in df.filter(like = col_type).columns]):
     df[col + 'AVERAGE'] = df.filter(regex = col, axis=1).mean(axis=1)
     df[col + 'AVERAGE'] = df[col + 'AVERAGE'].apply(lambda x: 1 if x > 0  else 0)

  df_mean = pd.DataFrame()

  # Calculate the 120-day rolling average of latest coverage rate for each company                            
  unique_date = pd.period_range(start = start_date, end = end_date, freq='D').map(str)  
  for d in unique_date:
      tem_range = pd.period_range(end=d, freq='D', periods=120)
      df_rolling = df.loc[df['DATE'].isin(tem_range.map(str))].copy()
      df_rolling = df_rolling.drop_duplicates(subset='ENTITY_ID', keep='last')
      df_rolling = df_rolling.drop(columns=df_rolling.filter(like='REL').columns)
      df_rolling['COMPANY_COUNT'] = 1
      series = pd.Series([d],index=['DATE_ROLLING']).append(df_rolling.sum(axis = 0).drop(labels=['CALL_ID','ENTITY_ID','DATE']))
      df_series = pd.DataFrame(series).T
      df_mean = df_mean.append(df_series)
  df_mean = df_mean.dropna(axis=1,how='all').set_index('DATE_ROLLING')
  for col in df_mean.filter(like = 'COVERAGE').columns:
    if '_AVERAGE' in col:
      df_mean[col[:-21] + 'COVERRATE' + col[-13:]] = df_mean.apply(lambda x: x[col] / x['COMPANY_COUNT'] if x['COMPANY_COUNT'] != 0 else None, axis = 1)
    else:
      df_mean[col[:-16] + 'COVERRATE' + col[-8:]] = df_mean.apply(lambda x: x[col] / x['COMPANY_COUNT'] if x['COMPANY_COUNT'] != 0 else None, axis = 1)
  df_mean = df_mean.drop(columns = [col for col in df_mean.columns if '_COVERAGE_FILT_' in col])
  return df_mean      



# COMMAND ----------

# MAGIC %md
# MAGIC ## Time Series Line Plot DataFrame

# COMMAND ----------

rank_lower= dbutils.widgets.get('rank_lower')
rank_upper= dbutils.widgets.get('rank_upper')
print('We are focusing on top ' + rank_lower + ' - ' + rank_upper + ' companies')

# COMMAND ----------

market_cap = market_cap[(market_cap['MCAP_RANK'] >= int(rank_lower)) & (market_cap['MCAP_RANK'] <= int(rank_upper))]
currdf['YEAR_MONTH'] = currdf['DATE'].apply(lambda x: str(x)[:7])
currdf_merge = pd.merge(market_cap[['YEAR_MONTH', 'factset_entity_id','MCAP', 'biz_group', 'MCAP_RANK']], currdf,  how='left', left_on=['factset_entity_id','YEAR_MONTH'], right_on = ['ENTITY_ID','YEAR_MONTH'])
currdf_R3K_selected = currdf_merge[~currdf_merge.CALL_ID.isna()]


# COMMAND ----------

# MAGIC %md
# MAGIC #### MCAP time series

# COMMAND ----------

df_cover = create_plot_df_coverage_rate(currdf_R3K_selected, 
              start_date = fromDateNewQuery, 
              end_date = maxDateNewQuery)
df_rel = create_plot_df(currdf_R3K_selected, 
              start_date = fromDateNewQuery, 
              end_date = maxDateNewQuery)
df_cover.reset_index(inplace=True)
df_rel.reset_index(inplace=True)
df_rel_cover = pd.merge(df_cover, df_rel, left_on='DATE_ROLLING', right_on='DATE_ROLLING')
df_rel_cover['CATEGORY'] = 'top ' + rank_lower + '-' + rank_upper 


# COMMAND ----------

df_rel_cover

# COMMAND ----------

# MAGIC %md
# MAGIC #### Sector-level time series

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 1. specific sector

# COMMAND ----------

sector_col = 'biz_group'

currdf_R3K_selected[sector_col].unique()

# COMMAND ----------

specific_sector = dbutils.widgets.get('sector')

df_cover_R3K_gp = create_plot_df_coverage_rate(currdf_R3K_selected[currdf_R3K_selected[sector_col] == specific_sector], 
            start_date = fromDateNewQuery, 
            end_date = maxDateNewQuery)
df_rel_R3K_gp = create_plot_df(currdf_R3K_selected[currdf_R3K_selected[sector_col] == specific_sector], 
            start_date = fromDateNewQuery, 
            end_date = maxDateNewQuery)
df_cover_R3K_gp.reset_index(inplace=True)
df_rel_R3K_gp.reset_index(inplace=True)
df_rel_cover_R3K_gp = pd.merge(df_cover_R3K_gp, df_rel_R3K_gp, left_on='DATE_ROLLING', right_on='DATE_ROLLING')
df_rel_cover_R3K_gp['CATEGORY'] = 'top ' + rank_lower + '-' + rank_upper + ' | ' + specific_sector


# COMMAND ----------

df_rel_cover_R3K_gp

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 2. all sectors

# COMMAND ----------

df_all_gp = pd.DataFrame([])
for gp in currdf_R3K_selected[sector_col].unique():
  df_cover_R3K_gp = create_plot_df_coverage_rate(currdf_R3K_selected[currdf_R3K_selected[sector_col] == gp], 
              start_date = fromDateNewQuery, 
              end_date = maxDateNewQuery)
  df_rel_R3K_gp = create_plot_df(currdf_R3K_selected[currdf_R3K_selected[sector_col] == gp], 
              start_date = fromDateNewQuery, 
              end_date = maxDateNewQuery)
  df_cover_R3K_gp.reset_index(inplace=True)
  df_rel_R3K_gp.reset_index(inplace=True)
  df_rel_cover_R3K_gp = pd.merge(df_cover_R3K_gp, df_rel_R3K_gp, left_on='DATE_ROLLING', right_on='DATE_ROLLING')
  df_rel_cover_R3K_gp['CATEGORY'] = 'top ' + rank_lower + '-' + rank_upper + ' | ' + gp
  df_all_gp = pd.concat([df_all_gp, df_rel_cover_R3K_gp])

# COMMAND ----------

df_all_gp

# COMMAND ----------

df_all_gp['DATE_ROLLING'] = pd.to_datetime(df_all_gp['DATE_ROLLING'])

# COMMAND ----------

