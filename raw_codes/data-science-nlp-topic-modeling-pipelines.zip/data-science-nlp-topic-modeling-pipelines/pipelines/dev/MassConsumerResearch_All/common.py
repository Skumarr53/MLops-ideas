# Databricks notebook source
from pyspark.sql.functions import pandas_udf, PandasUDFType
from typing import Any
from omegaconf import OmegaConf, DictConfig
import ast
from typing import List, Tuple, Union, Callable, Any
from transformers import pipeline, AutoTokenizer, AutoModelForSequenceClassification


run_config = OmegaConf.load('config.yml')
nli_pipeline = None


# Define the schema for the inference results
dict_schema = StructType([
    StructField("label", StringType(), False),
    StructField("score", FloatType(), False)
])


# Define the schema for the output of the UDF
inference_schema = ArrayType(ArrayType(dict_schema))

def display_config_section(config: Any, indent: int = 0, section: str = "") -> None:
    """Recursively display configuration sections with proper indentation"""
    if isinstance(config, (dict, OmegaConf, DictConfig)):
        if section:
            print("\n" + " " * indent + f"{section}:")
        for key, value in config.items():
            display_config_section(value, indent + 2, key)
    else:
        print(" " * indent + f"{section}: {config}")

def validate_config(config: OmegaConf) -> bool:
    """Generic config validator with common checks"""
    def validate_section(section: Any, path: str = "") -> None:
        if isinstance(section, (dict, OmegaConf)):
            for key, value in section.items():
                current_path = f"{path}.{key}" if path else key
                
                # Check for None/null values in required fields
                if value is None:
                    raise ValueError(f"Required field '{current_path}' cannot be null")
                
                # Validate date pairs if they exist
                if 'start_date' in section and 'end_date' in section:
                    if section['start_date'] > section['end_date']:
                        raise ValueError(
                            f"Start date must be before end date in section '{path}'"
                        )
                
                # Custom validation for table names
                if isinstance(value, str) and 'table' in key.lower():
                    if not value.startswith('EDS_PROD'):
                        raise ValueError(
                            f"Table '{current_path}' must start with 'EDS_PROD'"
                        )
                
                validate_section(value, current_path)
    
    try:
        validate_section(config)
        return True
    except Exception as e:
        print(f"Configuration validation failed: {str(e)}")
        return False

def user_config_check(config):
    # Load config
    
    # Display configuration
    print("\n=== PIPELINE CONFIGURATION REVIEW ===")
    display_config_section(config)
    
    print("\n=== IMPORTANT ===")
    print("Please review the configuration above carefully.")
    print("Proceeding with incorrect configuration could impact production data.")
    
    # Validate configuration
    if not validate_config(config):
        print("Exiting due to validation failure.")
        sys.exit(1)
    
    # Ask for confirmation
    while True:
        response = input("\nDo you want to proceed with this configuration? (yes/no): ").lower()
        if response in ['yes', 'no']:
            break
        print("Please enter 'yes' or 'no'")
    
    if response != 'yes':
        print("Pipeline execution cancelled by user.")
        sys.exit(0)    
    return True
  
# Function to parse JSON strings to lists
def parse_json_list(s):
    try:
        return json.loads(s)
    except Exception as e:
        return []
      

# Function to create text pairs for NLI
def create_text_pairs(filt):
    text_pairs = []
    for t in filt:
        for l in labels_broadcast.value:
            text_pairs.append(f"{t}</s></s>{l}.")
    return text_pairs
  
  # Function to initialize the NLI pipeline on each executor
def initialize_nli_pipeline(enable_quantization=False, model_name=None, version = 'Staging'):
    try:        

        # Load the model from the staging branch of the model registry
        staging_model = mlflow.transformers.load_model(f"models:/{model_name}/{version}")

        # Access the model and tokenizer
        model = staging_model.model
        tokenizer = staging_model.tokenizer

        
        if enable_quantization:
            model = torch.quantization.quantize_dynamic(
                model, {torch.nn.Linear}, dtype=torch.qint8
            )
        
        device = 0 if torch.cuda.is_available() else -1
        nli_pipeline = pipeline(
            task="text-classification",
            model=model,
            tokenizer=tokenizer,
            device=device
        )
        return nli_pipeline
    except Exception as e:
        raise e

def inference_summary(texts, inference_result, threshold=0.8):
    score_dict = {tp + '.': [] for tp in LABELS}
    total_dict = {tp + '.': [] for tp in LABELS}
    
    for i, (text_pair, inference) in enumerate(zip(texts, inference_result)):
        text1, text2_label = text_pair.split('</s></s>')
        for s in inference:
            if s['label'] == 'entailment':
                if s['score'] > threshold:
                    total_dict[text2_label].append(1)
                else:
                    total_dict[text2_label].append(0)
                score_dict[text2_label].append(s['score'])
    return total_dict, score_dict

def literal_eval_safe(data_str):
    try:
        return ast.literal_eval(data_str)
    except (ValueError, SyntaxError):
        return None
    



def pd_udf_wrapper(func, schema, udf_type=PandasUDFType.SCALAR):
    @pandas_udf(schema, udf_type)
    def wrapper(*args, **kwargs):
        return func(*args, **kwargs)
    return wrapper


@pandas_udf(inference_schema, PandasUDFType.SCALAR)
def inference_udf(texts: pd.Series) -> pd.Series:
    global nli_pipeline
    if nli_pipeline is None:
        nli_pipeline = initialize_nli_pipeline(enable_quantization=run_config.run_parameters.enable_quantization, 
                                               model_name=run_config.model.registry_name)

    text_list = texts.tolist()
    flat_text_pairs = [pair for sublist in text_list for pair in sublist]
    # Perform inference in batch
    
    results = nli_pipeline(
        flat_text_pairs,
        padding=True,
        top_k=None,
        batch_size=run_config.run_parameters.batch_size,  # Adjusted batch size
        truncation=True,
        max_length=512
    )
    # results = processed_texts.apply(pl_inference)
    # Split results back to original rows
    split_results = []
    idx = 0
    for pairs in text_list:
        if len(pairs):
            split_results.append(results[idx:idx+len(pairs)])
            idx += len(pairs)
        else:
            split_results.append([])

    return pd.Series(split_results)

def extract_inf(row, section, section_len, threshold):
    count_col = {}
    rel_col = {}
    score_col = {}
    total_col = {}

    # set_trace()
    for tp, score in row.items():
        if section_len != 0:
            score_binary = [float(1) if s > threshold else float(0) for s in score]
            total_col[f'{tp}_TOTAL_{section}'] = score_binary 
            count_col[f'{tp}_COUNT_{section}'] = float(sum(score_binary))
            rel_col[f'{tp}_REL_{section}'] = sum(score_binary) / section_len
            score_col[f'{tp}_SCORE_{section}'] = [round(s, 4) for s in score]
        else:
            count_col[f'{tp}_COUNT_{section}'] = None
            rel_col[f'{tp}_REL_{section}'] = None
            total_col[f'{tp}_TOTAL_{section}'] = []
            score_col[f'{tp}_SCORE_{section}'] = []
    # print(count_col.keys())

    return {**count_col, **rel_col, **score_col, **total_col}



def generate_label_columns(
    labels: List[str],
    metrics: List[str] = ['COUNT', 'REL', 'SCORE', 'TOTAL'],
    sec_filters: List[str] = ['FILT_MD', 'FILT_QA'],
) -> List[str]:
    """
    Generates a list of column names based on the provided labels, metrics, and secondary filters.

    The order of metrics should always follow: 'COUNT', 'REL', 'SCORE', 'TOTAL', and 'EXTRACT'.
    Some metrics may be omitted based on the use case, but the order must remain the same.

    Args:
        labels (List[str]): Labels such as 'consumer_strength', 'consumer_weakness', etc.
        metrics (List[str]): Metrics like 'COUNT', 'REL', 'SCORE', etc. Defaults to ['COUNT', 'REL', 'SCORE', 'TOTAL'].
        sec_filters (List[str], optional): Secondary filters like 'FILT_MD', 'FILT_QA'. Defaults to ['FILT_MD', 'FILT_QA'].

    Returns:
        List[str]: An ordered list of generated column names.

    Example:
        >>> labels = ['consumer_strength', 'consumer_weakness']
        >>> metrics = ['COUNT', 'REL']
        >>> generate_label_columns(labels, metrics)
        ['consumer_strength_COUNT_FILT_MD', 'consumer_strength_REL_FILT_MD',
         'consumer_strength_COUNT_FILT_QA', 'consumer_strength_REL_FILT_QA',
         'consumer_weakness_COUNT_FILT_MD', 'consumer_weakness_REL_FILT_MD',
         'consumer_weakness_COUNT_FILT_QA', 'consumer_weakness_REL_FILT_QA']
    """
    dynamic_columns = []
    for label in labels:
        for sec_filter in sec_filters:
            for metric in metrics:
                # Base column
                column_name = f"{label}_{metric}_{sec_filter}"
                dynamic_columns.append(column_name)
    return dynamic_columns


def literal_eval_safe(data_str):
    try:
        return ast.literal_eval(data_str)
    except (ValueError, SyntaxError):
        return None
      

def filter_columns(columns, substrings):
    return [col for col in columns if any(sub in col for sub in substrings)]


def rename_columns(df, labels_mapping):
    if not isinstance(df, DataFrame):
        raise ValueError("The provided input is not a valid Spark DataFrame.")

    if not isinstance(labels_mapping, dict):
        raise ValueError("The labels_mapping must be a dictionary.")

    try:
        # Create a mapping for renaming
        new_column_names = {}
        for old_col in df.columns:
            for original_label, new_label in labels_mapping.items():
                if original_label in old_col:
                    new_column_names[old_col] = old_col.replace(original_label, new_label)
                    break  # Break after the first match to avoid multiple replacements

        # Rename columns if any new names are generated
        for old_col, new_col in new_column_names.items():
            df = df.withColumnRenamed(old_col, new_col)

        return df
    except Exception as e:
        raise e

def get_table_name(base_tab_name):
   tablename_curr = base_tab_name
   if config.env_name.lower() == 'quant':
      tablename_curr = f"{run_config.model.owner}_{tablename_curr}"
   tablename_curr = tablename_curr.upper()
   return tablename_curr
