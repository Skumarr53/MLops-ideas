# Databricks notebook source
# MAGIC %md 
# MAGIC ### INSTRUCTIONS
# MAGIC
# MAGIC Find the best matched static topic for each topic in m2 (re-estimated topics)
# MAGIC - This notebook is depended on 2_Embedding_Model.ipynb and 3_Starting_topics_generation_pipeline.ipynb.
# MAGIC - Methodology:
# MAGIC   - Generate top key words and cosine similarity for each m2 topic.
# MAGIC   - Load static topic word lists.
# MAGIC   - Calculate the static topic vectors based on m2 model.
# MAGIC   - Match each m2 topic with the closest static topic.
# MAGIC - Output:
# MAGIC   - csv with   
# MAGIC      (1) m2: topic top 60 key words + cosine similarity,   
# MAGIC      (2) best matched m1: topic top 60 key words + cosine similarity + level-1 theme + best matched cosine
# MAGIC

# COMMAND ----------

pip install umap-learn

# COMMAND ----------

pip install ksvd

# COMMAND ----------

pip install -U pydantic spacy==3.4.4

# COMMAND ----------

# MAGIC %run "./../../package_loader/call_transcript_NLP_BERT_libs_stg5_pl4.py" 

# COMMAND ----------

# %run "Quant/Call_Transcript_Topic_Modeling/Development/Dynamic Topic Modeling/call_transcript_emb_lib_v1.1.py"

# COMMAND ----------

# MAGIC %run ./../../../data-science-nlp-ml-common-code/impackage/utilities/config_utility

# COMMAND ----------

# MAGIC %run ./../../../data-science-nlp-ml-common-code/impackage/database/snowflake_dbutility

# COMMAND ----------

new_sf = SnowFlakeDBUtility(config.schema, config.eds_db_prod)

# COMMAND ----------

from gensim.test.utils import common_texts
from gensim.models import Phrases
import pickle
import gensim
import gc
import itertools
from scipy import spatial
from __future__ import division
import pandas as pd
import math
import ast
from scipy import stats
from gensim.models import coherencemodel
from scipy.linalg import norm
from sklearn.preprocessing import normalize
from scipy.stats import entropy
from sklearn.preprocessing import normalize
import os
from itertools import combinations
import numpy as np
from gensim import corpora, models, similarities #calc all similarities at once, from http://radimrehurek.com/gensim/tut3.html
from gensim.models import Word2Vec, KeyedVectors
from random import seed, sample
import seaborn as sns
from ksvd import ApproximateKSVD 
# from umap import UMAP
import plotly.express as px
# import hdbscan
import plotly.figure_factory as ff
import scipy.cluster.hierarchy as shc
from scipy.cluster.hierarchy import ward, fcluster
from collections import Counter
from scipy.cluster.hierarchy import cophenet
from scipy.spatial.distance import pdist
from sklearn.metrics.pairwise import cosine_similarity, linear_kernel
from dateutil.relativedelta import relativedelta

# COMMAND ----------

# MAGIC %md
# MAGIC ### Load the new embedding model (m2)

# COMMAND ----------

# Calculate the start date and end date of word2vec model
w2v_end_date = datetime.now() # relativedelta(months=1) # end_month is excluded in the w2vmodel (unless for embedding of starting topic list)
w2v_start_date = datetime.now() - relativedelta(months=60)
w2v_end_month = format(w2v_end_date , '%y_%m')
w2v_start_month = format(w2v_start_date, '%y_%m')
print(w2v_start_month, w2v_end_month)

# COMMAND ----------

earnings_quarter = datetime.now() - relativedelta(months=3)

# COMMAND ----------

# Load the new embedding (i.e., 19_01 ~ 23_12 )
# w2vmodel2 = Word2Vec.load('/dbfs/mnt/access_work/UC25/Topic Modeling/Embedding/word2vec_DATM_19_01_23_12_v1.model')

# COMMAND ----------

# Load the new embedding every quarter
w2vmodel2 = Word2Vec.load('/dbfs/mnt/access_work/UC25/Topic Modeling/Embedding/word2vec_DATM_' + w2v_start_month + '_' + w2v_end_month + '_v1.model')

# COMMAND ----------

period_name = w2v_start_month + '_' + w2v_end_month
print(period_name)

# COMMAND ----------

## Function to generate discourse atoms
def do_aksvd(w2vmodel, n_comp, n_nonzeros, savelocation, embedding_time, save=False):
  '''
  Generate topic vectors (Extract Atoms with K-SVD) from w2vmodel.

  Inputs:
    w2vmodel: word2vec model 
    n_comp: n_components is number of discourse atoms, if vocab size is smallish, keep this fewer.
    n_nonzeros: transform_n is the number of atoms (components) that a word can be a linear combo of. 
    savelocation: the folder location for saving the topic vectors.
    embedding_time: the time period of the w2vmodel
    save: whether save the topic vector. Default value is "False".

  Output:
    dictionary_t: topic vectors

  '''
  aksvd_t = ApproximateKSVD(n_components=n_comp, transform_n_nonzero_coefs=n_nonzeros, max_iter=50, tol=1e-10) # Set max_iter=50 and tol=1e-10 to reduce the randomness.
  dictionary_t = aksvd_t.fit(w2vmodel.wv.vectors).components_ # Dictionary is the matrix of discourse atoms.
  gamma_t = aksvd_t.transform(w2vmodel.wv.vectors) # get the gammas, which are the "weights" of each word on a discourse atoms
  #len(dictionary[0]) #check that a discourse-atom vector is still same dimensions as word-vectors, note that norm of the dictionary vecs (atoms) are each 1! 
  if save==True:
      # outfile = open(str(savelocation)  + embedding_time + str(n_comp) + 'comp' + str(n_nonzeros) + 'nonzeros_aksvd','wb')
      # pickle.dump(aksvd_t,outfile)
      # outfile.close()
      
      outfile = open(str(savelocation)  + embedding_time + str(n_comp) + 'comp' + str(n_nonzeros) + 'nonzeros_dictionary' ,'wb')
      pickle.dump(dictionary_t,outfile)
      outfile.close()
      
      # outfile = open(str(savelocation)  + embedding_time + str(n_comp) + 'comp' + str(n_nonzeros) + 'nonzeros_gamma','wb')
      # pickle.dump(gamma_t,outfile)
      # outfile.close()
  return dictionary_t

# COMMAND ----------

if_create_topic_vectors = ast.literal_eval(dbutils.widgets.get("Create topic vectors"))

# COMMAND ----------

# If the topic vectors have already been saved into blob, load it directly. 
if if_create_topic_vectors:
  # Discourse atoms 4
  mydictionary4 = do_aksvd(w2vmodel2, 290, 5,  '/dbfs/mnt/access_work/UC25/Topic Modeling/DTM Phase2/', period_name + '_DATM_random1_', save = if_create_topic_vectors) #290 topics, each word can be a linear combo of 5 topics 

  # Discourse atoms 5
  mydictionary5 = do_aksvd(w2vmodel2, 290, 5,  '/dbfs/mnt/access_work/UC25/Topic Modeling/DTM Phase2/', period_name + '_DATM_random2_', save = if_create_topic_vectors) #290 topics, each word can be a linear combo of 5 topics

  # Discourse atoms 6
  mydictionary6 = do_aksvd(w2vmodel2, 290, 5,  '/dbfs/mnt/access_work/UC25/Topic Modeling/DTM Phase2/', period_name + '_DATM_random3_', save = if_create_topic_vectors) #290 topics, each word can be a linear combo of 5 topics

else:  
  infile = open('/dbfs/mnt/access_work/UC25/Topic Modeling/DTM Phase2/' + period_name + '_DATM_random1_290comp5nonzeros_dictionary','rb') 
  mydictionary4 = pickle.load(infile)
  infile.close()

  infile = open('/dbfs/mnt/access_work/UC25/Topic Modeling/DTM Phase2/' + period_name + '_DATM_random2_290comp5nonzeros_dictionary','rb')
  mydictionary5 = pickle.load(infile)
  infile.close()

  infile = open('/dbfs/mnt/access_work/UC25/Topic Modeling/DTM Phase2/' + period_name + '_DATM_random3_290comp5nonzeros_dictionary','rb')
  mydictionary6 = pickle.load(infile)
  infile.close()

# COMMAND ----------

data2 = np.vstack([mydictionary4, mydictionary5, mydictionary6])

# COMMAND ----------

mydictionary4

# COMMAND ----------

def count_shared_keywords(keywords1, keywords2):
  return len(set(keywords1) & set(keywords2)), set(keywords1) & set(keywords2)

# COMMAND ----------

def generate_new_topics(topic_vector_3times, w2vmodel, num_of_clusters, plot_dendrogram = True):

  # Pick up coherent topics: Only select topics whose cosine with all top5 closest words are larger than 0.6 
  atoms_words = [] # list of topic index and top 5 key words
  data_selected = [] # coherent topic's vectors
  included_index = []
  for i in range(0, len(topic_vector_3times)):  
      words = [i] + [j[0] for j in w2vmodel.wv.similar_by_vector(topic_vector_3times[i],topn=5) if j[1] >= 0.6] 
      if len(words) == 6:
        atoms_words.append(words)
        data_selected.append(topic_vector_3times[i])
        included_index.append(i)   

  # Cluster the included topics into num_of_clusters(i.e. 360) topics
  Z = shc.linkage(data_selected, method='average')
  c, coph_dists = cophenet(Z, pdist(data_selected))
  clusters = fcluster(Z, num_of_clusters, criterion='maxclust')

  # Record the topic indexes for each cluster
  new_topics_dic = {k: [] for k in range(1, num_of_clusters + 1)} # range starts from 1 because the cluster's label starts from 1
  for i, topic in enumerate(clusters):
    new_topics_dic[topic].append(included_index[i])

  # Create new topic vectors 
  new_topics_vectors = [] 
  atoms_dic_new = []
  for i,v in enumerate(list(new_topics_dic.values())):
    vectors = topic_vector_3times[v].mean(axis = 0)
    dic = {'Topic (m2)': i, 'Top 5 keywords (m2)': [j[0] for j in w2vmodel.wv.similar_by_vector(vectors, topn=5) if j[1] >0.6], 'Top 60 keywords + cosine (m2)': [j for j in w2vmodel.wv.similar_by_vector(vectors, topn=60)]}
    if len(dic['Top 5 keywords (m2)']) == 5:
      atoms_dic_new.append(dic)
      new_topics_vectors.append(vectors)
  atoms_df_new = pd.DataFrame.from_dict(atoms_dic_new)

  ## Drop duplicated topics
  atoms_df_new['Top_60_key_words'] = atoms_df_new['Top 60 keywords + cosine (m2)'].apply(lambda x: [w[0] for w in x])
  atoms_df_new['Duplicate'] = 'No duplicate'

  # Create a 'Duplicate' column to record the duplicated topic no. and shared keywords
  for i, row1 in atoms_df_new.iterrows():
    tp1 = row1['Topic (m2)']
    kw1 = row1['Top_60_key_words'][:10]
    has_dupicate = False

    for j, row2 in atoms_df_new.iterrows():
      if i != j:
        kw2 = row2['Top_60_key_words'][:10]
        kw_len, shared_keywords = count_shared_keywords(kw1, kw2)
        if kw_len >= 5:
          has_dupicate = True
          atoms_df_new.at[i, 'Duplicate'] = [row2['Topic (m2)'],shared_keywords]

  duplicated_df = atoms_df_new[atoms_df_new['Duplicate']!='No duplicate']
  nonduplicated_df = atoms_df_new[atoms_df_new['Duplicate'] =='No duplicate']

  duplicated_df['duplicated_topic_num'] = duplicated_df.Duplicate.apply(lambda x: x[0])
  duplicated_df['duplicated_group'] = duplicated_df.apply(lambda x: str(sorted([x.Duplicate[0],x['Topic (m2)']])), axis=1)
  duplicated_df = duplicated_df.drop_duplicates(['duplicated_group']).drop_duplicates(['duplicated_topic_num']).drop(columns = ['duplicated_topic_num',	'duplicated_group'])
  atoms_df_new = pd.concat([duplicated_df, nonduplicated_df]).sort_values(['Topic (m2)']).drop(columns = ['Top_60_key_words','Duplicate'])
  # Record the index of kept topics
  keep_index = atoms_df_new.index.to_list()
  new_topics_vectors = [new_topics_vectors[i]  for i in keep_index]
  atoms_df_new = atoms_df_new.reset_index(drop=True)
  atoms_df_new['Topic (m2)'] = atoms_df_new.index

  if plot_dendrogram:
    names = range(len(new_topics_vectors))
    fig = ff.create_dendrogram(np.array(new_topics_vectors) ,
                              orientation='left',
                              labels=np.array(atoms_df_new.apply(lambda x: [x['Topic (m2)']] + x['Top 5 keywords (m2)'], axis=1)),
                              linkagefun=lambda x: shc.linkage(x, "average"), # hierarchical clustering
                              hovertext = names)
    fig.update_layout(width=1000, height=5000, title="Hierarchical Clustering with DATM: " + str(len(new_topics_vectors)) + " topics from " + period_name)
    fig.show()

  return atoms_df_new, new_topics_vectors

# COMMAND ----------

m2_cluster_tp_df, m2_new_topics_vectors  = generate_new_topics(data2, w2vmodel2, 360, plot_dendrogram = False)

# COMMAND ----------

m2_cluster_tp_df

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC ### Load labeled static topics (m1)

# COMMAND ----------

tsQuery= ("select * from EDS_PROD.QUANT.YUJING_DTM_TP_LST_DEV_1; ")

resultspkdf = new_sf.read_from_snowflake(tsQuery)

labeled_m1_df = resultspkdf.toPandas()

# COMMAND ----------

labeled_m1_df['TOP60_KEYWORDS_COSINE'] = labeled_m1_df['TOP60_KEYWORDS_COSINE'].apply(ast.literal_eval)
labeled_m1_df['KEYWORDS'] = labeled_m1_df['KEYWORDS'].apply(ast.literal_eval)
labeled_m1_df['TOP60_KEYWORDS_COSINE'] = labeled_m1_df['TOP60_KEYWORDS_COSINE'].apply(lambda x: [(item['word'], item['score']) for item in x])
labeled_m1_df['TOPIC_ID'] = labeled_m1_df['TOPIC_ID'].apply(lambda x: int(x))

# COMMAND ----------

labeled_m1_df = labeled_m1_df.sort_values(by=['TOPIC_ID'])

# COMMAND ----------

labeled_m1_df['TOP10_KEYWORDS'] = labeled_m1_df['TOP60_KEYWORDS_COSINE'].apply(lambda x: ['_'.join(i.split()) for i,cos in x[:10]])

# COMMAND ----------

labeled_m1_df

# COMMAND ----------

labeled_m1_df.reset_index(drop=True, inplace=True)

# COMMAND ----------

m1_cluster_atoms_words = [i for i in labeled_m1_df['TOP10_KEYWORDS'].values]

# COMMAND ----------

m1_cluster_atoms_words

# COMMAND ----------

# Calculate the topic vectors for static topics based on embedding of m2
m1_new_topics_vectors= []
for i, w in enumerate(m1_cluster_atoms_words):
  key_words = w
  key_words_vectors = np.array([w2vmodel2.wv.vectors[w2vmodel2.wv.key_to_index[word]] for word in key_words if word in w2vmodel2.wv.key_to_index])
  atom_new_vector = np.mean(key_words_vectors, axis = 0)
  m1_new_topics_vectors.append(atom_new_vector)

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC ### Find the best matched static topic for the m2 topic

# COMMAND ----------

len(m1_new_topics_vectors),len(m2_new_topics_vectors)

# COMMAND ----------

costri = cosine_similarity(np.array(m2_new_topics_vectors), np.array(m1_new_topics_vectors))
atomsseq = np.argmax(costri, axis=1)
maxinRow = np.amax(costri, axis=1)

# COMMAND ----------

labeled_m1_df.head(2)

# COMMAND ----------

m2_cluster_tp_df

# COMMAND ----------

m2_cluster_tp_df['Best matched topic (m1)'] = m2_cluster_tp_df['Topic (m2)'].apply(lambda x: atomsseq[x])
m2_cluster_tp_df["Best matched topic's top 10 keywords (m1)"] = m2_cluster_tp_df['Best matched topic (m1)'].apply(lambda x: labeled_m1_df.loc[labeled_m1_df.TOPIC_ID == x + 1]['TOP10_KEYWORDS'][x])
m2_cluster_tp_df["Best matched topic's top 60 keywords + cosine (m1)"] = m2_cluster_tp_df['Best matched topic (m1)'].apply(lambda x: labeled_m1_df.loc[labeled_m1_df.TOPIC_ID == x + 1]['TOP60_KEYWORDS_COSINE'][x])
m2_cluster_tp_df["Best matched topic's - Included (m1)"] = m2_cluster_tp_df['Best matched topic (m1)'].apply(lambda x: labeled_m1_df.loc[labeled_m1_df.TOPIC_ID == x + 1]['INCLUDED'][x])
m2_cluster_tp_df["Best matched topic's - Topic name (m1)"] = m2_cluster_tp_df['Best matched topic (m1)'].apply(lambda x: labeled_m1_df.loc[labeled_m1_df.TOPIC_ID == x + 1]['TOPIC_NAME'][x])
m2_cluster_tp_df['Best matched topic cosine (m1)'] = m2_cluster_tp_df['Topic (m2)'].apply(lambda x: maxinRow[x])

# COMMAND ----------

m2_cluster_tp_df.sort_values(['Best matched topic cosine (m1)']).head(5)

# COMMAND ----------

m2_cluster_tp_df['Best matched topic (m1)'] = m2_cluster_tp_df['Best matched topic (m1)'].apply(lambda x: x + 1)

# COMMAND ----------

quarter = (earnings_quarter.month - 1) // 3 + 1
update_quarter = f"{earnings_quarter.year % 100}Q{quarter}"
print(update_quarter)

# COMMAND ----------

m2_cluster_tp_path = '/dbfs/mnt/access_work/UC25/Topic Modeling/DTM Phase2/pipeline_results/new_tp_E' + update_quarter +'_v1.csv'

# COMMAND ----------

m2_cluster_tp_path

# COMMAND ----------

m2_cluster_tp_df.to_csv(m2_cluster_tp_path, index=False)

# COMMAND ----------

