# Databricks notebook source
# SANTHOSH_MASS_FT_NLI_DEMAND_TS_DEV_20250319_3000_MERGED
# SANTHOSH_MASS_FT_NLI_DEMAND_TS_DEV_20250319_1500_MERGED
# SANTHOSH_MASS_FT_NLI_DEMAND_TS_DEV_20250319_DISCRETIONARY_3000_MERGED
# SANTHOSH_MASS_FT_NLI_DEMAND_TS_DEV_20250319_DISCRETIONARY_1500_MERGED
# SANTHOSH_MASS_FT_NLI_DEMAND_TS_DEV_20250319_STAPLES_1500_MERGED
# SANTHOSH_MASS_FT_NLI_DEMAND_TS_DEV_20250319_STAPLES_3000_MERGED

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %run ./../../../data-science-nlp-ml-common-code/impackage/utilities/config_utility
# MAGIC

# COMMAND ----------

# MAGIC %run ./../../../data-science-nlp-ml-common-code/impackage/database/snowflake_dbutility

# COMMAND ----------

tables = ['SANTHOSH_MASS_FT_NLI_DEMAND_TS_DEV_20250319_3000',
'SANTHOSH_MASS_FT_NLI_DEMAND_TS_DEV_20250319_1500',
'SANTHOSH_MASS_FT_NLI_DEMAND_TS_DEV_20250319_DISCRETIONARY_3000',
'SANTHOSH_MASS_FT_NLI_DEMAND_TS_DEV_20250319_DISCRETIONARY_1500',
'SANTHOSH_MASS_FT_NLI_DEMAND_TS_DEV_20250319_STAPLES_1500',
'SANTHOSH_MASS_FT_NLI_DEMAND_TS_DEV_20250319_STAPLES_3000',
'SANTHOSH_MASS_FT_NLI_DEMAND_TS_DEV_3000',
'SANTHOSH_MASS_FT_NLI_DEMAND_TS_DEV_1500',
'SANTHOSH_MASS_FT_NLI_DEMAND_TS_DEV_DISCRETIONARY_3000',
'SANTHOSH_MASS_FT_NLI_DEMAND_TS_DEV_DISCRETIONARY_1500',
'SANTHOSH_MASS_FT_NLI_DEMAND_TS_DEV_STAPLES_1500',
'SANTHOSH_MASS_FT_NLI_DEMAND_TS_DEV_STAPLES_3000']

# COMMAND ----------

def get_category(tab):
    sector = 'All'
    if 'DISCRETIONARY' in tab:  sector = 'Discretionary'
    if 'STAPLES' in tab:  sector = 'Staples'
    
    n_comp = 3000
    if '1500' in tab: n_comp = 1500
    return f"{sector}_top{n_comp}".upper()

BASE_QUERY = '''
SELECT * FROM EDS_PROD.QUANT.{tab}
'''
new_sf = SnowFlakeDBUtility(config.schema, config.eds_db_prod)


for i,tab in enumerate(tables):
  print(tab)
  df = new_sf.read_from_snowflake(BASE_QUERY.format(tab=tab)).filter(col("CATEGORY") == 'top 1-3000').drop(*['CATEGORY'])
  df = df.withColumn('CATEGORY', lit(get_category(tab)))
  if '20250319' in tab:
    df = df.withColumn('Model_version', lit("NEW_MODEL"))
  else:
    df = df.withColumn('Model_version', lit("OLD_MODEL"))
  if i == 0:
      df_union = df
  else:
      df_union = df_union.union(df)



# COMMAND ----------

result = new_sf.write_to_snowflake_table(df_union, "SANTHOSH_MASS_FT_NLI_DEMAND_TS_DEV_20250319_COMBINED")

# COMMAND ----------

pd_df.columns

# COMMAND ----------

df_union

# COMMAND ----------

(pd_df.CATEGORY + pd_df.Model_version).value_counts()

# COMMAND ----------

res_cols  =['INCREASED_CONSUMPTION_COVERRATE_FILT_MD',
 'REDUCED_CONSUMPTION_COVERRATE_FILT_MD',
 'INCREASED_CONSUMPTION_COVERRATE_FILT_QA',
 'REDUCED_CONSUMPTION_COVERRATE_FILT_QA',
 'INCREASED_CONSUMPTION_COVERRATE_FILT_AVERAGE',
 'REDUCED_CONSUMPTION_COVERRATE_FILT_AVERAGE',
 'INCREASED_CONSUMPTION_REL_FILT_MD',
 'REDUCED_CONSUMPTION_REL_FILT_MD',
 'INCREASED_CONSUMPTION_REL_FILT_QA',
 'REDUCED_CONSUMPTION_REL_FILT_QA',
 'INCREASED_CONSUMPTION_REL_FILT_AVERAGE',
 'REDUCED_CONSUMPTION_REL_FILT_AVERAGE']

# COMMAND ----------

old_data = old_data.withColumn("Model_version", lit("OLD_MODEL"))    
new_data = new_data.withColumn("Model_version", lit("NEW_MODEL"))

comb_data = new_data.union(old_data)

# COMMAND ----------

merged_df = new_data.join(old_data, on='DATE_ROLLING', how="outer")


# COMMAND ----------

merged_df.columns

# COMMAND ----------

print(f"Writing to Snowflake table: {NEW_TABLE}_MERGED")
result_curr = new_sf.write_to_snowflake_table(merged_df, f"{NEW_TABLE}_MERGED")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Download as CSV

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %run ./../../../data-science-nlp-ml-common-code/impackage/utilities/config_utility
# MAGIC

# COMMAND ----------

# MAGIC %run ./../../../data-science-nlp-ml-common-code/impackage/database/snowflake_dbutility

# COMMAND ----------

BASE_QUERY = '''
SELECT * FROM EDS_PROD.QUANT.{tab}
'''
new_sf = SnowFlakeDBUtility(config.schema, config.eds_db_prod)

# COMMAND ----------

tables = ['SANTHOSH_MASS_FT_NLI_DEMAND_TS_DEV_20250319_3000_MERGED',
          'SANTHOSH_MASS_FT_NLI_DEMAND_TS_DEV_20250319_1500_MERGED',
          'SANTHOSH_MASS_FT_NLI_DEMAND_TS_DEV_20250319_DISCRETIONARY_3000_MERGED',
          'SANTHOSH_MASS_FT_NLI_DEMAND_TS_DEV_20250319_DISCRETIONARY_1500_MERGED',
          'SANTHOSH_MASS_FT_NLI_DEMAND_TS_DEV_20250319_STAPLES_1500_MERGED',
          'SANTHOSH_MASS_FT_NLI_DEMAND_TS_DEV_20250319_STAPLES_3000_MERGED']

cols_req = ['DATE_ROLLING',
            'INCREASED_CONSUMPTION_COVERRATE_FILT_AVERAGE_NEW',
            'REDUCED_CONSUMPTION_COVERRATE_FILT_AVERAGE_NEW',
            'INCREASED_CONSUMPTION_REL_FILT_AVERAGE_NEW',
            'REDUCED_CONSUMPTION_REL_FILT_AVERAGE_NEW',
            'INCREASED_CONSUMPTION_COVERRATE_FILT_AVERAGE_OLD',
            'REDUCED_CONSUMPTION_COVERRATE_FILT_AVERAGE_OLD',
            'INCREASED_CONSUMPTION_REL_FILT_AVERAGE_OLD',
            'REDUCED_CONSUMPTION_REL_FILT_AVERAGE_OLD']

# COMMAND ----------


from pyspark.sql.functions import lit

out_dir = '/Workspace/Repos/santhosh.kumar3@voya.com/data-science-nlp-topic-modeling-pipelines/pipelines/dev/results'

def get_category(tab):
    sector = 'All'
    if 'DISCRETIONARY' in tab:  sector = 'Discretionary'
    if 'STAPLES' in tab:  sector = 'Staples'
    
    n_comp = 3000
    if '1500' in tab: n_comp = 1500
    return f"{sector}_top{n_comp}".upper()


for i, tab in enumerate(tables):
    print(f"Loading from Snowflake table: {tab}")
    df = new_sf.read_from_snowflake(BASE_QUERY.format(tab=tab))
    print(get_category(tab))
    df = df.withColumn('CATEGORY', lit(get_category(tab)))
    if i == 0:
        df_union = df
    else:
        df_union = df_union.union(df)

    # df[cols_req].to_csv(f"{out_dir}/{tab}.csv", index=False)

# COMMAND ----------


result = new_sf.write_to_snowflake_table(df_union, "SANTHOSH_MASS_FT_NLI_DEMAND_TS_DEV_20250319_COMBINED") 

# COMMAND ----------

# MAGIC %md
# MAGIC ## Plotting

# COMMAND ----------

new_sf = SnowFlakeDBUtility(config.schema, config.eds_db_prod)


# COMMAND ----------

data = new_sf.read_from_snowflake("select * from EDS_PROD.QUANT.SANTHOSH_MASS_FT_NLI_DEMAND_TS_DEV_20250328_COMBINED").toPandas()

# COMMAND ----------

data.CATEGORY.unique(), data.MODEL_VERSION.unique()

# COMMAND ----------

import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from tqdm import tqdm

# Sample DataFrame creation for demonstration (replace this with your actual DataFrame)
# df = pd.read_csv('your_data.csv')  # Load your DataFrame from a CSV or other source
# Example DataFrame for demonstration

tables = ['SANTHOSH_MASS_FT_NLI_DEMAND_TS_DEV_20250319_3000_MERGED',
          'SANTHOSH_MASS_FT_NLI_DEMAND_TS_DEV_20250319_1500_MERGED',
          'SANTHOSH_MASS_FT_NLI_DEMAND_TS_DEV_20250319_DISCRETIONARY_3000_MERGED',
          'SANTHOSH_MASS_FT_NLI_DEMAND_TS_DEV_20250319_DISCRETIONARY_1500_MERGED',
          'SANTHOSH_MASS_FT_NLI_DEMAND_TS_DEV_20250319_STAPLES_1500_MERGED',
          'SANTHOSH_MASS_FT_NLI_DEMAND_TS_DEV_20250319_STAPLES_3000_MERGED']

def get_title(metric, cat):
  title = ""
  metric = metric.replace('_FILT','')
  metric = metric.replace('_REL',' RELEVANCE')

  sector = 'All Sectors'
  if 'DISCRETIONARY' in cat:  sector = 'Discretionary'
  if 'STAPLES' in cat:  sector = 'Staples'

  n_comp = 3000
  if '1500' in cat: n_comp = 1500

  return f"{metric}: {sector} | Top {n_comp} Companies"

def plot_line_chart(cat):
  # List of metrics
  metrics = [
      'INCREASED_CONSUMPTION_COVERRATE_FILT_AVERAGE',
      'REDUCED_CONSUMPTION_COVERRATE_FILT_AVERAGE',
      'INCREASED_CONSUMPTION_REL_FILT_AVERAGE',
      'REDUCED_CONSUMPTION_REL_FILT_AVERAGE'
  ]
  out_dir = '/Workspace/Repos/santhosh.kumar3@voya.com/data-science-nlp-topic-modeling-pipelines/pipelines/dev/results'

  df = data[data.CATEGORY==cat]

  df = df.sort_values(by='DATE_ROLLING', ascending=True)
  df['DATE_ROLLING'] = pd.to_datetime(df['DATE_ROLLING'])

  # Create subplots
  fig, axs = plt.subplots(len(metrics), 1, figsize=(10, 15), sharex=True)
  # Plot each metric
  for i, metric in enumerate(metrics):
      # new_col = f'{metric}_NEW'
      # old_col = f'{metric}_OOB'


      axs[i].plot(df['DATE_ROLLING'][df.MODEL_VERSION=="NEW_MODEL"], df[metric][df.MODEL_VERSION=="NEW_MODEL"], label='New', color='blue')
      axs[i].plot(df['DATE_ROLLING'][df.MODEL_VERSION=="OOB"], df[metric][df.MODEL_VERSION=="OOB"], label='OOB', color='orange') #, marker='x'
      
      title = get_title(metric, cat)
      axs[i].set_title(title.replace('_', ' ').title())
      # axs[i].set_ylabel('Value')
      axs[i].legend()
      axs[i].grid()

  # Set x-axis label
  axs[-1].set_xlabel('Date')
  plt.xticks(rotation=30)
  plt.gca().xaxis.set_minor_locator(mdates.MonthLocator(bymonth=[4,7,10]))
  # Adjust layout
  plt.tight_layout()
  plt.savefig(f"{out_dir}/{cat}.png", bbox_inches='tight')


for cat in tqdm(data.CATEGORY.unique()):
  plot_line_chart(cat)

# COMMAND ----------

