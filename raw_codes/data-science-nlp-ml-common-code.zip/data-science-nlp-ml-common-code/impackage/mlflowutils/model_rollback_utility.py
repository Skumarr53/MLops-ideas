# Databricks notebook source
# MAGIC %pip install transformers==4.38.1 optimum==1.17.1 torch==2.0

# COMMAND ----------

# MAGIC %run ./../utilities/config_utility

# COMMAND ----------

import pandas as pd 
import torch

# COMMAND ----------

import mlflow
from mlflow import MlflowClient

# COMMAND ----------

client=MlflowClient()

# COMMAND ----------

latest_version_info = client.get_latest_versions(config.mlflow_FINBERT_model_name, stages=["Production"])
latest_production_version = latest_version_info[0].version

# COMMAND ----------

latest_production_version

# COMMAND ----------

client.transition_model_version_stage(
  name=config.mlflow_FINBERT_model_name,
  version=latest_production_version,
  stage="Staging"
)

# COMMAND ----------

latest_archived_version_info = client.get_latest_versions(config.mlflow_FINBERT_model_name, stages=["Archived"])
latest_archived_version = latest_archived_version_info[0].version

# COMMAND ----------

latest_archived_version

# COMMAND ----------

client.transition_model_version_stage(
  name=config.mlflow_FINBERT_model_name,
  version=latest_archived_version,
  stage="Production"
)