# Databricks notebook source
# MAGIC %run ./register_bert_model

# COMMAND ----------

import os, pathlib
from mlflow.pyfunc import PythonModel, PythonModelContext

# COMMAND ----------

model_path="/dbfs/mnt/ajaya/finbert_mlflow/"
artifacts = { pathlib.Path(file).stem: os.path.join(model_path, file) 
                    for file in os.listdir(model_path) 
                    if not os.path.basename(file).startswith('.') }

# COMMAND ----------

import mlflow

mlflow.set_experiment('/Users/ajaya.devalla@voya.com/mlflow_practice/finbert_better_transformer_experiment')

with mlflow.start_run(run_name = "finbert_better_transformer_run"):
    mlflow.pyfunc.log_model('classifier', 
                            python_model=RegisterBERTModel(), 
                            artifacts=artifacts, 
                            registered_model_name='finbert_better_transformer_model')

# COMMAND ----------

import mlflow

model = mlflow.pyfunc.load_model('models:/finbert_better_transformer_model/latest')

# COMMAND ----------

txt=['good enough','The overall quality if good, but there are certain aspects of the product that made it hard to use']

# COMMAND ----------

model.predict(txt)