# Databricks notebook source
# MAGIC %run "./test_mlflow_model"