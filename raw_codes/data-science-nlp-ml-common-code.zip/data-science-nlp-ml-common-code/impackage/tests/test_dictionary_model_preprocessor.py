# Databricks notebook source
# MAGIC %run "./../preprocessor/dictionary_model_preprocessor"

# COMMAND ----------

"""
Nutter Fixture for testing the DictionaryModelPreprocessor module.
"""

from runtime.nutterfixture import NutterFixture
class DictionaryModelPreprocessorFixture(NutterFixture):
   """
   This DictionaryModelPreprocessor fixture is used for unit testing all the methods that are used in the dictionary_model_preprocessor.py module 
   """
   def __init__(self):
      """
      helps in intializing all the instance variables

      """
      self.dictionary_model_obj=DictionaryModelPreprocessor()
      NutterFixture.__init__(self)
      
     
   def assertion_word_tokenizer(self):
      """
      This method is used for unit testing DictionaryModelPreprocessorFixture.word_tokenizer method
      """
      assert (self.dictionary_model_obj.word_tokenizer("thank you ii to the house of VOYA financial services") == ['thank', 'voya', 'financial', 'services'])
   def assertion_preprocess_text(self):
      """
      This method is used for unit testing DictionaryModelPreprocessorFixture.preprocess_text method
      """
      text, input_words, word_count=self.dictionary_model_obj.preprocess_text("I'll  ACHIEVE 999 z z a  c heights")
      assert (text==' will achieve heights' and input_words==[' ', 'achieve', 'heights'] and word_count==3 )

   def assertion_preprocess_text_empty(self):
      """
      This method is used for unit testing DictionaryModelPreprocessorFixture.preprocess_text method
      """
      text, input_words, word_count=self.dictionary_model_obj.preprocess_text("")
      assert (text==False and input_words==[] and word_count==0 )

   def assertion_preprocess_text_list_empty(self):
      """
      This method is used for unit testing DictionaryModelPreprocessorFixture.preprocess_text method
      """
      text_list, input_words_list, word_count_list=self.dictionary_model_obj.preprocess_text_list("")
      assert (len(text_list)==0 and input_words_list==[] and len(word_count_list)==0 )
   def assertion_preprocess_text_list(self):
      """
      This method is used for unit testing DictionaryModelPreprocessorFixture.preprocess_text method
      """
      text_list, input_words_list, word_count_list=self.dictionary_model_obj.preprocess_text_list(["I'll  ACHIEVE 999 z z a c heights"])
      assert (text_list[0]=='will achieve heights' and input_words_list[0]==['achieve', 'heights'] and word_count_list[0]==2 )

result = DictionaryModelPreprocessorFixture().execute_tests()
print(result.to_string())