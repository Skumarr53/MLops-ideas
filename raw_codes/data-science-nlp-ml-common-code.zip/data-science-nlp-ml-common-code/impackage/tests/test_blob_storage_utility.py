# Databricks notebook source
# MAGIC %run "./../filesystem/blob_storage_utility"

# COMMAND ----------

"""
Nutter Fixture for testing the blob storage utility module.
"""

from runtime.nutterfixture import NutterFixture
class BlobStorageUtilityFixture(NutterFixture):
   """
   This BlobStorageUtility fixture is used for unit testing all the methods that are used in the BlobStorageUtility.py module 
   """
   def __init__(self):
      """
      helps in intializing all the instance variables
      """
      self.blob_obj=BlobStorageUtility()
      NutterFixture.__init__(self)

   def assertion_init_variables(self):
      """
      This method is used for unit testing BlobStorageUtility.read_contraction_words method
      """
      assert("LM_Dictionary" in self.blob_obj.words_dictionary_file_location)

   def assertion_read_contraction_words(self):
      """
      This method is used for unit testing BlobStorageUtility.read_contraction_words method
      """
      contraction_word_dict=self.blob_obj.read_contraction_words()
      assert (contraction_word_dict["ain't"] == "is not" and contraction_word_dict["aren't"] == "are not" and contraction_word_dict["can't"] == "cannot")
  
   def assertion_read_stop_words(self):
      """
      This method is used for unit testing BlobStorageUtility.read_stop_words method
      """
      stop_word_set=self.blob_obj.read_stop_words()
      assert ("is" in stop_word_set and "in" in stop_word_set)
   def assertion_read_litigious_words(self):
      """
      This method is used for unit testing BlobStorageUtility.read_litigious_words method
      """
      litigious_words_set=self.blob_obj.read_litigious_words()
      assert ("prosecutions" in litigious_words_set)
   def assertion_read_complexity_words(self):
      """
      This method is used for unit testing BlobStorageUtility.read_complexity_words method
      """
      complexity_words_set=self.blob_obj.read_complexity_words()
      assert ("contingencies" in complexity_words_set)
   def assertion_read_uncertainity_words(self):
      """
      This method is used for unit testing BlobStorageUtility.read_uncertainity_words method
      """
      uncertainity_words_set=self.blob_obj.read_uncertainity_words()
      assert ("uncertainty" in uncertainity_words_set)
   def assertion_read_vocab_positive_words(self):
      """
      This method is used for unit testing BlobStorageUtility.read_vocab_positive_words method
      """
      vocab_positive_words_set=self.blob_obj.read_vocab_positive_words()
      assert ("succeeding" in vocab_positive_words_set)
   def assertion_read_vocab_negative_words(self):
      """
      This method is used for unit testing BlobStorageUtility.read_vocab_negative_words method
      """
      vocab_negative_words_set=self.blob_obj.read_vocab_negative_words()
      assert ("worsening" in vocab_negative_words_set)
   

result = BlobStorageUtilityFixture().execute_tests()
print(result.to_string())