# Databricks notebook source
# MAGIC %run "./../utilities/config_utility"

# COMMAND ----------

"""
Nutter Fixture for testing the config_utility module.
"""

from runtime.nutterfixture import NutterFixture
class ConfigFixture(NutterFixture):
   """
   This Config fixture is used for unit testing all the methods that are used in the config_utility.py module 
   """
   def __init__(self):
      """
      helps in intializing all the instance variables

      instance variable: Config is created
      """
      self.config_obj=Config()
      self.config_obj_stg=Config("Quant_Stg")
      self.config_obj_live=Config("Quant_Live")
      NutterFixture.__init__(self)
 
     
   def assertion_schema(self):
      """
      This method is used for unit testing schema variable in config_utility.py
      """
      assert (self.config_obj.schema == "QUANT" and self.config_obj_stg.schema == "QUANT_STG" and self.config_obj_live.schema == "QUANT_LIVE")

   

result = ConfigFixture().execute_tests()
print(result.to_string())