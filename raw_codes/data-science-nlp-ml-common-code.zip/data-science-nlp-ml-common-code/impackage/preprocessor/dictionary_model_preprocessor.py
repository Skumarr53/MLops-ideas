# Databricks notebook source
!pip install spacy==3.4.4
!pip install https://github.com/explosion/spacy-models/releases/download/en_core_web_sm-3.4.0/en_core_web_sm-3.4.0.tar.gz


# COMMAND ----------

# MAGIC %run ./text_preprocessor

# COMMAND ----------

"""
NAME : DictionaryModelTextPreprocessor

DESCRIPTION:
This module serves the below functionalities:
                Tokenization
             
"""

class DictionaryModelPreprocessor(TextPreprocessor):
  
  """Topic X Preprocessing CLASS"""
    
  def __init__(self):
    """Initialize the super class Init method"""
    super().__init__()
    self.spacy_tokenizer = spacy.load('en_core_web_sm')

  def word_tokenizer(self, text):
    """tokenizes the text and performed lemmatization

    Parameters:
    argument1 (str): text
   
    Returns:
    str:list of lemmatized words
    
    """
    text = text.lower()
    doc = self.spacy_tokenizer(text)
    token_lemmatized = []
    for token in doc:
      token_lemmatized.append(token.text)

    filtered_words = list(filter(lambda x: x not in self.stop_words_List, token_lemmatized))
    return filtered_words

  def preprocess_text(self, text_list):
    """
    Preprocess the text like remove double quotes, removes single letter words, replace multiple spaces with single space
    
    Parameters:
    argument1 (list): list
   
    Returns:
    str,list,int: text, input_words, word_count
    
    """
    text = self.check_datatype(text_list)
    if text:
      text = self.expand_contractions(re.sub('’', "'", text))
      text = text.strip().lower() 
      #replacing " " " with space 
      text = text.replace('"', '')
      #remove single words - 'a','A','i','I'
      text = re.sub(r"\b[a-zA-Z]\b", "", text)  
      #replace anything that is not an english letter - ',','.','123','$' with space
      text = re.sub("[^a-zA-Z]", " ", text) 
      #replace spaces more than one with single space 
      text = re.sub("\s+", ' ', text)
      input_words = self.word_tokenizer(text)
      word_count = len(input_words)
      return text, input_words, word_count
    
    else:
      
      return text, [], 0
    
  def preprocess_text_list(self, text_list):
    """
    Preprocess the text list like remove double quotes, removes single letter words, replace multiple spaces with single space
    
    Parameters:
    argument1 (list): list
   
    Returns:
    list,list,list: text list, input words list, word count list
    
    """
    input_word_list=[]
    word_count_list=[]
    final_text_list=[]
    for txt in text_list:
        txt = self.expand_contractions(re.sub('’', "'", txt))
        txt = txt.strip().lower() 
        #replacing " " " with space 
        txt =txt.replace('"', '')
        #remove single words - 'a','A','i','I'
        txt = re.sub(r"\b[a-zA-Z]\b", "", txt)  
        #replace anything that is not an english letter - ',','.','123','$' with space
        txt = re.sub("[^a-zA-Z]", " ", txt) 
        #replace spaces more than one with single space 
        txt = re.sub("\s+", ' ', txt)
        txt = txt.strip()
        token_word_list=self.word_tokenizer(txt)
        input_word_list.append(token_word_list)
        if len(token_word_list)!=0:
          word_count_list.append(len(token_word_list))
        else:
          word_count_list.append(0)
        final_text_list.append(txt)
    return final_text_list, input_word_list, word_count_list
    
