# Databricks notebook source
# MAGIC %run ./../utilities/config_utility

# COMMAND ----------

# MAGIC %run ./../utilities/customexception

# COMMAND ----------

import ast

# COMMAND ----------

"""
NAME : BlobStorageUtility

DESCRIPTION:
This module serves the below functionalities:
                READING THE CONTENTS FROM THE FILES IN BLOB STORAGE
              
"""


class BlobStorageUtility:
  
  """AZURE BLOB STORAGE HELPER CLASS"""
  
  def __init__(self):
    
    """Initialize the attributes of the Blob Storage Utility object"""
    
    self.blob_path = config.model_artifacts_path
    
    self.words_dictionary_file_location = self.blob_path + config.preprocessing_words_path
    self.negate =config.negated_words
    
  def read_contraction_words(self):
    """Reads the contraction words from the blob storage"""
    file_path=self.words_dictionary_file_location + "contraction_words.txt"
    contents=''
    try:
        with open(file_path, "r") as fs_contraction_words:
          contents = fs_contraction_words.read()
    except FileNotFoundError as ex:
        raise FilesNotLoadedException()
    return ast.literal_eval(contents)
    
  def read_stop_words(self):
    """Reads the stop words from the blob storage"""
    file_path=self.words_dictionary_file_location + 'StopWords_Full_list.txt'
    stop_words=''
    try:
        with open(file_path ,'r') as fs_stop_words:
          stop_words = fs_stop_words.read().lower()
    except FileNotFoundError as ex:
        raise FilesNotLoadedException()
    stop_words_List = stop_words.split('\n')
    return set(stop_words_List)
    
  def read_litigious_words(self):
    """Reads the litigious words from the blob storage"""
    file_path = self.words_dictionary_file_location + 'litigious_words.txt'
    pos_words=''
    try:
        with open(file_path ,'r') as fs_pos_words:
          pos_words = fs_pos_words.read().lower()
    except FileNotFoundError as ex:
        raise FilesNotLoadedException()
    litigious_words_List = pos_words.split('\n')
    return set(litigious_words_List)
    
    
  def read_complexity_words(self):
    """Reads the complexity words from the blob storage"""
    file_path = self.words_dictionary_file_location + 'complexity_words.txt'
    negation_words=''
    try:
      with open(file_path ,'r') as fs_negation_words:
          negation_words = fs_negation_words.read().lower()
    except FileNotFoundError as ex:
        raise FilesNotLoadedException()
    complex_words_list = negation_words.split('\n')
    return set(complex_words_list)
    
  def read_uncertainity_words(self):
    """Reads the uncertainity words from the blob storage"""
    file_path = self.words_dictionary_file_location + 'uncertainty_words.txt'
    try:
        with open(file_path,'r') as fs_negation_words:
          negation_words = fs_negation_words.read().lower()
    except FileNotFoundError as ex:
        raise FilesNotLoadedException()
    uncertain_word_list = negation_words.split('\n')
    return set(uncertain_word_list)
    
  def read_syllable_count(self):
    """Reads the syllable words from the blob storage"""
    file_path = self.words_dictionary_file_location + 'syllable_count.txt'
    syllables = {}
    try:
        with open(file_path ,'r') as fs_pos_words:
          for line in fs_pos_words:
              word, count = line.split() 
              syllables[word.lower()] = int(count)
    except FileNotFoundError as ex:
        raise FilesNotLoadedException()
    return syllables
    
    
  def read_vocab_positive_words(self):
    """Reads the vocabulary positive words from the blob storage"""
    file_path = self.words_dictionary_file_location + 'vocab_pos.txt'
    pos_words=''
    try:
        with open(file_path ,'r') as fs_pos_words:
          pos_words = fs_pos_words.read().lower()
        positive_words_List = pos_words.split('\n')
    except FileNotFoundError as ex:
        raise FilesNotLoadedException()
    return set(positive_words_List)
    
  def read_vocab_negative_words(self):
    """Reads the vocabulary negativefrom the blob storage"""
    file_path=self.words_dictionary_file_location + 'vocab_neg.txt'
    neg_words=''
    try:
        with open(file_path ,'r') as fs_neg_words:
          neg_words = fs_neg_words.read().lower()
        negative_word_list = neg_words.split('\n')
    except FileNotFoundError as ex:
        raise FilesNotLoadedException()
    return set(negative_word_list)
    
   
    